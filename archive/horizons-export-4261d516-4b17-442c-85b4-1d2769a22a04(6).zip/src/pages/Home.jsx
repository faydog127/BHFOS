import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { 
  Star, ShieldCheck, CheckCircle2, ArrowRight, 
  PlayCircle, ClipboardCheck, Camera, 
  Clock, BadgeCheck 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { trackCallClick, trackBookClick, trackOfferClick } from '@/lib/tracking';
import FreeAirCheckModal from '@/components/FreeAirCheckModal';

const Home = () => {
  const [showAirCheckModal, setShowAirCheckModal] = useState(false);

  const handleFreeAirCheckClick = () => {
    console.log('🔘 "Book Free Air Check" button clicked');
    trackOfferClick('free_air_check');
    setShowAirCheckModal(true);
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50">
      <Helmet>
        <title>The Vent Guys | NADCA Certified Duct & Dryer Vent Cleaning</title>
        <meta name="description" content="Professional NADCA-certified air duct and dryer vent cleaning in Brevard County. Photo-verified results, 48-hour SLA, and no hidden fees. Book your free air check today." />
      </Helmet>

      {/* TRUST STRIP (Sticky/Prominent) */}
      <div className="bg-blue-900 text-white py-2 px-4 text-center text-xs md:text-sm font-medium sticky top-16 md:top-20 z-40 shadow-sm">
        <div className="container mx-auto flex flex-wrap justify-center gap-3 md:gap-8 items-center">
          <span className="flex items-center gap-1"><Star className="w-3 h-3 text-yellow-400 fill-yellow-400" /> 4.9/5 Google Rated</span>
          <span className="hidden md:inline opacity-50">|</span>
          <span className="flex items-center gap-1"><BadgeCheck className="w-3 h-3 text-blue-300" /> NADCA Certified</span>
          <span className="hidden md:inline opacity-50">|</span>
          <span className="flex items-center gap-1"><Camera className="w-3 h-3 text-blue-300" /> Photo-Verified Work</span>
          <span className="hidden md:inline opacity-50">|</span>
          <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-blue-300" /> 48-Hour SLA</span>
        </div>
      </div>

      {/* HERO SECTION */}
      <section className="relative bg-slate-900 text-white overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            alt="Clean modern living room with good air quality" 
            className="w-full h-full object-cover opacity-30" 
            src="https://images.unsplash.com/photo-1656122381069-9ec666d95cf1" />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-slate-900/40"></div>
        </div>

        <div className="container mx-auto px-4 py-16 md:py-24 lg:py-32 relative z-10">
          <div className="max-w-3xl">
            <div className="flex gap-2 mb-6 flex-wrap">
               <span className="bg-blue-600/20 border border-blue-500/30 text-blue-200 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                 Serving Brevard County
               </span>
               <span className="bg-green-600/20 border border-green-500/30 text-green-200 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1">
                 <ShieldCheck className="w-3 h-3" /> Fully Insured
               </span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-6 text-white">
              NADCA-Level Duct & Dryer Vent Cleaning — <span className="text-blue-400">Photo-Verified.</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-slate-300 mb-8 leading-relaxed max-w-2xl">
              No hidden fees. No mess. Documented results you can trust with our 48-Hour SLA guarantee.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg h-14 px-8 shadow-lg shadow-blue-900/20"
                asChild
                onClick={() => trackBookClick('hero_primary')}
              >
                <Link to="/booking">Book Online</Link>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="bg-transparent border-slate-400 text-white hover:bg-white/10 hover:text-white hover:border-white font-semibold text-lg h-14 px-8"
                asChild
                onClick={() => trackCallClick('hero_secondary')}
              >
                <a href="tel:3213609704">Call Now</a>
              </Button>
            </div>

            <div className="mt-10 pt-8 border-t border-slate-800 flex flex-wrap gap-6 md:gap-12 items-center opacity-90">
               {/* Trust Badges Row - Increased Size (64px/h-16) */}
               
               {/* NADCA Badge - Image Replacement */}
               <div className="bg-white rounded-md p-2 shadow-sm flex items-center justify-center h-16 w-auto">
                 <img 
                   src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/f4b1326b89f7e33e3c403875e9f7442a.png" 
                   alt="NADCA Certified Member Seal" 
                   className="h-full w-auto object-contain" 
                 />
               </div>

               {/* Clean Air Certified Image */}
               <div className="bg-white rounded-md p-2 shadow-sm flex items-center justify-center h-24 w-auto">
                 <img
                    src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/66cfd791bc41361d9e6457d872f80a87.png"
                    alt="The Vent Guys Clean Air Standard Badge"
                    className="h-full w-auto object-contain"
                  />
               </div>

               {/* Google Rating */}
               <div className="flex items-center gap-3">
                 <div className="flex flex-col items-center justify-center bg-white/10 rounded-lg h-16 px-3 min-w-[80px] border border-white/10">
                    <span className="font-bold text-2xl text-white leading-none">4.9</span>
                    <div className="flex text-yellow-400 mt-1">
                      <Star className="w-3 h-3 fill-current" />
                      <Star className="w-3 h-3 fill-current" />
                      <Star className="w-3 h-3 fill-current" />
                      <Star className="w-3 h-3 fill-current" />
                      <Star className="w-3 h-3 fill-current" />
                    </div>
                 </div>
                 <span className="font-bold text-white text-sm hidden sm:block">Google<br/>Rated</span>
               </div>

               {/* Insured */}
               <div className="flex items-center gap-3">
                 <div className="bg-green-900/50 p-1 rounded-full border border-green-500/30 flex items-center justify-center h-16 w-auto">
                    <ShieldCheck className="w-full h-full text-green-400" />
                 </div>
                 <div className="flex flex-col leading-none">
                   <span className="text-sm font-bold uppercase tracking-wide text-slate-400">Fully</span>
                   <span className="font-bold text-xl text-white">Insured</span>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* BEFORE/AFTER SLIDER SECTION */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">See the Difference</h2>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg">
              Don't just take our word for it. Every job is documented with before & after photos so you know exactly what you're paying for.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto bg-slate-100 rounded-2xl overflow-hidden shadow-xl aspect-video relative group">
             {/* Placeholder for Slider Component */}
             <div className="absolute inset-0 flex items-center justify-center bg-slate-200">
               <img 
                 alt="Split comparison showing dirty air duct on left and clean air duct on right" 
                 className="w-full h-full object-cover"
                src="https://images.unsplash.com/photo-1696853961331-22ed783d24cd" />
               <div className="absolute inset-0 flex items-center justify-center bg-black/30 z-10">
                 <div className="bg-white/90 backdrop-blur px-6 py-4 rounded-lg text-center shadow-lg">
                   <p className="font-bold text-slate-800 text-lg mb-1">[BEFORE / AFTER SLIDER]</p>
                   <p className="text-sm text-slate-600">Interactive Component Placeholder</p>
                 </div>
               </div>
               {/* Mock Slider Handle */}
               <div className="absolute inset-y-0 left-1/2 w-1 bg-white z-20 cursor-ew-resize shadow-lg">
                 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-full p-2 shadow-lg">
                   <div className="flex gap-1">
                      <div className="w-0 h-0 border-y-4 border-y-transparent border-r-4 border-r-slate-400"></div>
                      <div className="w-0 h-0 border-y-4 border-y-transparent border-l-4 border-l-slate-400"></div>
                   </div>
                 </div>
               </div>
             </div>
          </div>
          <p className="text-center text-sm text-slate-500 mt-4 flex items-center justify-center gap-2">
            <Camera className="w-4 h-4" /> Drag slider to compare. Real results from local homes.
          </p>
        </div>
      </section>

      {/* OFFER BLOCK */}
      <section className="py-16 bg-blue-50 border-y border-blue-100">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12 max-w-5xl mx-auto">
            <div className="flex-1 space-y-6">
              <div className="inline-block bg-blue-100 text-blue-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide mb-2">
                Limited Time Offer
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900">
                Free In-Home Air Check
                <span className="block text-lg font-normal text-slate-600 mt-2">(15–20 Minute Inspection)</span>
              </h2>
              <p className="text-slate-700 text-lg">
                Not sure if you need cleaning? We'll come out, inspect your system, and give you an honest assessment with photos.
              </p>
              
              <ul className="space-y-3">
                {[
                  "Visual checklist of your system's health",
                  "Photo documentation of any issues found",
                  "No-pressure educational consultation",
                  "Clear next-step recommendations"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-slate-700">
                    <CheckCircle2 className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button 
                  size="lg" 
                  className="bg-blue-600 hover:bg-blue-700 text-white shadow-md"
                  onClick={handleFreeAirCheckClick}
                >
                  Book Your Free Air Check
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-blue-200 text-blue-700 hover:bg-blue-50"
                  asChild
                  onClick={() => trackCallClick('offer_block')}
                >
                  <a href="tel:3213609704">Call Now</a>
                </Button>
              </div>
            </div>
            <div className="flex-1 w-full max-w-md">
               <div className="bg-white p-6 rounded-2xl shadow-xl border border-blue-100 relative overflow-hidden">
                 <div className="absolute top-0 right-0 bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1 rounded-bl-lg">
                   $0 Cost
                 </div>
                 <img 
                   alt="Technician showing inspection results on a tablet to a homeowner" 
                   className="w-full h-64 object-cover rounded-lg mb-4"
                  src="https://images.unsplash.com/photo-1634967389630-b6bbab0fab7e" />
                 <div className="text-center">
                   <p className="font-bold text-slate-800">"I didn't know what was in my vents until they showed me."</p>
                   <div className="flex justify-center text-yellow-400 mt-2 mb-1">
                     <Star className="w-4 h-4 fill-current" />
                     <Star className="w-4 h-4 fill-current" />
                     <Star className="w-4 h-4 fill-current" />
                     <Star className="w-4 h-4 fill-current" />
                     <Star className="w-4 h-4 fill-current" />
                   </div>
                   <p className="text-xs text-slate-500">- Sarah M., Palm Bay</p>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* PROCESS VIDEO SECTION */}
      <section className="py-16 md:py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">What Professional Duct Cleaning Really Means</h2>
          <p className="text-slate-400 max-w-2xl mx-auto mb-12 text-lg">
             We use negative pressure and agitation tools according to NADCA ACR 2021 standards. No "blow-and-go" scams here.
          </p>

          <div className="max-w-4xl mx-auto bg-black rounded-xl overflow-hidden shadow-2xl aspect-video relative group cursor-pointer">
            <div className="absolute inset-0 flex items-center justify-center">
              <img 
                alt="Technician using professional negative air machine equipment" 
                className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity"
               src="https://images.unsplash.com/photo-1670064161367-4c605010ac37" />
              <PlayCircle className="w-20 h-20 text-white opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all absolute z-10" />
              <div className="absolute bottom-6 left-6 bg-black/60 backdrop-blur px-4 py-2 rounded text-left">
                <p className="font-bold text-white text-sm">[TECH PHOTO / VIDEO PLACEHOLDER]</p>
                <p className="text-xs text-slate-300">See our process in action</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PROGRAMS ROW */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900">Our Core Services</h2>
            <p className="text-slate-600 mt-4">Specialized solutions for every need</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Card 1 */}
            <Card className="hover:shadow-lg transition-shadow border-slate-200">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <div className="text-blue-600 font-bold text-xl">💨</div>
                </div>
                <CardTitle className="text-xl">Dryer Vent Cleaning</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6">
                  Prevent fires and improve efficiency. We clean the entire run from connection to termination point, measuring airflow before and after.
                </p>
                <Link to="/services" className="text-blue-600 font-semibold hover:text-blue-800 inline-flex items-center group">
                  Learn More <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Link>
              </CardContent>
            </Card>

            {/* Card 2 */}
            <Card className="hover:shadow-lg transition-shadow border-slate-200">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <BadgeCheck className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle className="text-xl">NADCA Duct Cleaning</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6">
                  Comprehensive source removal cleaning for your HVAC system. Adhering strictly to NADCA ACR 2021 standards for indoor air quality.
                </p>
                <Link to="/services" className="text-blue-600 font-semibold hover:text-blue-800 inline-flex items-center group">
                  Learn More <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Link>
              </CardContent>
            </Card>

            {/* Card 3 */}
            <Card className="hover:shadow-lg transition-shadow border-slate-200">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <ClipboardCheck className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle className="text-xl">Property Manager Program</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6">
                  Volume pricing and automated scheduling for HOAs and property managers. Keep your residents safe and compliant effortlessly.
                </p>
                <Link to="/for-property-managers" className="text-blue-600 font-semibold hover:text-blue-800 inline-flex items-center group">
                  Learn More <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* REVIEWS STRIP */}
      <section className="py-12 bg-slate-50 border-y border-slate-200">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-8">Trusted by Homeowners Across Brevard County</h2>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto text-left">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white p-6 rounded-lg shadow-sm border border-slate-100">
                <div className="flex text-yellow-400 mb-3">
                  {[...Array(5)].map((_, j) => <Star key={j} className="w-4 h-4 fill-current" />)}
                </div>
                <p className="text-slate-700 italic mb-4 text-sm">
                  "Professional, on time, and they actually showed me pictures of what they did. My allergies have been so much better since."
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center font-bold text-slate-500 text-xs">
                    {['JD', 'AS', 'MR'][i-1]}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 text-sm">{['John D.', 'Amanda S.', 'Mike R.'][i-1]}</p>
                    <p className="text-xs text-slate-500">Verified Customer</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-10">
            <a href="#" className="text-blue-600 font-semibold hover:underline">See all 200+ Google Reviews →</a>
          </div>
        </div>
      </section>

      {/* FAQ TEASER */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-slate-900">Common Questions</h2>
          </div>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>How often should I clean my dryer vent?</AccordionTrigger>
              <AccordionContent>
                Most manufacturers and fire safety experts recommend cleaning your dryer vent at least once a year to prevent fire hazards and maintain efficiency.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger>What does NADCA certified mean?</AccordionTrigger>
              <AccordionContent>
                NADCA (National Air Duct Cleaners Association) certification ensures we follow strict standards for source removal, safety, and ethical practices. It means we do the job right, not just scratch the surface.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger>How long does a typical cleaning take?</AccordionTrigger>
              <AccordionContent>
                A standard dryer vent cleaning takes about 45-60 minutes. A full air duct system cleaning varies by home size but typically takes 3-5 hours.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger>Do you use chemicals?</AccordionTrigger>
              <AccordionContent>
                Our primary method is source removal (physical cleaning). We only use EPA-registered antimicrobial treatments if necessary and with your explicit permission.
              </AccordionContent>
            </AccordionItem>
          </Accordion>

          <div className="text-center mt-8">
            <Link to="/faq" className="text-blue-600 font-medium hover:underline">View all FAQs</Link>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-20 bg-blue-900 text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Breathe Cleaner Air?</h2>
          <p className="text-blue-200 text-xl mb-8 max-w-2xl mx-auto">
            Schedule your service today and experience the difference of a professional, photo-verified cleaning.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-white text-blue-900 hover:bg-blue-50 font-bold h-14 px-8"
              asChild
              onClick={() => trackBookClick('footer_cta')}
            >
              <Link to="/booking">Book Online Now</Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-blue-400 text-blue-100 hover:bg-blue-800 hover:text-white h-14 px-8"
              asChild
              onClick={() => trackCallClick('footer_cta')}
            >
              <a href="tel:3213609704">Call (321) 360-9704</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Offer Modal */}
      <FreeAirCheckModal open={showAirCheckModal} onOpenChange={setShowAirCheckModal} />
    </div>
  );
};

export default Home;