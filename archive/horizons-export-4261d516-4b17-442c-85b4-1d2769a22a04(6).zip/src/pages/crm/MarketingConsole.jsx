import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter, 
  DialogDescription 
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from '@/components/ui/card';
import { CheckCircle, XCircle, AlertCircle, Loader2, Search, Calendar, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';

const MarketingConsole = () => {
  const { toast } = useToast();
  const [actions, setActions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedAction, setSelectedAction] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [processing, setProcessing] = useState(false);
  
  // New state for reviewer notes
  const [reviewerNotes, setReviewerNotes] = useState('');

  useEffect(() => {
    fetchPendingActions();
  }, []);

  const fetchPendingActions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('marketing_actions')
        .select('*, leads(first_name, last_name, email, company)')
        .eq('status', 'needs_approval')
        .order('scheduled_at', { ascending: true });

      if (error) throw error;
      setActions(data || []);
    } catch (error) {
      console.error('Error fetching actions:', error);
      toast({
        title: "Error",
        description: "Failed to load pending marketing actions.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = (item) => {
    setSelectedAction(item);
    // Preload notes if they exist (though usually empty for new approvals)
    setReviewerNotes(item.reviewer_notes || '');
    setIsModalOpen(true);
  };

  const updateStatus = async (newStatus) => {
    if (!selectedAction) return;

    setProcessing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const updates = {
        status: newStatus,
        reviewer_notes: reviewerNotes ? reviewerNotes.trim() : null,
        reviewed_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        approved_by: user?.id,
        approved_at: newStatus === 'approved' ? new Date().toISOString() : null
      };

      const { error } = await supabase
        .from('marketing_actions')
        .update(updates)
        .eq('id', selectedAction.id);

      if (error) throw error;

      toast({
        title: newStatus === 'approved' ? "Approved" : "Rejected",
        description: `Action has been ${newStatus}.`,
        variant: newStatus === 'approved' ? "default" : "destructive"
      });

      // Clear state and refresh
      setReviewerNotes('');
      setIsModalOpen(false);
      fetchPendingActions();

    } catch (error) {
      console.error('Error updating status:', error);
      toast({
        title: "Update Failed",
        description: "Could not update the action status.",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return format(new Date(dateString), 'MMM d, yyyy h:mm a');
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-6 bg-slate-50/50">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight text-[#091e39]">Marketing Console</h1>
        <p className="text-muted-foreground">
          Review and approve AI-generated content, monitor automation triggers, and manage pending actions.
        </p>
      </div>

      <div className="flex-1 min-h-0 border rounded-lg bg-white shadow-sm overflow-hidden flex flex-col">
        <div className="p-4 border-b flex justify-between items-center bg-white">
          <h2 className="font-semibold flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-amber-500" />
            Pending Approvals ({actions.length})
          </h2>
          <Button variant="outline" size="sm" onClick={fetchPendingActions} disabled={loading}>
            <span className={loading ? "animate-spin mr-2" : "mr-2"}>⟳</span> Refresh
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 bg-slate-50">
          {loading ? (
            <div className="flex items-center justify-center h-40">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : actions.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center space-y-4">
              <div className="p-4 rounded-full bg-green-100">
                <CheckCircle className="w-12 h-12 text-green-600" />
              </div>
              <div>
                <h3 className="text-lg font-medium">All Caught Up!</h3>
                <p className="text-muted-foreground">No pending marketing actions requiring approval.</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {actions.map((action) => (
                <Card key={action.id} className="flex flex-col hover:shadow-md transition-shadow border-l-4 border-l-amber-400">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <Badge variant="outline" className="mb-2">{action.type}</Badge>
                      <span className="text-xs text-muted-foreground">{formatDate(action.scheduled_at)}</span>
                    </div>
                    <CardTitle className="text-lg line-clamp-1">{action.content_preview?.split('\n')[0] || 'No Subject'}</CardTitle>
                    <CardDescription className="line-clamp-1">
                      To: {action.target_details?.name || action.leads?.first_name || 'Unknown'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 text-sm text-muted-foreground">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs">
                        <Badge variant="secondary" className="text-[10px]">{action.channel}</Badge>
                        <span>•</span>
                        <span>{action.playbook_key}</span>
                      </div>
                      <p className="line-clamp-3 italic border-l-2 pl-2 mt-2 bg-slate-50 p-2 rounded-r-sm">
                        {action.content_preview || "No content preview available."}
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2 pb-4">
                    <Button className="w-full" onClick={() => handlePreview(action)}>
                      Review Action <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Review Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Review Marketing Action</DialogTitle>
            <DialogDescription>
              Review the generated content before approving for delivery.
            </DialogDescription>
          </DialogHeader>
          
          {selectedAction && (
            <div className="space-y-6 py-4">
              {/* Target Details */}
              <div className="grid grid-cols-2 gap-4 text-sm bg-slate-50 p-3 rounded-md border">
                <div>
                  <span className="font-medium text-slate-500 block">Recipient</span>
                  {selectedAction.target_details?.name || selectedAction.leads?.first_name || 'N/A'}
                </div>
                <div>
                  <span className="font-medium text-slate-500 block">Channel</span>
                  <span className="capitalize">{selectedAction.channel}</span>
                </div>
                <div>
                  <span className="font-medium text-slate-500 block">Scheduled For</span>
                  {formatDate(selectedAction.scheduled_at)}
                </div>
                <div>
                  <span className="font-medium text-slate-500 block">Playbook</span>
                  {selectedAction.playbook_key}
                </div>
              </div>

              {/* Content Preview */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Content Preview</label>
                <div className="p-4 rounded-md border bg-white whitespace-pre-wrap font-mono text-sm">
                  {selectedAction.content_preview}
                </div>
              </div>

              {/* New Reviewer Notes Section */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
                <label className="block text-sm font-medium text-yellow-900 mb-2">
                  Internal - Coaching Notes (Optional)
                </label>
                <Textarea 
                  placeholder="Add feedback about tone, content, or why this was rejected/approved..."
                  value={reviewerNotes}
                  onChange={(e) => setReviewerNotes(e.target.value)}
                  className="bg-white mb-2"
                />
                <p className="text-xs text-yellow-700">
                  These notes are saved for your team and AI. They are NOT sent to the customer.
                </p>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button 
              variant="destructive" 
              onClick={() => updateStatus('rejected')}
              disabled={processing}
            >
              {processing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <XCircle className="w-4 h-4 mr-2" />}
              Reject
            </Button>
            <Button 
              variant="default" 
              className="bg-green-600 hover:bg-green-700"
              onClick={() => updateStatus('approved')}
              disabled={processing}
            >
              {processing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <CheckCircle className="w-4 h-4 mr-2" />}
              Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MarketingConsole;