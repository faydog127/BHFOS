
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Plus, 
  RefreshCw, 
  Loader2, 
  CheckCircle2, 
  XCircle, 
  History,
  Filter,
  ArrowRight,
  Clock,
  Search,
  Save
} from 'lucide-react';
import { format } from 'date-fns';

const PIPELINE_STAGES = [
  { value: 'new', label: 'New' },
  { value: 'qualified', label: 'Qualified' },
  { value: 'scheduled', label: 'Scheduled' },
  { value: 'job_completed', label: 'Job Done' },
  { value: 'nurture', label: 'Nurture' },
  { value: 'lost', label: 'Lost' }
];

const PERSONAS = [
  { value: 'homeowner', label: 'Homeowner' },
  { value: 'property_manager', label: 'Property Manager' },
  { value: 'realtor', label: 'Realtor' },
  { value: 'other', label: 'Other' }
];

const Leads = () => {
  const { toast } = useToast();
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Filters & Search
  const [stageFilter, setStageFilter] = useState('all');
  const [personaFilter, setPersonaFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Add Lead Modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [addFormData, setAddFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    persona: 'homeowner',
    pipelineStage: 'new',
    consentMarketing: true,
    enrollMarketing: true
  });

  // Lead Details Drawer
  const [selectedLead, setSelectedLead] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [drawerFormData, setDrawerFormData] = useState({});
  const [isUpdatingLead, setIsUpdatingLead] = useState(false);
  const [pipelineHistory, setPipelineHistory] = useState([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);

  useEffect(() => {
    fetchLeads();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stageFilter, personaFilter]);

  useEffect(() => {
    if (selectedLead) {
      fetchHistory(selectedLead.id);
    }
  }, [selectedLead]);

  const fetchLeads = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(200); // Increased limit

      if (stageFilter !== 'all') {
        query = query.eq('pipeline_stage', stageFilter);
      }
      if (personaFilter !== 'all') {
        query = query.eq('persona', personaFilter);
      }

      const { data, error } = await query;

      if (error) throw error;
      setLeads(data || []);
    } catch (error) {
      console.error('Error fetching leads:', error);
      toast({
        title: "Error",
        description: "Could not load leads list.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchHistory = async (leadId) => {
    setIsLoadingHistory(true);
    setPipelineHistory([]);
    try {
      const { data, error } = await supabase
        .from('lead_pipeline_events')
        .select('*')
        .eq('lead_id', leadId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPipelineHistory(data || []);
    } catch (error) {
      console.error('Error fetching history:', error);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  // Handlers for Add Lead Form
  const handleAddInputChange = (e) => {
    const { name, value } = e.target;
    setAddFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddSelectChange = (name, value) => {
    setAddFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddCheckboxChange = (name, checked) => {
    setAddFormData(prev => {
      const newState = { ...prev, [name]: checked };
      if (name === 'consentMarketing' && !checked) {
        newState.enrollMarketing = false;
      }
      return newState;
    });
  };

  // Handlers for Drawer/Edit Lead Form
  const handleLeadClick = (lead) => {
    setSelectedLead(lead);
    setDrawerFormData({
      firstName: lead.first_name || '',
      lastName: lead.last_name || '',
      email: lead.email || '',
      phone: lead.phone || '',
      persona: lead.persona || 'homeowner',
      pipelineStage: lead.pipeline_stage || 'new',
      consentMarketing: lead.consent_marketing || false,
      needsAiAction: lead.needs_ai_action || false
    });
    setIsDrawerOpen(true);
  };

  const handleDrawerInputChange = (e) => {
    const { name, value } = e.target;
    setDrawerFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleDrawerSelectChange = (name, value) => {
    setDrawerFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleDrawerCheckboxChange = (name, checked) => {
    setDrawerFormData(prev => {
      const newState = { ...prev, [name]: checked };
      if (name === 'consentMarketing' && !checked) {
        newState.needsAiAction = false;
      }
      return newState;
    });
  };

  const handleSaveDrawer = async () => {
    setIsUpdatingLead(true);
    try {
      const updates = {
        first_name: drawerFormData.firstName,
        last_name: drawerFormData.lastName,
        email: drawerFormData.email,
        phone: drawerFormData.phone,
        persona: drawerFormData.persona,
        pipeline_stage: drawerFormData.pipelineStage,
        consent_marketing: drawerFormData.consentMarketing,
        needs_ai_action: drawerFormData.needsAiAction,
        // Only update segment to match persona if we're still maintaining that column, otherwise ignore
        segment: drawerFormData.persona 
      };

      const { error } = await supabase
        .from('leads')
        .update(updates)
        .eq('id', selectedLead.id);

      if (error) throw error;

      toast({ title: "Lead Updated", description: "Changes saved successfully." });
      setIsDrawerOpen(false);
      fetchLeads();
    } catch (error) {
      console.error('Error updating lead:', error);
      toast({ title: "Error", description: "Failed to update lead.", variant: "destructive" });
    } finally {
      setIsUpdatingLead(false);
    }
  };

  const handleSaveNewLead = async () => {
    setIsSaving(true);
    
    if (!addFormData.firstName || !addFormData.email) {
        toast({
            title: "Validation Error",
            description: "First Name and Email are required.",
            variant: "destructive"
        });
        setIsSaving(false);
        return;
    }

    try {
      const newLead = {
        first_name: addFormData.firstName,
        last_name: addFormData.lastName,
        email: addFormData.email,
        phone: addFormData.phone,
        persona: addFormData.persona, // Using persona strictly
        segment: addFormData.persona, // Keeping sync for legacy if needed
        pipeline_stage: addFormData.pipelineStage,
        consent_marketing: addFormData.consentMarketing,
        needs_ai_action: addFormData.enrollMarketing,
        source: 'manual_entry',
        utm_source: 'manual_entry',
        status: addFormData.pipelineStage,
        pqi: 0,
      };

      const { error } = await supabase.from('leads').insert([newLead]);

      if (error) throw error;

      toast({ title: "Success", description: "Lead added successfully!" });

      setIsAddModalOpen(false);
      resetAddForm();
      fetchLeads(); 

    } catch (error) {
      console.error('Error adding lead:', error);
      toast({ title: "Error", description: error.message || "Failed to add lead.", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const resetAddForm = () => {
    setAddFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      persona: 'homeowner',
      pipelineStage: 'new',
      consentMarketing: true,
      enrollMarketing: true
    });
  };

  const updatePipelineStageInline = async (leadId, newStage) => {
    try {
      // Optimistic update
      setLeads(prev => prev.map(l => l.id === leadId ? { ...l, pipeline_stage: newStage } : l));

      const { error } = await supabase
        .from('leads')
        .update({ pipeline_stage: newStage })
        .eq('id', leadId);

      if (error) throw error;

      toast({
        title: "Stage Updated",
        description: `Lead moved to ${PIPELINE_STAGES.find(s => s.value === newStage)?.label}`,
      });
    } catch (error) {
      console.error('Error updating stage:', error);
      toast({
        title: "Update Failed",
        description: "Could not update pipeline stage.",
        variant: "destructive"
      });
      fetchLeads(); // Revert on error
    }
  };

  // Helper function for normalizing search values
  const normalize = (value) =>
    (value || '').toString().toLowerCase().trim();

  // Client-side filtering
  const filteredLeads = leads.filter((lead) => {
    const q = normalize(searchQuery);
    if (!q) return true;

    return (
      normalize(lead.first_name).includes(q) ||
      normalize(lead.last_name).includes(q) ||
      normalize(lead.email).includes(q) ||
      normalize(lead.phone).includes(q)
    );
  });

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      <Helmet>
        <title>Leads & Pipeline | CRM</title>
      </Helmet>

      {/* Header & Controls */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Leads & Pipeline Manager</h1>
          <p className="text-gray-500">Manage lead stages, track history, and control marketing automation.</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 w-full xl:w-auto items-center">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search leads..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
            </div>

            {/* Filters */}
            <div className="flex gap-2 bg-white p-1 rounded-md border shadow-sm">
                <div className="flex items-center px-2 border-r">
                    <Filter className="h-4 w-4 text-slate-400" />
                </div>
                <Select value={stageFilter} onValueChange={setStageFilter}>
                    <SelectTrigger className="w-[140px] h-8 border-0 focus:ring-0">
                        <SelectValue placeholder="All Stages" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Stages</SelectItem>
                        {PIPELINE_STAGES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                    </SelectContent>
                </Select>
                <Select value={personaFilter} onValueChange={setPersonaFilter}>
                    <SelectTrigger className="w-[150px] h-8 border-0 focus:ring-0">
                        <SelectValue placeholder="All Personas" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Personas</SelectItem>
                        {PERSONAS.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>

            <div className="flex gap-2">
                <Button variant="outline" onClick={fetchLeads} disabled={loading}>
                    <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                    Refresh
                </Button>
                <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
                <DialogTrigger asChild>
                    <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Lead
                    </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                    <DialogTitle>Add New Lead</DialogTitle>
                    <DialogDescription>
                        Manually register a lead.
                    </DialogDescription>
                    </DialogHeader>
                    
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="firstName">First Name *</Label>
                                <Input 
                                    id="firstName" 
                                    name="firstName" 
                                    value={addFormData.firstName} 
                                    onChange={handleAddInputChange} 
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="lastName">Last Name</Label>
                                <Input 
                                    id="lastName" 
                                    name="lastName" 
                                    value={addFormData.lastName} 
                                    onChange={handleAddInputChange} 
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="email">Email *</Label>
                            <Input 
                                id="email" 
                                name="email" 
                                type="email"
                                value={addFormData.email} 
                                onChange={handleAddInputChange} 
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="phone">Phone</Label>
                            <Input 
                                id="phone" 
                                name="phone" 
                                value={addFormData.phone} 
                                onChange={handleAddInputChange} 
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label>Segment (Persona)</Label>
                                <Select 
                                    value={addFormData.persona} 
                                    onValueChange={(val) => handleAddSelectChange('persona', val)}
                                >
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {PERSONAS.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label>Initial Stage</Label>
                                <Select 
                                    value={addFormData.pipelineStage} 
                                    onValueChange={(val) => handleAddSelectChange('pipelineStage', val)}
                                >
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {PIPELINE_STAGES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="bg-slate-50 p-3 rounded-lg space-y-3 mt-2 border">
                            <div className="flex items-start space-x-2">
                                <Checkbox 
                                    id="consentMarketing" 
                                    checked={addFormData.consentMarketing}
                                    onCheckedChange={(checked) => handleAddCheckboxChange('consentMarketing', checked)}
                                />
                                <div className="grid gap-1.5 leading-none">
                                    <Label htmlFor="consentMarketing" className="text-sm font-medium cursor-pointer">
                                        Has given consent for marketing follow-up
                                    </Label>
                                    <p className="text-xs text-muted-foreground">Required for any automated outreach.</p>
                                </div>
                            </div>
                            <div className="flex items-start space-x-2">
                                <Checkbox 
                                    id="enrollMarketing" 
                                    checked={addFormData.enrollMarketing}
                                    onCheckedChange={(checked) => handleAddCheckboxChange('enrollMarketing', checked)}
                                    disabled={!addFormData.consentMarketing}
                                />
                                <div className="grid gap-1.5 leading-none">
                                    <Label htmlFor="enrollMarketing" className={`text-sm font-medium cursor-pointer ${!addFormData.consentMarketing ? 'text-gray-400' : ''}`}>
                                        Enroll in Marketing Factory
                                    </Label>
                                    <p className="text-xs text-muted-foreground">Automatically triggers "Welcome" & "Nurture" playbooks.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <DialogFooter>
                    <Button variant="ghost" onClick={() => { setIsAddModalOpen(false); resetAddForm(); }}>Cancel</Button>
                    <Button onClick={handleSaveNewLead} disabled={isSaving}>
                        {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save Lead
                    </Button>
                    </DialogFooter>
                </DialogContent>
                </Dialog>
            </div>
        </div>
      </div>

      {/* Data Table */}
      <div className="rounded-md border bg-white shadow-sm">
        <Table>
            <TableHeader>
                <TableRow className="bg-slate-50/50">
                    <TableHead className="w-[250px]">Lead Details</TableHead>
                    <TableHead>Segment</TableHead>
                    <TableHead>Pipeline Stage</TableHead>
                    <TableHead className="text-center">Marketing</TableHead>
                    <TableHead className="text-center">AI Enrollment</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {loading ? (
                    <TableRow>
                        <TableCell colSpan={6} className="h-32 text-center">
                            <div className="flex justify-center items-center gap-2 text-gray-500">
                                <Loader2 className="h-5 w-5 animate-spin text-primary" /> Loading pipeline...
                            </div>
                        </TableCell>
                    </TableRow>
                ) : filteredLeads.length === 0 ? (
                    <TableRow>
                        <TableCell colSpan={6} className="h-32 text-center text-gray-500">
                            No leads found matching your criteria.
                        </TableCell>
                    </TableRow>
                ) : (
                    filteredLeads.map((lead) => (
                        <TableRow 
                            key={lead.id} 
                            className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                            onClick={() => handleLeadClick(lead)}
                        >
                            <TableCell>
                                <div className="font-medium text-gray-900">
                                    {lead.first_name} {lead.last_name}
                                </div>
                                <div className="text-xs text-gray-500 flex items-center gap-1">
                                    {lead.email}
                                </div>
                                {lead.phone && <div className="text-xs text-gray-400 mt-0.5">{lead.phone}</div>}
                            </TableCell>
                            <TableCell>
                                <Badge variant="outline" className="font-normal capitalize bg-white text-slate-600">
                                    {lead.persona || 'Unknown'}
                                </Badge>
                            </TableCell>
                            <TableCell onClick={(e) => e.stopPropagation()}>
                                <Select 
                                    defaultValue={lead.pipeline_stage || 'new'} 
                                    onValueChange={(val) => updatePipelineStageInline(lead.id, val)} 
                                >
                                    <SelectTrigger className="h-8 w-[140px] bg-white">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {PIPELINE_STAGES.map(stage => (
                                            <SelectItem key={stage.value} value={stage.value}>
                                                <span className="flex items-center gap-2">
                                                    <span className={`h-2 w-2 rounded-full ${
                                                        stage.value === 'lost' ? 'bg-red-400' :
                                                        stage.value === 'job_completed' ? 'bg-green-500' :
                                                        stage.value === 'new' ? 'bg-blue-400' :
                                                        'bg-slate-300'
                                                    }`} />
                                                    {stage.label}
                                                </span>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </TableCell>
                            <TableCell className="text-center">
                                {lead.consent_marketing ? (
                                    <CheckCircle2 className="h-5 w-5 text-green-500 mx-auto" />
                                ) : (
                                    <XCircle className="h-5 w-5 text-slate-200 mx-auto" />
                                )}
                            </TableCell>
                            <TableCell className="text-center">
                                {lead.needs_ai_action ? (
                                    <Badge className="bg-indigo-100 text-indigo-700 hover:bg-indigo-200 border-0">Active</Badge>
                                ) : (
                                    <span className="text-xs text-slate-400">-</span>
                                )}
                            </TableCell>
                            <TableCell className="text-right">
                                <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-8 w-8 p-0 hover:bg-indigo-50 hover:text-indigo-600"
                                >
                                    <ArrowRight className="h-4 w-4" />
                                    <span className="sr-only">View Details</span>
                                </Button>
                            </TableCell>
                        </TableRow>
                    ))
                )}
            </TableBody>
        </Table>
      </div>

      {/* Lead Details Sheet */}
      <Sheet open={isDrawerOpen} onOpenChange={setIsDrawerOpen}>
        <SheetContent className="w-[400px] sm:w-[540px] overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Lead Details</SheetTitle>
            <SheetDescription>
              View and edit lead information and history.
            </SheetDescription>
          </SheetHeader>

          <div className="py-6 space-y-6">
            {/* Contact Info Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Contact Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-firstName">First Name</Label>
                  <Input id="edit-firstName" name="firstName" value={drawerFormData.firstName} onChange={handleDrawerInputChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-lastName">Last Name</Label>
                  <Input id="edit-lastName" name="lastName" value={drawerFormData.lastName} onChange={handleDrawerInputChange} />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">Email</Label>
                <Input id="edit-email" name="email" value={drawerFormData.email} onChange={handleDrawerInputChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-phone">Phone</Label>
                <Input id="edit-phone" name="phone" value={drawerFormData.phone} onChange={handleDrawerInputChange} />
              </div>
            </div>

            <div className="h-px bg-slate-100" />

            {/* Segmentation & Pipeline */}
            <div className="space-y-4">
               <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Pipeline & Segment</h3>
               <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Segment (Persona)</Label>
                    <Select value={drawerFormData.persona} onValueChange={(val) => handleDrawerSelectChange('persona', val)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PERSONAS.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Pipeline Stage</Label>
                    <Select value={drawerFormData.pipelineStage} onValueChange={(val) => handleDrawerSelectChange('pipelineStage', val)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PIPELINE_STAGES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
               </div>
               <div className="space-y-2">
                  <Label>Source</Label>
                  <Input value={selectedLead?.source || 'Unknown'} disabled className="bg-slate-50 text-slate-500" />
               </div>
            </div>

            <div className="h-px bg-slate-100" />

            {/* Automation Settings */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Automation Settings</h3>
              <div className="bg-slate-50 p-3 rounded-lg space-y-3 border">
                  <div className="flex items-center space-x-2">
                      <Checkbox 
                          id="edit-consentMarketing" 
                          checked={drawerFormData.consentMarketing}
                          onCheckedChange={(checked) => handleDrawerCheckboxChange('consentMarketing', checked)}
                      />
                      <Label htmlFor="edit-consentMarketing" className="font-medium cursor-pointer">
                          Has given consent for marketing follow-up
                      </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                      <Checkbox 
                          id="edit-needsAiAction" 
                          checked={drawerFormData.needsAiAction}
                          onCheckedChange={(checked) => handleDrawerCheckboxChange('needsAiAction', checked)}
                          disabled={!drawerFormData.consentMarketing}
                      />
                      <Label htmlFor="edit-needsAiAction" className={`font-medium cursor-pointer ${!drawerFormData.consentMarketing ? 'text-gray-400' : ''}`}>
                          Enroll in Marketing Factory
                      </Label>
                  </div>
              </div>
            </div>

            <div className="flex justify-end">
               <Button onClick={handleSaveDrawer} disabled={isUpdatingLead} className="w-full sm:w-auto">
                  {isUpdatingLead && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
               </Button>
            </div>

            <div className="h-px bg-slate-100" />

            {/* Pipeline History */}
            <div className="space-y-4">
               <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                 <History className="h-4 w-4" /> Pipeline History
               </h3>
               
               {isLoadingHistory ? (
                 <div className="text-center py-8 text-muted-foreground">Loading history...</div>
               ) : pipelineHistory.length === 0 ? (
                 <div className="text-center py-8 bg-slate-50 rounded-lg text-muted-foreground text-sm">
                   No stage changes recorded yet.
                 </div>
               ) : (
                 <div className="relative border-l-2 border-indigo-100 ml-2 space-y-6 py-2">
                   {pipelineHistory.map((event, idx) => (
                     <div key={event.id || idx} className="relative pl-6">
                        <div className="absolute -left-[5px] top-1.5 h-2.5 w-2.5 rounded-full border border-white bg-indigo-400 shadow-sm" />
                        <div className="text-sm text-gray-900">
                          {event.from_stage ? (
                            <span>Moved from <span className="font-medium capitalize">{event.from_stage}</span> to <span className="font-medium capitalize text-indigo-600">{event.to_stage}</span></span>
                          ) : (
                            <span>Lead created in <span className="font-medium capitalize text-indigo-600">{event.to_stage}</span></span>
                          )}
                        </div>
                        <div className="text-xs text-gray-500 mt-0.5">
                          {format(new Date(event.created_at), 'MMM d, yyyy h:mm a')} • {event.source || 'system'}
                        </div>
                     </div>
                   ))}
                 </div>
               )}
            </div>

          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default Leads;
