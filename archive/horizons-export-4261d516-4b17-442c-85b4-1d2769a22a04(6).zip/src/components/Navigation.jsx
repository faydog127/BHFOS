import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Phone, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { trackCallClick, trackBookClick } from '@/lib/tracking';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  const handleBookClick = (placement) => {
    trackBookClick(placement);
    setIsOpen(false);
  };

  const handleCallClick = (placement) => {
    trackCallClick(placement);
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Partners', path: '/partners' }, // Added Partners link
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50 border-b border-slate-100">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16 md:h-20">
          
          {/* Logo */}
          <Link to="/" className="flex items-center site-logo" onClick={() => setIsOpen(false)}>
            <img 
              src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/c042e0bf3434dbac49b80f9dc3eaa54a.png" 
              alt="The Vent Guys - We Clear What Others Miss" 
              className="h-[64.4px] md:h-[73.6px] w-auto" // Increased by 15% (56px * 1.15 = 64.4px, 64px * 1.15 = 73.6px)
            />
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex space-x-8">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                to={link.path} 
                className="text-slate-600 hover:text-blue-800 font-medium transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Desktop Right Side */}
          <div className="hidden md:flex items-center gap-4">
            <a 
              href="tel:3213609704" 
              onClick={() => handleCallClick('header_desktop')}
              className="flex items-center gap-2 text-slate-700 hover:text-blue-700 font-semibold transition-colors"
            >
              <Phone className="w-4 h-4" />
              (321) 360-9704
            </a>
            <Button asChild onClick={() => handleBookClick('header_desktop')}>
              <Link to="/booking">Book Online</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="text-slate-700 p-2 focus:outline-none"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 absolute w-full shadow-lg animate-in slide-in-from-top-5">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                to={link.path} 
                className="text-lg font-medium text-slate-800 py-2 border-b border-slate-50"
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </Link>
            ))}
            <div className="flex flex-col gap-3 pt-2">
              <a 
                href="tel:3213609704" 
                className="flex items-center justify-center gap-2 w-full py-3 bg-slate-100 text-slate-800 rounded-md font-semibold"
                onClick={() => handleCallClick('header_mobile_menu')}
              >
                <Phone className="w-5 h-5" />
                Call (321) 360-9704
              </a>
              <Button className="w-full py-6 text-lg" asChild onClick={() => handleBookClick('header_mobile_menu')}>
                <Link to="/booking">
                  <Calendar className="w-5 h-5 mr-2" />
                  Book Online
                </Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navigation;