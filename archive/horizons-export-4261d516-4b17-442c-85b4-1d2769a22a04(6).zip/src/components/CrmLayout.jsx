
import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Home, List, Phone, BarChart2, Mail, Calendar, Settings, Users, ClipboardList, Target, UserCheck } from 'lucide-react';

const CrmLayout = ({ children }) => {
    const navLinks = [
        { to: '/crm/dashboard', icon: Home, label: 'Dashboard' },
        { to: '/crm/leads', icon: List, label: 'Leads & Pipeline' },
        { to: '/crm/console', icon: Phone, label: 'Call Console' },
        { to: '/crm/action-hub', icon: ClipboardList, label: 'Action Hub' },
        { to: '/crm/inbox', icon: Mail, label: 'Inbox' },
        { to: '/crm/schedule', icon: Calendar, label: 'Schedule' },
        { to: '/crm/marketing', icon: Target, label: 'Marketing' },
        { to: '/crm/reporting', icon: BarChart2, label: 'Reporting' },
        { to: '/crm/partner-submissions', icon: UserCheck, label: 'Partner Submissions' },
    ];
    
    const adminLinks = [
        { to: '/crm/admin', icon: Users, label: 'User Admin' },
        { to: '/crm/metrics', icon: BarChart2, label: 'Metrics' },
        { to: '/crm/settings', icon: Settings, label: 'Settings' },
    ];

    const activeLinkClass = "bg-blue-800 text-white";
    const inactiveLinkClass = "text-gray-300 hover:bg-gray-700 hover:text-white";

    return (
        <div className="h-screen flex bg-gray-100">
            <aside className="w-64 bg-gray-800 text-white flex flex-col">
                <div className="h-16 flex items-center justify-center text-2xl font-bold border-b border-gray-700 shrink-0">
                    <span className="text-blue-400">TVG</span>-CRM
                </div>
                <nav className="flex-1 px-2 py-4 space-y-2 overflow-y-auto">
                    {navLinks.map(({ to, icon: Icon, label }) => (
                        <NavLink
                            key={to}
                            to={to}
                            className={({ isActive }) =>
                                `flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${isActive ? activeLinkClass : inactiveLinkClass}`
                            }
                        >
                            <Icon className="mr-3 h-5 w-5" />
                            {label}
                        </NavLink>
                    ))}
                    
                    <div className="pt-4 mt-4 border-t border-gray-700">
                        <h3 className="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Admin Portal</h3>
                        <div className="mt-2 space-y-2">
                            {adminLinks.map(({ to, icon: Icon, label }) => (
                                <NavLink
                                    key={to}
                                    to={to}
                                    className={({ isActive }) =>
                                        `flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${isActive ? activeLinkClass : inactiveLinkClass}`
                                    }
                                >
                                    <Icon className="mr-3 h-5 w-5" />
                                    {label}
                                </NavLink>
                            ))}
                        </div>
                    </div>
                </nav>
                <div className="px-4 py-4 border-t border-gray-700 shrink-0">
                    <div className="text-sm text-gray-400 truncate">Public Access Mode</div>
                </div>
            </aside>
            <div className="flex-1 flex flex-col overflow-hidden">
                <main className="flex-1 overflow-x-hidden overflow-y-auto">
                    {children || <Outlet />}
                </main>
            </div>
        </div>
    );
};

export default CrmLayout;
