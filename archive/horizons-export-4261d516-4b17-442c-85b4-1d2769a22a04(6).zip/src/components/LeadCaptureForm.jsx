import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Send, Loader2, AlertCircle } from 'lucide-react';
import { LEAD_CAPTURE_API_URL } from '@/lib/constants';
import { sanitizeInput, validateEmail, validatePhone, formatPhoneNumber, checkRateLimit } from '@/lib/security';
import AddressAutocomplete from '@/components/AddressAutocomplete';

export default function LeadCaptureForm({
  formType = 'free-air-check',
  onSuccess = () => {}
}) {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null);
  const [message, setMessage] = useState('');
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    phone: '',
    email: '',
    address: '',
    message: '',
    consent_marketing: false,
  });
  const [errors, setErrors] = useState({});

  const navigate = useNavigate();

  const formTypeConfig = {
    'free-air-check': {
      service_type: 'IAQ Check',
      source_kind: 'WEBSITE',
      source_detail: 'Free Air Check Form',
      customer_type: 'RESIDENTIAL',
      persona: 'HOMEOWNER_PREBOOK',
    },
    'contact': {
      service_type: 'Other',
      source_kind: 'WEBSITE',
      source_detail: 'Contact Form',
      customer_type: 'RESIDENTIAL',
      persona: 'HOMEOWNER_INQUIRY',
    },
  };

  const config = formTypeConfig[formType] || formTypeConfig['free-air-check'];

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.first_name.trim()) {
      newErrors.first_name = 'First name is required.';
    }
    
    if (!validatePhone(formData.phone)) {
      newErrors.phone = 'Valid US phone number (555) 555-5555 is required.';
    }
    
    if (formData.email && !validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    let finalValue = type === 'checkbox' ? checked : value;
    
    // Apply formatting for phone
    if (name === 'phone') {
        finalValue = formatPhoneNumber(value);
    }

    // Sanitize text inputs on change (optional, but prevents pasting huge XSS vectors)
    if (type === 'text' || type === 'textarea') {
        // We don't sanitize strictly on change to allow typing, we sanitize on submit
        // But we can prevent certain chars if needed. For now, we just store raw.
    }

    setFormData((prev) => ({
      ...prev,
      [name]: finalValue,
    }));
    
    // Clear error when user types
    if (errors[name]) {
        setErrors(prev => ({...prev, [name]: ''}));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Rate Limiting
    if (!checkRateLimit('lead_capture', 3000)) {
        setStatus('error');
        setMessage('You are submitting too fast. Please wait a moment.');
        return;
    }

    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    setStatus(null);
    setMessage('');

    try {
      // Sanitize all inputs before sending
      const payload = {
        first_name: sanitizeInput(formData.first_name),
        last_name: sanitizeInput(formData.last_name),
        phone: formData.phone, // Already validated format
        email: formData.email, // Already validated format
        property_name: sanitizeInput(formData.address), 
        message: sanitizeInput(formData.message),
        service_type: config.service_type,
        customer_type: config.customer_type,
        source_kind: config.source_kind,
        source_detail: config.source_detail,
        landing_page_url: window.location.href,
        utm_source: sanitizeInput(new URLSearchParams(window.location.search).get('utm_source')),
        consent_marketing: formData.consent_marketing,
        status: 'OPEN',
        persona: config.persona,
        pqi: 25,
      };

      const response = await fetch(LEAD_CAPTURE_API_URL, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind3eXhvaGpueXFuZWd6Ynh0dXhzIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODg2NjkxODcsImV4cCI6MjAwNDI0NTE4N30.i-22y2hD_7f_A5YGDpQz6eRmsy-4eB4021t5Zg_LwG0'
         },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error('Submission failed.');
      }

      setStatus('success');
      setMessage('✓ Thank you! We received your request and will contact you shortly.');
      setFormData({
        first_name: '', last_name: '', phone: '', email: '', address: '', message: '', consent_marketing: false,
      });
      onSuccess();
      
      setTimeout(() => {
        navigate('/thank-you');
      }, 1000);

    } catch (err) {
      console.error('Form submission error:', err);
      setStatus('error');
      setMessage('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="first_name">First Name *</Label>
          <Input id="first_name" name="first_name" value={formData.first_name} onChange={handleChange} required placeholder="John" disabled={loading} />
          {errors.first_name && <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3"/>{errors.first_name}</p>}
        </div>
        <div>
          <Label htmlFor="last_name">Last Name</Label>
          <Input id="last_name" name="last_name" value={formData.last_name} onChange={handleChange} placeholder="Doe" disabled={loading} />
        </div>
      </div>
      <div>
        <Label htmlFor="phone">Phone *</Label>
        <Input id="phone" type="tel" name="phone" inputMode="numeric" value={formData.phone} onChange={handleChange} required placeholder="(321) 555-1234" disabled={loading} maxLength="14" />
        {errors.phone && <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3"/>{errors.phone}</p>}
      </div>
       <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" type="email" name="email" value={formData.email} onChange={handleChange} placeholder="john@example.com" disabled={loading} />
        {errors.email && <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3"/>{errors.email}</p>}
      </div>
      <div>
        <Label htmlFor="address">Property Address</Label>
        <AddressAutocomplete id="address" name="address" value={formData.address} onChange={handleChange} disabled={loading} />
      </div>
      <div>
        <Label htmlFor="message">Message</Label>
        <Textarea id="message" name="message" value={formData.message} onChange={handleChange} rows={3} placeholder="Tell us about your air quality concerns..." disabled={loading} />
      </div>
      <div className="flex items-center space-x-2">
        <Checkbox id="consent_marketing" name="consent_marketing" checked={formData.consent_marketing} onCheckedChange={(checked) => setFormData(p => ({...p, consent_marketing: checked}))} disabled={loading} />
        <Label htmlFor="consent_marketing" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
            I consent to marketing communications
        </Label>
      </div>

      {status && (
        <div className={`mt-4 p-3 rounded-md text-sm font-medium ${ status === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }`}>
          {message}
        </div>
      )}

      <Button type="submit" size="lg" className="w-full bg-[#D7263D] hover:bg-[#b51f31] text-white mt-4" disabled={loading}>
        {loading ? <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Sending...</> : <><Send className="mr-2 h-5 w-5" /> Request My Free Check</>}
      </Button>
    </form>
  );
}