import React, { useEffect, useRef, useState } from 'react';
import { Input } from '@/components/ui/input';
import { MapPin } from 'lucide-react';

const AddressAutocomplete = ({ value, onChange, className, ...props }) => {
  const inputRef = useRef(null);
  const [inputValue, setInputValue] = useState(value || '');
  const [isGoogleLoaded, setIsGoogleLoaded] = useState(false);

  // Sync internal state with prop
  useEffect(() => {
    setInputValue(value || '');
  }, [value]);

  // Check for Google Maps API
  useEffect(() => {
    if (window.google && window.google.maps && window.google.maps.places) {
      setIsGoogleLoaded(true);
      
      const autocomplete = new window.google.maps.places.Autocomplete(inputRef.current, {
        types: ['address'],
        componentRestrictions: { country: 'us' },
        fields: ['formatted_address']
      });

      autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        if (place.formatted_address) {
          setInputValue(place.formatted_address);
          onChange({ target: { name: props.name, value: place.formatted_address } });
        }
      });
    }
  }, [onChange, props.name]);

  const handleChange = (e) => {
    setInputValue(e.target.value);
    onChange(e);
  };

  return (
    <div className="relative">
      <Input
        ref={inputRef}
        value={inputValue}
        onChange={handleChange}
        className={`${className} ${isGoogleLoaded ? 'pl-9' : ''}`}
        placeholder={props.placeholder || "Start typing address..."}
        {...props}
      />
      {isGoogleLoaded && (
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
      )}
      {!isGoogleLoaded && (
         // Hint for developer/user in development mode if key is missing
         <span className="sr-only">Google Places API not loaded. Standard text input enabled.</span>
      )}
    </div>
  );
};

export default AddressAutocomplete;