import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, CheckCircle2, AlertCircle, XCircle } from 'lucide-react';
import { validateEmail, formatPhoneNumber } from '@/lib/security';

const FreeAirCheckModal = ({ open, onOpenChange }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [submitError, setSubmitError] = useState(null); // New state for submission errors
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    notes: ''
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { id, value } = e.target;
    let finalValue = value;

    // Auto-format phone number as user types
    if (id === 'phone') {
        finalValue = formatPhoneNumber(value);
    }

    setFormData(prev => ({ ...prev, [id]: finalValue }));
    
    // Clear specific field error when user fixes it
    if (errors[id]) {
        setErrors(prev => ({ ...prev, [id]: null }));
    }
    // Clear general submission error when user types
    if (submitError) {
        setSubmitError(null);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    const { name, email, phone, address } = formData;

    console.log('🔍 Validating form data:', { name, email, phone, address });

    if (!name || !name.trim()) {
        newErrors.name = "Name is required";
    }

    if (!address || !address.trim()) {
        newErrors.address = "Property address is required";
    }
    
    if (!email || !email.trim()) {
        newErrors.email = "Email is required";
    } else if (!validateEmail(email)) {
        newErrors.email = "Please enter a valid email address";
    }

    if (!phone || !phone.trim()) {
        newErrors.phone = "Phone number is required";
    } else {
        const digits = phone.replace(/\D/g, '');
        if (digits.length < 10) {
             newErrors.phone = "Please enter a valid 10-digit phone number";
        }
    }

    setErrors(newErrors);
    const isValid = Object.keys(newErrors).length === 0;
    console.log(`🔍 Validation result: ${isValid ? 'PASSED' : 'FAILED'}`, newErrors);
    return isValid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitError(null);
    
    console.log("🚀 Submit button clicked. Starting submission process...");

    if (!validateForm()) {
        console.warn("❌ Validation failed", errors);
        toast({
            title: "Check your information",
            description: "Please fix the highlighted errors before submitting.",
            variant: "destructive"
        });
        return;
    }

    setLoading(true);
    
    try {
      // Split name for storage
      const nameParts = formData.name.trim().split(' ');
      const firstName = nameParts[0];
      const lastName = nameParts.slice(1).join(' ') || '';

      console.log('📝 Constructing payload...');

      const payload = {
        first_name: firstName,
        last_name: lastName,
        email: formData.email,
        phone: formData.phone,
        message: `Address: ${formData.address}\nNotes: ${formData.notes || 'None'}`,
        service: 'Free Air Check',
        source_kind: 'website_home_offer',
        status: 'New',
        marketing_source_detail: 'Home Page Modal',
        consent_marketing: true,
        // Required fields for database constraints
        persona: 'homeowner',
        utm_source: 'website_direct',
        pqi: 10
      };

      console.log('📦 Payload ready for Supabase:', payload);

      const { data, error } = await supabase
        .from('leads')
        .insert([payload])
        .select();

      if (error) {
        console.error('❌ Supabase returned error:', error);
        // Set the error state to display in UI
        setSubmitError(error.message || "Database error occurred");
        throw error;
      }

      console.log('✅ Lead inserted successfully. Response data:', data);
      setSuccess(true);
      
      toast({
        title: "Request Received!",
        description: "We'll be in touch shortly to schedule your Free Air Check.",
      });

      // Close modal after 2.5 seconds
      setTimeout(() => {
         console.log("🔒 Auto-closing modal timer fired.");
         onOpenChange(false);
         // Reset form state after closing
         setTimeout(() => {
            setSuccess(false);
            setFormData({ name: '', email: '', phone: '', address: '', notes: '' });
            setSubmitError(null);
         }, 300);
      }, 2500);

    } catch (error) {
      console.error('❌ Submission Exception caught:', error);
      // Ensure error is set if it wasn't already
      if (!submitError) {
          setSubmitError(error.message || "An unexpected error occurred");
      }
      
      toast({
        title: "Submission Error",
        description: "There was a problem submitting your request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
      console.log("🏁 Submission process finished (loading set to false).");
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    if (success) {
       setTimeout(() => {
          setSuccess(false);
          setFormData({ name: '', email: '', phone: '', address: '', notes: '' });
          setSubmitError(null);
       }, 300);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        {success ? (
          <div className="py-12 text-center flex flex-col items-center justify-center space-y-4 animate-in fade-in zoom-in duration-300">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <DialogTitle className="text-2xl">You're All Set!</DialogTitle>
            <DialogDescription className="text-center max-w-xs">
              We have received your request. A member of our team will call you at <strong>{formData.phone}</strong> shortly to confirm a time.
            </DialogDescription>
            <Button onClick={handleClose} className="mt-4">Close</Button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Schedule Your Free Air Check</DialogTitle>
              <DialogDescription>
                Fill out the form below to book your no-obligation inspection.
              </DialogDescription>
            </DialogHeader>
            
            {submitError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md flex items-start gap-3 animate-in slide-in-from-top-2">
                    <XCircle className="w-5 h-5 mt-0.5 shrink-0 text-red-600" />
                    <div className="text-sm">
                        <p className="font-semibold">Submission Failed</p>
                        <p>{submitError}</p>
                    </div>
                </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name" className={errors.name ? "text-red-500" : ""}>Full Name *</Label>
                <Input 
                    id="name" 
                    value={formData.name} 
                    onChange={handleChange} 
                    placeholder="John Doe" 
                    className={errors.name ? "border-red-500 focus-visible:ring-red-500" : ""}
                />
                {errors.name && <p className="text-xs text-red-500 flex items-center mt-1 animate-in slide-in-from-top-1"><AlertCircle className="w-3 h-3 mr-1"/> {errors.name}</p>}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="phone" className={errors.phone ? "text-red-500" : ""}>Phone Number *</Label>
                    <Input 
                        id="phone" 
                        type="tel" 
                        value={formData.phone} 
                        onChange={handleChange} 
                        placeholder="(321) 555-0123"
                        maxLength={14}
                        className={errors.phone ? "border-red-500 focus-visible:ring-red-500" : ""}
                    />
                    {errors.phone && <p className="text-xs text-red-500 flex items-center mt-1 animate-in slide-in-from-top-1"><AlertCircle className="w-3 h-3 mr-1"/> {errors.phone}</p>}
                </div>
                <div className="space-y-2">
                    <Label htmlFor="email" className={errors.email ? "text-red-500" : ""}>Email Address *</Label>
                    <Input 
                        id="email" 
                        type="email" 
                        value={formData.email} 
                        onChange={handleChange} 
                        placeholder="john@example.com" 
                        className={errors.email ? "border-red-500 focus-visible:ring-red-500" : ""}
                    />
                    {errors.email && <p className="text-xs text-red-500 flex items-center mt-1 animate-in slide-in-from-top-1"><AlertCircle className="w-3 h-3 mr-1"/> {errors.email}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className={errors.address ? "text-red-500" : ""}>Property Address *</Label>
                <Input 
                    id="address" 
                    value={formData.address} 
                    onChange={handleChange} 
                    placeholder="123 Main St, Melbourne, FL" 
                    className={errors.address ? "border-red-500 focus-visible:ring-red-500" : ""}
                />
                {errors.address && <p className="text-xs text-red-500 flex items-center mt-1 animate-in slide-in-from-top-1"><AlertCircle className="w-3 h-3 mr-1"/> {errors.address}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Textarea id="notes" value={formData.notes} onChange={handleChange} placeholder="Gate code, specific concerns, preferred times..." />
              </div>

              <DialogFooter className="pt-4">
                <Button type="button" variant="outline" onClick={handleClose} disabled={loading}>Cancel</Button>
                <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
                  {loading ? (
                    <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...
                    </>
                  ) : (
                    "Book Free Inspection"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default FreeAirCheckModal;