# Project Audit: Structure & Database

## 3. Directory Tree