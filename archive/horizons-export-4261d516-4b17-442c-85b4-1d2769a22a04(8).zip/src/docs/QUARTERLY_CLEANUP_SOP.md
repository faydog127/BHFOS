# Quarterly Test Data Cleanup SOP

**Frequency:** Every 3 Months
**Role:** Admin / Operations Manager

**Objective:** Prevent test data bloat and ensure metrics remain accurate.

---

## 1. Analysis
Run the following queries in the Supabase SQL Editor to assess the volume of test data.