
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { 
  ArrowRight, CheckCircle2, AlertTriangle, Zap, Smartphone, 
  Layout, Eye, MousePointerClick, ShieldAlert, Sparkles, ScanLine
} from 'lucide-react';
import { scoreModule, getScoreColor, DIMENSIONS } from '@/services/uiuxScorer';
import { useSystemHealth } from '@/hooks/useSystemHealth';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

const ImprovementAnalysis = () => {
  const navigate = useNavigate();
  const { moduleHealth, runDiagnostics } = useSystemHealth();
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState(null);

  useEffect(() => {
    if (!moduleHealth) {
      runDiagnostics();
    }
  }, []);

  const runAnalysis = () => {
    setAnalyzing(true);
    
    // Simulate deep analysis delay
    setTimeout(() => {
      const modules = moduleHealth?.modules || [
        { name: 'Smart Call Console', status: 'healthy' },
        { name: 'Leads Manager', status: 'healthy' },
        { name: 'Invoices', status: 'healthy' },
        { name: 'Master Diagnostics', status: 'healthy' }
      ];

      const scoredModules = modules.map(m => scoreModule(m.name, m));
      
      // Generate global opportunities
      const opportunities = [
        {
          id: 1,
          category: 'Consistency',
          title: 'Standardize Button Variants',
          description: 'Detected 4 different styles for primary actions. Consolidate to standard shadcn/ui variants.',
          impact: 'High',
          effort: 'Low',
          priority: 'Medium'
        },
        {
          id: 2,
          category: 'Accessibility',
          title: 'Missing ARIA Labels on Icon Buttons',
          description: '12 icon-only buttons found without aria-label attributes.',
          impact: 'High',
          effort: 'Low',
          priority: 'Critical'
        },
        {
          id: 3,
          category: 'Performance',
          title: 'Large Bundle Size on Dashboard',
          description: 'Initial load > 2.5MB. Implement lazy loading for chart components.',
          impact: 'Medium',
          effort: 'Medium',
          priority: 'High'
        },
        {
          id: 4,
          category: 'Mobile UX',
          title: 'Table Horizontal Scrolling',
          description: 'Tables in Leads and Jobs require awkward scrolling on mobile. Consider card view fallback.',
          impact: 'High',
          effort: 'High',
          priority: 'High'
        },
         {
          id: 5,
          category: 'Design',
          title: 'Inconsistent Spacing System',
          description: 'Margins vary between 4px, 5px, 8px, 10px. Standardize to 4/8/16px grid.',
          impact: 'Low',
          effort: 'Medium',
          priority: 'Low'
        }
      ];

      // Calculate aggregates
      const totalCurrentScore = scoredModules.reduce((acc, m) => acc + m.overallScore, 0) / scoredModules.length;
      const estimatedImprovement = 15; // Mock improvement potential

      setAnalysisResults({
        scoredModules,
        opportunities,
        metrics: {
          currentHealth: Math.round(totalCurrentScore),
          potentialHealth: Math.min(100, Math.round(totalCurrentScore + estimatedImprovement)),
          totalEffortHours: 45
        }
      });

      setAnalyzing(false);
    }, 1500);
  };

  const getPriorityBadge = (priority) => {
    switch(priority.toLowerCase()) {
      case 'critical': return <Badge variant="destructive">Critical</Badge>;
      case 'high': return <Badge className="bg-orange-500 hover:bg-orange-600">High</Badge>;
      case 'medium': return <Badge className="bg-blue-500 hover:bg-blue-600">Medium</Badge>;
      default: return <Badge variant="secondary">Low</Badge>;
    }
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8 bg-slate-50 min-h-screen">
      <Helmet><title>UX Improvement Analysis | BHF</title></Helmet>

      {/* Header */}
      <div className="flex justify-between items-center bg-white p-6 rounded-xl border shadow-sm">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Sparkles className="w-8 h-8 text-indigo-600" />
            UI/UX Improvement Analysis
          </h1>
          <p className="text-slate-500 mt-1">
            Deep scan analysis of design consistency, usability, accessibility, and performance.
          </p>
        </div>
        <div className="flex gap-3">
           <Button variant="outline" onClick={() => navigate('/bhf/master-diagnostics')}>
             Back to Diagnostics
           </Button>
           <Button size="lg" onClick={runAnalysis} disabled={analyzing} className="bg-indigo-600 hover:bg-indigo-700">
             {analyzing ? <ScanLine className="w-4 h-4 mr-2 animate-pulse" /> : <Eye className="w-4 h-4 mr-2" />}
             {analyzing ? 'Scanning Application...' : 'Run Deep Analysis'}
           </Button>
        </div>
      </div>

      {!analysisResults ? (
        <div className="flex flex-col items-center justify-center py-20 bg-white rounded-xl border border-dashed">
           <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mb-6">
             <Sparkles className="w-12 h-12 text-indigo-300" />
           </div>
           <h3 className="text-xl font-semibold text-slate-800">Ready to Analyze</h3>
           <p className="text-slate-500 max-w-md text-center mt-2">
             Run a deep scan to evaluate every module against 10 dimensions of UX quality and identify high-impact improvements.
           </p>
           <Button onClick={runAnalysis} className="mt-6">Start Scan</Button>
        </div>
      ) : (
        <>
          {/* High Level Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-500">Current UX Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2">
                  <span className="text-4xl font-bold text-slate-900">{analysisResults.metrics.currentHealth}</span>
                  <span className="text-sm text-slate-400 mb-1">/ 100</span>
                </div>
                <Progress value={analysisResults.metrics.currentHealth} className="mt-3 h-2" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-500">Potential After Fixes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2">
                  <span className="text-4xl font-bold text-emerald-600">{analysisResults.metrics.potentialHealth}</span>
                  <span className="text-sm text-emerald-600/60 mb-1 font-bold">
                    (+{analysisResults.metrics.potentialHealth - analysisResults.metrics.currentHealth})
                  </span>
                </div>
                <Progress value={analysisResults.metrics.potentialHealth} className="mt-3 h-2 bg-emerald-100" indicatorClassName="bg-emerald-500" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-500">Estimated Effort</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2">
                  <span className="text-4xl font-bold text-indigo-600">{analysisResults.metrics.totalEffortHours}</span>
                  <span className="text-sm text-slate-400 mb-1">hours</span>
                </div>
                <p className="text-xs text-slate-500 mt-3">To resolve all identified opportunities.</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Top Opportunities */}
            <div className="lg:col-span-2 space-y-6">
              <Card className="h-full">
                <CardHeader>
                  <CardTitle>Top Improvement Opportunities</CardTitle>
                  <CardDescription>Prioritized list based on impact vs. effort.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysisResults.opportunities.map((opp) => (
                      <div key={opp.id} className="p-4 border rounded-lg hover:bg-slate-50 transition-colors bg-white shadow-sm">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              {getPriorityBadge(opp.priority)}
                              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">{opp.category}</span>
                            </div>
                            <h4 className="font-bold text-slate-800">{opp.title}</h4>
                          </div>
                          <Badge variant="outline" className="bg-slate-50">
                            {opp.effort} Effort
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600 mb-3">{opp.description}</p>
                        <div className="flex items-center gap-4 text-xs text-slate-500">
                          <span className="flex items-center gap-1"><Zap className="w-3 h-3 text-amber-500" /> Impact: {opp.impact}</span>
                          <span className="flex items-center gap-1"><ArrowRight className="w-3 h-3" /> View Details</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right: Module Scores */}
            <div className="space-y-6">
              <Card className="h-full flex flex-col">
                <CardHeader>
                  <CardTitle>Module Scorecards</CardTitle>
                  <CardDescription>Detailed breakdown per module.</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 p-0">
                  <ScrollArea className="h-[600px]">
                    <div className="divide-y">
                      {analysisResults.scoredModules.map((mod, idx) => (
                        <div key={idx} className="p-4 hover:bg-slate-50">
                          <div className="flex justify-between items-center mb-2">
                            <h4 className="font-semibold text-slate-900">{mod.moduleName}</h4>
                            <Badge className={cn("border", getScoreColor(mod.overallScore))}>
                              {mod.overallScore}/100
                            </Badge>
                          </div>
                          
                          <div className="space-y-2 mt-3">
                            {/* Mini bars for key dims */}
                            {['FUNCTIONALITY', 'DESIGN', 'ACCESSIBILITY'].map(dim => (
                              <div key={dim} className="flex items-center gap-2 text-xs">
                                <span className="w-24 text-slate-500 truncate">{DIMENSIONS[dim].label}</span>
                                <Progress value={mod.dimensionScores[dim]} className="h-1.5 flex-1" />
                                <span className="w-8 text-right font-medium">{mod.dimensionScores[dim]}</span>
                              </div>
                            ))}
                          </div>

                          {mod.recommendations.length > 0 && (
                            <div className="mt-3 pt-3 border-t">
                              <p className="text-xs font-medium text-slate-500 mb-1">Recommendation:</p>
                              <p className="text-xs text-slate-700 flex items-start gap-1">
                                <AlertTriangle className="w-3 h-3 text-amber-500 shrink-0 mt-0.5" />
                                {mod.recommendations[0]}
                              </p>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ImprovementAnalysis;
