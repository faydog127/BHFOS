export const serviceAreas = [
  { "name": "Titusville", "slug": "titusville-air-duct-cleaning" },
  { "name": "Rockledge", "slug": "rockledge-air-duct-cleaning" },
  { "name": "Merritt Island", "slug": "merritt-island-air-duct-cleaning" },
  { "name": "Cocoa", "slug": "cocoa-air-duct-cleaning" },
  { "name": "New Smyrna Beach", "slug": "new-smyrna-beach-air-duct-cleaning" },
  { "name": "Melbourne", "slug": "areas/melbourne" },
  { "name": "Viera", "slug": "areas/viera" },
  { "name": "Suntree", "slug": "areas/suntree" },
  { "name": "Port St. John", "slug": "areas/port-st-john" }
];