
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  ShieldCheck, RefreshCw, AlertTriangle, 
  Wrench, Check, X, Loader2, ArrowRight
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { supabase } from '@/lib/customSupabaseClient';

const QuickFixes = ({ failures = [], onRetry }) => {
  const { toast } = useToast();
  const [selectedIssues, setSelectedIssues] = useState([]);
  const [fixingIssue, setFixingIssue] = useState(null); // The issue currently being fixed via modal
  const [processing, setProcessing] = useState(false); // General loading state
  const [fixedIssues, setFixedIssues] = useState([]); // Array of IDs that have been fixed
  const [fixModalOpen, setFixModalOpen] = useState(false);

  // Generate a unique ID for each failure if one doesn't exist (for selection tracking)
  const formattedFailures = failures.map((f, i) => ({
    ...f,
    _id: f.id || `issue-${i}`,
    _fixType: f.message?.includes('RLS') ? 'SQL_RLS' : f.status === 'missing' ? 'SQL_CREATE' : 'MANUAL'
  }));

  const toggleSelection = (id) => {
    setSelectedIssues(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedIssues.length === formattedFailures.length) {
      setSelectedIssues([]);
    } else {
      setSelectedIssues(formattedFailures.map(f => f._id));
    }
  };

  const openFixModal = (issue) => {
    setFixingIssue(issue);
    setFixModalOpen(true);
  };

  const applyFix = async (issue) => {
    setProcessing(true);
    try {
      // 1. Simulate API call or DB operation
      console.log(`Applying fix for: ${issue.name}`);
      
      // If it's a real SQL fix, we would execute it here via RPC or edge function
      // For now, we simulate success after delay
      await new Promise(r => setTimeout(r, 800));
      
      // 2. Update local state
      setFixedIssues(prev => [...prev, issue._id]);
      setFixModalOpen(false);
      
      toast({
        title: "Fix Applied Successfully",
        description: `Resolved issue: ${issue.name}`,
        variant: "default"
      });
    } catch (error) {
      console.error("Fix failed:", error);
      toast({
        title: "Fix Failed",
        description: error.message || "Could not apply fix automatically. Try manual steps.",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
      setFixingIssue(null);
    }
  };

  const handleBulkFix = async () => {
    setProcessing(true);
    let successCount = 0;
    
    // Process only selected and not-yet-fixed issues
    const issuesToFix = formattedFailures.filter(f => selectedIssues.includes(f._id) && !fixedIssues.includes(f._id));
    
    for (const issue of issuesToFix) {
      try {
        await new Promise(r => setTimeout(r, 300)); // Simulate individual processing
        setFixedIssues(prev => [...prev, issue._id]);
        successCount++;
      } catch (e) {
        console.error(e);
      }
    }
    
    setProcessing(false);
    toast({
      title: "Bulk Fix Complete",
      description: `Successfully resolved ${successCount} issues.`,
    });
    setSelectedIssues([]);
  };

  if (!formattedFailures || formattedFailures.length === 0) {
    return (
      <Card className="bg-emerald-50 border-emerald-200 shadow-sm">
        <CardContent className="pt-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="p-3 bg-white rounded-full shadow-sm">
                <ShieldCheck className="w-8 h-8 text-emerald-600" />
             </div>
             <div>
               <h3 className="font-bold text-emerald-900 text-lg">All Systems Healthy</h3>
               <p className="text-emerald-700 text-sm">No critical issues requiring remediation were found.</p>
             </div>
          </div>
          <Button variant="outline" onClick={onRetry} className="bg-white hover:bg-emerald-100 text-emerald-800 border-emerald-200">
             <RefreshCw className="h-4 w-4 mr-2" /> Re-scan
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="flex flex-col border-amber-200 shadow-sm overflow-hidden bg-white">
      <CardHeader className="bg-amber-50/50 border-b px-4 py-3">
        <div className="flex items-center justify-between">
           <div className="flex items-center gap-2">
             <AlertTriangle className="h-5 w-5 text-amber-500" />
             <div>
               <CardTitle className="text-base font-bold text-slate-800">Quick Fixes & Remediation</CardTitle>
               <CardDescription className="text-xs">
                 {formattedFailures.length} detected issues • {fixedIssues.length} fixed • {formattedFailures.length - fixedIssues.length} pending
               </CardDescription>
             </div>
           </div>
           
           <div className="flex items-center gap-2">
             <Button 
               size="sm" 
               variant="outline" 
               className="h-8 text-xs bg-white"
               onClick={toggleSelectAll}
             >
               {selectedIssues.length === formattedFailures.length ? "Deselect All" : "Select All"}
             </Button>
             
             {selectedIssues.length > 0 && (
               <Button 
                 size="sm" 
                 className="h-8 text-xs bg-indigo-600 hover:bg-indigo-700 text-white"
                 onClick={handleBulkFix}
                 disabled={processing}
               >
                 {processing ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <Wrench className="w-3 h-3 mr-1" />}
                 Fix Selected ({selectedIssues.length})
               </Button>
             )}
           </div>
        </div>
      </CardHeader>
      
      <div className="flex-1 max-h-[300px] overflow-hidden flex flex-col">
        <div className="bg-slate-50 border-b text-xs font-semibold text-slate-500 flex px-4 py-2">
           <div className="w-8 flex-shrink-0"></div>
           <div className="flex-1">ISSUE</div>
           <div className="w-24">SEVERITY</div>
           <div className="w-24">TYPE</div>
           <div className="flex-1">SUGGESTED FIX</div>
           <div className="w-24 text-right">ACTION</div>
        </div>
        <ScrollArea className="flex-1">
           <div className="divide-y">
             {formattedFailures.map((issue) => {
               const isFixed = fixedIssues.includes(issue._id);
               const isSelected = selectedIssues.includes(issue._id);

               return (
                 <div key={issue._id} className={cn("flex items-center px-4 py-2 text-sm hover:bg-slate-50 transition-colors", isFixed && "bg-emerald-50/50 hover:bg-emerald-50/80")}>
                    <div className="w-8 flex-shrink-0 flex justify-center">
                       {isFixed ? (
                         <Check className="w-4 h-4 text-emerald-600" />
                       ) : (
                         <Checkbox 
                           checked={isSelected} 
                           onCheckedChange={() => toggleSelection(issue._id)}
                         />
                       )}
                    </div>
                    <div className="flex-1 font-medium text-slate-900 truncate pr-4" title={issue.message}>
                       {issue.name || "Unknown Issue"}
                    </div>
                    <div className="w-24 flex-shrink-0">
                       <Badge variant={issue.severity === 'critical' ? 'destructive' : 'secondary'} className="text-[10px] uppercase h-5 px-1.5">
                         {issue.severity}
                       </Badge>
                    </div>
                    <div className="w-24 flex-shrink-0 text-xs text-slate-500 uppercase tracking-wide">
                       {issue.type}
                    </div>
                    <div className="flex-1 text-slate-600 text-xs truncate pr-4">
                       {isFixed ? "Issue resolved successfully." : (issue.message || "Check logs for details.")}
                    </div>
                    <div className="w-24 flex-shrink-0 text-right">
                       {!isFixed && (
                         <Button 
                           size="sm" 
                           variant="ghost" 
                           className="h-6 px-2 text-xs text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50"
                           onClick={() => openFixModal(issue)}
                         >
                           Review <ArrowRight className="w-3 h-3 ml-1" />
                         </Button>
                       )}
                    </div>
                 </div>
               );
             })}
           </div>
        </ScrollArea>
      </div>

      {/* Confirmation Modal */}
      <Dialog open={fixModalOpen} onOpenChange={setFixModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Apply Fix for {fixingIssue?.name}</DialogTitle>
            <DialogDescription>
              Review the automated actions before applying changes.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="p-3 bg-slate-50 rounded border text-sm text-slate-700">
               <span className="font-semibold block mb-1">Issue Detected:</span>
               {fixingIssue?.message}
            </div>
            
            <div className="space-y-2">
               <span className="text-sm font-semibold text-slate-900">Planned Action:</span>
               {fixingIssue?._fixType === 'SQL_RLS' && (
                 <div className="bg-slate-950 text-slate-300 p-3 rounded font-mono text-xs overflow-x-auto">
                    ALTER TABLE {fixingIssue.name} ENABLE ROW LEVEL SECURITY;<br/>
                    CREATE POLICY "Enable read" ON {fixingIssue.name} FOR SELECT TO authenticated USING (true);
                 </div>
               )}
               {fixingIssue?._fixType === 'SQL_CREATE' && (
                 <div className="bg-slate-950 text-slate-300 p-3 rounded font-mono text-xs overflow-x-auto">
                    CREATE TABLE public.{fixingIssue.name} (<br/>
                    &nbsp;&nbsp;id uuid PRIMARY KEY DEFAULT gen_random_uuid(),<br/>
                    &nbsp;&nbsp;created_at TIMESTAMPTZ DEFAULT NOW()<br/>
                    );
                 </div>
               )}
               {fixingIssue?._fixType === 'MANUAL' && (
                 <div className="p-3 bg-amber-50 border border-amber-200 rounded text-amber-800 text-sm">
                    ⚠️ This issue requires manual intervention or configuration change. 
                    We can mark it as acknowledged, but you may need to check the dashboard settings.
                 </div>
               )}
            </div>
          </div>

          <DialogFooter className="flex gap-2 sm:justify-end">
            <Button variant="outline" onClick={() => setFixModalOpen(false)}>Cancel</Button>
            <Button 
              onClick={() => applyFix(fixingIssue)} 
              disabled={processing}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              {processing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {fixingIssue?._fixType === 'MANUAL' ? 'Acknowledge Issue' : 'Apply Fix'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </Card>
  );
};

export default QuickFixes;
