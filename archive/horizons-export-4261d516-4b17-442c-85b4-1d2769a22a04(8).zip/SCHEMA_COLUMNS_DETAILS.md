marketing_actions:
- id: uuid
- lead_id: uuid
- playbook_key: text
- type: text
- channel: text
- status: text
- content_preview: text
- target_details: jsonb
- scheduled_at: timestamp with time zone
- created_at: timestamp with time zone
- approved_at: timestamp with time zone
- approved_by: uuid
- sent_at: timestamp with time zone
- error_log: text
- reviewer_notes: text
- reviewed_at: timestamp with time zone
- updated_at: timestamp with time zone
- reviewed_by: text

marketing_content:
- The `marketing_content` table does not exist in the current database schema.