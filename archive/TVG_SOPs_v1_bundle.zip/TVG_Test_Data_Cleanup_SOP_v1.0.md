# TVG Test Data Cleanup SOP (v1.0)

## 1. Purpose

This SOP defines how to separate test/training data from real operating data so that:

- The board and reports only reflect real business.  
- Test data remains available for training and dev.  
- Automations do not touch junk records.

---

## 2. First Principle – Don’t Delete Blindly

Before cleanup:

1. Export a full database backup (Supabase/Hostinger export).  
2. Treat test data in two categories:
   - Trash: safe to archive/delete.  
   - Useful: keep, but mark as test so it never affects KPIs.

Goal: end with:

- Real data → drives board, metrics, money.  
- Test data → quarantined; visible only by explicit choice.

---

## 3. Add `is_test` Flags

Add a boolean `is_test` field to key tables:

- leads  
- jobs / work_orders  
- accounts  
- partners  
- (optional) invoices, automation_events

Example:

```sql
ALTER TABLE leads ADD COLUMN is_test boolean NOT NULL DEFAULT false;
ALTER TABLE jobs ADD COLUMN is_test boolean NOT NULL DEFAULT false;
ALTER TABLE accounts ADD COLUMN is_test boolean NOT NULL DEFAULT false;
ALTER TABLE partners ADD COLUMN is_test boolean NOT NULL DEFAULT false;
```

---

## 4. Three-Pass Identification

### Pass 1 – Obvious Junk (Bulk Mark)

Mark clearly fake records as `is_test = true`:

- Names containing: Test, Demo, Sample, Fake, ZZZ, etc.  
- Emails: test@, demo@, example.com, mailinator, etc.  
- Phone: 555-… patterns.  
- lead_source: Internal Test, Dev, Playground, etc.

Run bulk updates to flag them as test.

---

### Pass 2 – Probably Test (Human Review)

Create admin views such as:

- possible_test_leads:
  - created_by = you  
  - created_at during dev period  
  - no invoices, no payments

- possible_test_jobs:
  - no invoice/payment  
  - no satisfaction_rating  
  - created during obvious testing days

Manually scan these lists and mark confirmed test records as `is_test = true`.

---

### Pass 3 – Archive or Delete

Once flagged:

- For useful test records:
  - Keep them in DB, but `is_test = true` and off the main board.  
- For trash:
  - Soft archive: `archive_reason = 'Internal Test'; is_test = true;`  
  - Optional hard delete from non-critical tables once you are confident.

Do not hard delete until you’ve run the system successfully with the `is_test` filters.

---

## 5. Update App Queries & Views

All main operational views must ignore test data by default:

- Kanban / pipeline  
- Metrics bar  
- Workload view  
- Collections  
- Source/Partner performance

Base query rule:

```sql
WHERE is_test = false
```

If needed, add an “Include Test Data” toggle visible only to admin for debugging.

---

## 6. Automations Must Ignore Test Data

Update all automation logic to skip test records:

- Zombie Archive  
- Stale Quote Alert  
- Overbooking Flag  
- Collections reminders  
- Review engine

Example condition:

```sql
WHERE is_test = false
  AND status = 'quote_sent'
  AND last_touch < NOW() - interval '30 days'
```

This prevents automations from constantly touching junk training rows.

---

## 7. Future Test Data – Make It Deliberate

From now on, all test records should be clearly marked:

- Names like: “TVG Test – [Scenario]”.  
- lead_source = 'Internal Test' or 'Training'.  
- Obvious test addresses (“999 Test St”).  
- Always created with `is_test = true`.

If possible, require `is_test = true` in the UI for any record created while in Training Mode.

---

## 8. One-Time Cleanup Checklist

1. Backup the database.  
2. Add `is_test` to key tables.  
3. Run Pass 1 bulk mark.  
4. Build Pass 2 views and manually review; mark as test.  
5. Update all app queries to `WHERE is_test = false` for live views.  
6. Update automations to ignore `is_test = true`.  
7. Soft archive obvious junk.  
8. Smoke-test the app:
   - Create a real lead (is_test = false) → visible everywhere.  
   - Create a test lead (is_test = true) → only visible when explicitly requested.

After this, anything you see on the main board and metrics is **real business**.
