# TVG PIPELINE DIRECTIVE v1.0  
## “Board = Truth. Movement = Action.”

### 1. Purpose of the Board

The TVG Kanban is not a whiteboard.  
It is a **State Machine** that controls:

- Leads  
- Jobs  
- Money  
- Reputation  

> A card may only move when a real action has occurred.  
> No “dragging to feel better.” No cosmetic moves.

---

### 2. Columns & States (The Spine)

Columns (left → right):

1. New Leads  
2. Contacted / Qualifying  
3. Visit Scheduled  
4. Quote Sent  
5. Ready to Book (Approved, not scheduled)  
6. Scheduled Jobs  
7. In Progress  
8. Ready to Invoice  
9. Awaiting Payment  
10. Paid / Closed  

(Plus Archive/Dormant off-board.)

Every job/lead must exist in exactly one of these states.

---

### 3. Movement Physics (Drag Rules)

Global Law:

- If a modal opens and you cancel or fail validation, the card snaps back.  
- No action = no state change.

Allowed forward moves (office):

- New → Contacted: requires logging a real interaction.  
- Contacted → Visit Scheduled: requires booking date, window, visit type, address.  
- Quote Sent → Ready to Book: requires logged approval (how, who, when).  
- Ready to Book → Scheduled Jobs: requires scheduling work order (date, window, tech if known).  
- Ready to Invoice → Awaiting Payment: requires creating/sending an invoice.  
- Awaiting Payment → Paid / Closed: requires recording payment (amount, method, date, reference).

Field app controls:

- Scheduled → In Progress: tech taps Start Job in field app.  
- In Progress → Ready to Invoice: tech taps Complete Job with photos + signatures.

Backward / special moves:

- Scheduled → Ready to Book: only via Reschedule flow (clear date/time, unassign).  
- Any active → Archive/Dormant: via Archive modal with disposition reason.

Illegal moves (blocked in UI):

- Scheduled → In Progress (office).  
- Visit Scheduled → Quote Sent (if no quote exists).  
- Paid / Closed → any earlier money stage.  
- Any non-adjacent skip by drag.

---

### 4. Filters, Peek, and Views

Core tools:

- Filters:
  - SLA Status: Green / Yellow / Red  
  - Owner  
  - Follow-Ups Due Today  
  - Source / Partner (for reviews)

- Card Peek (hover):
  - Who, what, where, value, owner/tech, dates, last note.

- Side Drawer (click):
  - Full details, notes/activity feed, key actions.

Operating rule:

- Hover to decide. Click to act.  
- Do not open drawers just to remember what something is.

---

### 5. Time Protection (Estimated Minutes & Workload)

Each job/work order has `estimated_minutes`:

- GOOD: 90 min  
- BETTER: 120 min  
- BEST: 150 min  
- Dryer Vent Only: 45 min  
- Special / Mold: 180+ min (flagged special)

CSR can override at scheduling.

Daily Workload View (solo mode):

- Sum of estimated minutes per day.  
- Colors:
  - Green: < 6h  
  - Yellow: 6–7.5h  
  - Red: 7.5–8h  
  - Blue: > 8h (overbooked)

Rule: Do not schedule into Blue by accident. Grinding a long day must be intentional.

---

### 6. WIP & SLA (Board Discipline)

WIP Limit (v1):

- Quote Sent is capped (e.g., 20).  
- At or over limit:
  - Header turns red.  
  - Dragging into that column is blocked.  
  - Message: “Clear existing quotes before sending more.”

SLA & colors:

- New Leads:
  - Green: 0–15 min (business hours)  
  - Yellow: 16–60 min  
  - Red: >60 min  
  - Blue: after-hours (timer starts next business day)

- Stale Quotes:
  - Stale after 72 hours: triggers alert & follow-up.

Rule:  
Red = today.  
Yellow = this block.  
Green = fine.  
Blue = queued.

---

### 7. Critical Data Fields

Every lead/job must carry:

- `lead_source` (Web Wizard, Fast Lane, Free Air Check, Door Hanger, BNI, Partner, etc.)  
- `referring_partner_id` (nullable, mandatory if partner referred)  
- `next_follow_up_at` (date you plan to touch it again)  
- `archive_reason` (Disposition: Price, Competitor, Timing, Out of Area, Chaos, Internal Error)

Money:

- `invoice_due_at`  
- `invoice_status` (`sent`, `reminder_1`, `reminder_2`, `overdue`)

Reputation:

- `satisfaction_rating` (1–5) on completion.

---

### 8. Automations (The Bots & Their Laws)

Automations must be visible, logged, and predictable.

Core v1 automations:

1. Zombie Archive  
   - IF Quote Sent AND no activity > 30 days  
   - THEN move to Dormant/Archive, log event, add note.

2. Stale Quote Alert  
   - IF Quote Sent AND time_in_stage > 72 hours  
   - THEN assign Owner, send follow-up email, log event.

3. Overbooking Flag  
   - IF total estimated_minutes for a day > 480  
   - THEN mark day as Overbooked in workload view.

4. Collections Engine (v1)  
   - Reminder 1: X days after invoice_due_at → friendly email.  
   - Reminder 2: X+Y days → firmer reminder.  
   - Overdue: Z days → set invoice_status = 'overdue', add badge, show in Collections filter.

5. Review Engine  
   - On job completion, ask for rating:
     - 5★ → send Google review link email.  
     - 1–4★ → send “We’d like to fix this” email AND:
       - Tag Needs Recovery  
       - Set next_follow_up_at = tomorrow.

---

### 9. Automation Oversight

Add an Automation Log:

- timestamp  
- rule_name  
- target_type  
- target_id  
- result (success/failed)  
- message

UI: a simple view under Settings.

Rule: If the board ever looks wrong, check the Automation Log first.

---

### 10. Tech Mode (Field View)

Techs do not use the CRM board.

They live on `/tech/schedule`:

- Today’s jobs (vertical list).  
- For each job:
  - Time window  
  - Address (tap to map)  
  - Scope summary  
  - Buttons: START JOB, VIEW DOSSIER, COMPLETE JOB

On COMPLETE:

- Capture before/after photos  
- Customer signature  
- Satisfaction rating  

This drives board transitions and review engine.

---

### 11. Operating Rhythm

Daily – Morning:

1. Filter: SLA Red + Owner = you → clear Reds.  
2. Filter: Follow-Ups Due Today → clear follow-ups.  
3. Check Workload View → avoid Blue.  
4. Glance at Automation Log.

Daily – End of Day:

- Ensure all completed jobs are in Ready to Invoice, not stuck In Progress.

Weekly:

- Collections pass (Awaiting Payment + Overdue).  
- Source/Partner snapshot.  
- Clean Dormant (spot-check big tickets).

---

### 12. Core Principle

If the board doesn’t reflect reality, nothing else matters.

- No tech action should bypass the board.  
- No office action should move a card without required data.  
- No automation should run without logging what it did.

This directive is the standard for you now and for future staff/franchisees.
