# TVG Kanban – Operator Cheat Sheet (v1.0)

**Rule #1:** You are not allowed to move cards just to make the board look pretty.  
Every move = a real action (call, booking, quote, invoice, payment).

**Rule #2:** If you try to move a card and don’t finish the form that pops up,  
the card stays where it was. No action = no state change.

---

## Columns (Left → Right)

1. New Leads  
2. Contacted / Qualifying  
3. Visit Scheduled  
4. Quote Sent  
5. Ready to Book (Approved, not scheduled)  
6. Scheduled Jobs  
7. In Progress  
8. Ready to Invoice  
9. Awaiting Payment  
10. Paid / Closed

---

## How to Move Cards (What You MUST Do First)

### 1. New Leads → Contacted / Qualifying

You may move it ONLY if:

- You actually called, texted, or emailed them.

You will be asked to log:

- How you contacted them (Call / SMS / Email)  
- What happened (Reached / Left VM / No answer)  
- Any quick notes  

If you didn’t touch them yet, leave the card in New Leads.

---

### 2. Contacted / Qualifying → Visit Scheduled

You may move it ONLY if:

- You picked a day + time window with the customer.

You must enter:

- Visit type (Residential, Free Air Check, Commercial, etc.)  
- Date  
- Time window (AM/PM)  
- Confirm address  

If you haven’t actually booked a time with the customer, do not move the card.

---

### 3. Visit Scheduled → Quote Sent

You do NOT drag cards into Quote Sent.

The board will move it for you when:

- You (or the tech) create and send a quote from the Proposals/Quote screen.

If no quote exists yet, the card stays in Visit Scheduled.

---

### 4. Quote Sent → Ready to Book

You may move it ONLY if:

- The customer has approved the quote (signed or clearly confirmed).

You will be asked:

- How they approved (signed, email, phone, etc.)  
- Who approved (name + role)  
- Confirmation that they agreed to scope & price  

If they’re “thinking about it,” the card stays in Quote Sent.

---

### 5. Ready to Book → Scheduled Jobs

You may move it ONLY if:

- You choose a date and time window for the actual work.

You must set:

- Date  
- Time window  
- Tech (if you know it)  
- Any important notes (access, pets, ladders, etc.)

No schedule = card stays in Ready to Book.

---

### 6. Scheduled Jobs → In Progress

You CANNOT move this by hand.

- It moves automatically when the tech taps “Start Job” in the field app.

If it’s not moving, call the tech. Don’t drag the card.

---

### 7. In Progress → Ready to Invoice

You CANNOT move this by hand either.

- It moves automatically when the tech completes the job in the field app and uploads photos/signatures.

If the tech finished but the card isn’t moving, have them close it properly in the app.

---

### 8. Ready to Invoice → Awaiting Payment

You may move it ONLY if:

- You actually create and send the invoice.

You will be asked to:

- Confirm line items/price  
- Choose how to send it (email/text/print)  
- Confirm invoice date + due date

If the invoice isn’t sent yet, keep the card in Ready to Invoice.

---

### 9. Awaiting Payment → Paid / Closed

You may move it ONLY if:

- The customer has paid (in full or you’re recording the payment).

You must record:

- Amount  
- Payment method (card, cash, check, etc.)  
- Date  
- Reference (check #, last 4, etc.)

If you don’t know for sure they paid, do not move it.

---

## Cancels, Lost Deals & Reschedules

### Archive / Cancel

If a job or lead is dead:

- Drag the card to the Archive/Cancel zone.
- Select a reason:
  - Price, Chose Competitor, Not a Fit, No Show, Out of Area, Chaos, Internal Error, etc.
- Card disappears from the main board (moves to Dormant/Archive view).

### Reschedule

If a job in Scheduled Jobs needs to be moved:

- Drag it back to Ready to Book.  
- Confirm that you’re clearing the date/time.  
- Book a new date later like any other Ready to Book card.

---

## The Mindset

Before you move any card, ask:

> “What real action have I taken that earns this move?”

If the answer is “none” or “not yet” → do not move the card.

That’s what keeps the board honest—and what makes it useful when you look at it in the morning.
