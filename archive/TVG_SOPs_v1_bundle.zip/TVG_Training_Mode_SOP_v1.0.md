# TVG TRAINING MODE SOP  
Version 1.0 – For Virtual Assistants & New Staff

---

## 1. Purpose

Training Mode exists so you can practice using TVG OS without:

- Touching real customers  
- Messing up real jobs  
- Corrupting real reports or money

If you’re in Training Mode, nothing you do should impact the live business.

---

## 2. How to Know Which Mode You’re In

You are in TRAINING MODE when:

- You see a clear banner at the top, e.g.:  
  “TRAINING MODE – Changes do NOT affect real customers or reports.”
- The app styling indicates training (color/label).
- The browser title says something like: “TVG OS – TRAINING”.

You are in LIVE MODE when:

- There is no Training banner; title is just “TVG OS”.

Rule: If you are ever unsure which mode you’re in → STOP and ask before continuing.

---

## 3. What Training Mode Does Behind the Scenes

When Training Mode is ON:

1. All new records you create are TEST records.
   - New leads, jobs, accounts, partners = `is_test = true`.
   - They do not count toward real KPIs or reports.

2. Real (live) data is read-only.
   - You may view real leads/jobs as examples.  
   - You may NOT:
     - Move live cards on the board  
     - Change live statuses  
     - Edit live customer details

3. Automations ignore live data.
   - Zombie Archive, Stale Quote, Overbooking, Collections, etc. will not change any live records while in Training Mode.

4. No real external actions.
   - No real Stripe charges  
   - No real customer SMS via Twilio  
   - No real customer emails via Resend  
   - Anything “sent” is either logged only or routed to a safe internal test address.

---

## 4. What You CAN Do in Training Mode

You are encouraged to:

- Create test leads (e.g., “TVG Test – Dryer Vent”).  
- Use fake contact info and addresses (test@… emails, “999 Test St”).  
- Move test cards through every column:
  - New → Contacted → Visit Scheduled → Quote Sent → Ready to Book → Scheduled → In Progress → Ready to Invoice → Awaiting Payment → Paid/Closed.
- Practice:
  - Logging calls and notes  
  - Scheduling visits  
  - Recording approvals  
  - Generating quotes (in training)  
  - Sending “invoices” (test only)  
  - Archiving with disposition reasons  
  - Setting follow-up dates and using Follow-Ups Due Today

Think of Training Mode as a flight simulator – you should feel free to press every button and see what happens.

---

## 5. What You MUST NOT Do in Training Mode

While in Training Mode:

- Do NOT try to:
  - Fix real customer cards  
  - Send real invoices, quotes, or receipts  
  - Process real payments  
- If you see a real customer name you recognize, treat it as:
  - Read-only example  
  - Do not drag it, edit it, or archive it during training.

If you accidentally move or change something that looks real:

- Stop.  
- Notify Erron immediately with details:
  - “I was in Training Mode and I think I touched a live record: [Name / Address / Job ID].”

---

## 6. How Training Sessions Work

### Before Training

1. Confirm with Erron that Training Mode is ON.  
2. Look for the Training banner and title.

### During Training

1. Create or use clearly fake records:
   - Names: “TVG Test – [Scenario]”  
   - Emails: `test+1@theventguys.com` or similar  
   - Addresses: obvious fakes

2. Practice end-to-end scenarios:
   - New inbound lead → scheduled visit  
   - Quote sent → approved → Ready to Book → Scheduled  
   - Job completed → satisfaction rating → review workflow  
   - Lead archived → correct Disposition Reason

3. Ask questions whenever:
   - You’re not sure what a column means  
   - You’re not sure which action is required before moving a card  
   - Something doesn’t move and you don’t know why

### After Training

1. Do NOT try to “clean up” test data – it is already flagged as test.  
2. Confirm you are out of Training Mode before doing any real work.  
3. For live work, only use real information and follow the Live Mode SOP.

---

## 7. Golden Rules

1. If you see TRAINING MODE, assume nothing is real.  
2. If you see real customer details, treat them as read-only during training.  
3. Never process real payments, SMS, or emails in Training Mode.  
4. If you’re confused, stop and ask – don’t guess.
