import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

const SupabaseAuthContext = createContext({});

export const useSupabaseAuth = () => useContext(SupabaseAuthContext);

// Fix for Issue #2: Export useAuth as an alias for compatibility
export const useAuth = useSupabaseAuth;

export const SupabaseAuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [role, setRole] = useState(null); // 'admin', 'manager', 'technician', 'viewer'
  const [loading, setLoading] = useState(true);

  // Helper to fetch role from our public table
  const fetchUserRole = async (userId) => {
    try {
      const { data, error } = await supabase
        .from('app_user_roles')
        .select('role')
        .eq('user_id', userId)
        .single();
      
      if (error) {
        console.warn('Error fetching user role:', error);
        return 'viewer'; // Default fallback
      }
      return data?.role || 'viewer';
    } catch (err) {
      console.error('Role fetch exception:', err);
      return 'viewer';
    }
  };

  useEffect(() => {
    let mounted = true;

    async function initializeAuth() {
      try {
        const { data: { session: initialSession }, error } = await supabase.auth.getSession();
        
        if (mounted) {
          if (error) throw error;
          
          setSession(initialSession);
          setUser(initialSession?.user ?? null);

          if (initialSession?.user) {
            const userRole = await fetchUserRole(initialSession.user.id);
            setRole(userRole);
          }
        }
      } catch (err) {
        console.error('Auth initialization error:', err);
      } finally {
        if (mounted) setLoading(false);
      }
    }

    initializeAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, currentSession) => {
      if (mounted) {
        setSession(currentSession);
        setUser(currentSession?.user ?? null);
        
        if (currentSession?.user) {
          // If role isn't loaded yet or user changed, fetch it
          if (!role || (user && user.id !== currentSession.user.id)) {
             const userRole = await fetchUserRole(currentSession.user.id);
             setRole(userRole);
          }
        } else {
          setRole(null);
        }
        
        setLoading(false);
      }
    });

    return () => {
      mounted = false;
      subscription?.unsubscribe();
    };
  }, []);

  const value = {
    user,
    session,
    role,
    loading,
    isAdmin: role === 'admin',
    isManager: role === 'manager' || role === 'admin',
    isTechnician: role === 'technician' || role === 'manager' || role === 'admin',
    
    signInWithGoogle: async () => {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/crm/dashboard`,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          },
        },
      });
      if (error) throw error;
      return data;
    },

    signInWithPassword: (credentials) => supabase.auth.signInWithPassword(credentials),
    
    signOut: async () => {
      setRole(null);
      setUser(null);
      setSession(null);
      return await supabase.auth.signOut();
    },
  };

  return (
    <SupabaseAuthContext.Provider value={value}>
      {children}
    </SupabaseAuthContext.Provider>
  );
};