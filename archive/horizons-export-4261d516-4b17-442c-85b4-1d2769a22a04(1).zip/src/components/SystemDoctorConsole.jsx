
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { 
  Shield, AlertTriangle, CheckCircle, Activity, Play, 
  Database, History, RefreshCw, XCircle, Terminal, Save, Lock, 
  ChevronRight, AlertOctagon, FileCode, Check, Loader2, PlayCircle
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

const SystemDoctorConsole = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [manualPlanOpen, setManualPlanOpen] = useState(false);
  const [manualSql, setManualSql] = useState('');
  const [activeTab, setActiveTab] = useState('queue');

  // 1. Role Check
  const { data: isAdmin, isLoading: isLoadingRole } = useQuery({
    queryKey: ['isAdmin', user?.id],
    queryFn: async () => {
      if (!user) return false;
      const { data, error } = await supabase
        .from('app_user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin')
        .single();
      
      // If no row found, error is not null, so we assume false
      if (error && error.code !== 'PGRST116') console.error('Role check error:', error);
      return !!data;
    },
    enabled: !!user,
  });

  // 2. Fetch System Settings (Safe Mode)
  const { data: safeMode, isLoading: isLoadingSettings } = useQuery({
    queryKey: ['system_settings', 'global_safe_mode'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('system_settings')
        .select('value')
        .eq('key', 'global_safe_mode')
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      // Default to true if not set to ensure safety
      return data ? data.value === true : true; 
    }
  });

  // 3. Fetch Audit Log Issues
  const { data: issues = [], isLoading: isLoadingIssues, refetch: refetchIssues } = useQuery({
    queryKey: ['system_audit_log'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('system_audit_log')
        .select('*')
        .order('timestamp_utc', { ascending: false })
        .limit(50);
      
      if (error) throw error;
      return data;
    }
  });

  // 4. Mutations
  const toggleSafeModeMutation = useMutation({
    mutationFn: async (newValue) => {
      const { error } = await supabase
        .from('system_settings')
        .upsert({ key: 'global_safe_mode', value: newValue });
      if (error) throw error;
      return newValue;
    },
    onSuccess: (newValue) => {
      queryClient.setQueryData(['system_settings', 'global_safe_mode'], newValue);
      toast({
        title: `Safe Mode ${newValue ? 'Enabled' : 'Disabled'}`,
        description: newValue 
          ? "System is now protected from destructive actions." 
          : "Warning: Destructive actions are now permitted.",
        variant: newValue ? "default" : "destructive",
      });
    }
  });

  const executeFixMutation = useMutation({
    mutationFn: async (issueId) => {
      // Use RPC as per requirements for executing the fix
      const { data, error } = await supabase.rpc('execute_remediation_plan', {
        target_issue_id: issueId
      });

      if (error) throw error;
      if (data && data.status === 'FAILURE') {
        throw new Error(data.error || 'Execution returned failure status');
      }
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Fix Executed Successfully",
        description: "The remediation plan has been applied.",
        className: "bg-emerald-500 border-none text-white"
      });
      refetchIssues();
      setSelectedIssue(null);
    },
    onError: (error) => {
      console.error("Fix Execution Error:", error);
      toast({
        title: "Execution Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const saveManualPlanMutation = useMutation({
    mutationFn: async ({ issueId, sql, description }) => {
      const { data, error } = await supabase.functions.invoke('save-manual-plan', {
        body: { issue_id: issueId, sql_content: sql, description }
      });

      if (error) throw error;
      if (!data.success) throw new Error(data.error || 'Failed to save plan');
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Manual Plan Saved",
        description: "Your custom SQL plan has been attached to the issue.",
      });
      setManualPlanOpen(false);
      refetchIssues();
    },
    onError: (error) => {
      toast({
        title: "Save Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Filtering
  const pendingIssues = issues.filter(i => 
    ['PENDING_REVIEW', 'MANUAL_INTERVENTION_REQUIRED', 'IN_PROGRESS', 'FAILURE'].includes(i.execution_status)
  );
  
  const historyIssues = issues.filter(i => 
    ['SUCCESS', 'RESOLVED', 'ROLLED_BACK'].includes(i.execution_status)
  );

  const displayIssues = activeTab === 'queue' ? pendingIssues : historyIssues;

  // Stats
  const stats = {
    active: pendingIssues.length,
    fixed: historyIssues.length,
    health: Math.max(0, 100 - (pendingIssues.length * 5)), // Simple heuristic
  };

  // Loading state
  if (isLoadingRole) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-slate-400">
        <Loader2 className="w-10 h-10 animate-spin mb-4 text-emerald-500" />
        <p>Verifying access privileges...</p>
      </div>
    );
  }

  // Access Denied State
  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-slate-400">
        <Shield className="w-16 h-16 mb-4 text-slate-600" />
        <h2 className="text-xl font-semibold text-slate-200">Access Restricted</h2>
        <p>System Doctor Console requires administrator privileges.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 p-6 font-sans text-slate-200 selection:bg-emerald-500/30">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white mb-1">System Doctor Console</h1>
          <p className="text-slate-400">Automated diagnostics and self-healing infrastructure.</p>
        </div>
        <Button 
          variant="outline" 
          onClick={() => refetchIssues()}
          disabled={isLoadingIssues}
          className="border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
        >
          <RefreshCw className={cn("w-4 h-4 mr-2", isLoadingIssues && "animate-spin")} />
          Refresh
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard 
          title="Active Issues" 
          value={stats.active} 
          icon={AlertTriangle} 
          color="text-amber-500"
          bg="bg-amber-500/10"
          border="border-amber-500/20"
        />
        <StatCard 
          title="Fixes Applied" 
          value={stats.fixed} 
          icon={CheckCircle} 
          color="text-emerald-500"
          bg="bg-emerald-500/10"
          border="border-emerald-500/20"
        />
        <StatCard 
          title="System Health" 
          value={`${stats.health}%`} 
          icon={Activity} 
          color={stats.health > 90 ? "text-emerald-500" : stats.health > 70 ? "text-amber-500" : "text-red-500"}
          bg="bg-slate-900"
          border="border-slate-800"
        />
        <Card className="bg-slate-900 border-slate-800 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Protected Mode</CardTitle>
            <Shield className={cn("w-4 h-4", safeMode ? "text-indigo-400" : "text-slate-600")} />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-white">{safeMode ? 'Active' : 'Disabled'}</div>
              <Switch 
                checked={safeMode}
                onCheckedChange={(val) => toggleSafeModeMutation.mutate(val)}
                className="data-[state=checked]:bg-indigo-500"
              />
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {safeMode ? 'Destructive actions blocked' : 'Unrestricted execution allowed'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-300px)] min-h-[600px]">
        
        {/* Left Column: Anomalies List */}
        <Card className="col-span-1 bg-slate-900 border-slate-800 flex flex-col h-full shadow-xl shadow-black/20">
          <CardHeader className="border-b border-slate-800 pb-4">
            <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
              <AlertOctagon className="w-5 h-5 text-slate-400" />
              Detected Anomalies
            </CardTitle>
            <CardDescription className="text-slate-400">Real-time system alerts requiring attention.</CardDescription>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mt-4">
              <TabsList className="grid w-full grid-cols-2 bg-slate-950">
                <TabsTrigger value="queue" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-400">
                  <PlayCircle className="w-4 h-4 mr-2" /> Queue
                </TabsTrigger>
                <TabsTrigger value="history" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-400">
                  <History className="w-4 h-4 mr-2" /> History
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>
          
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-3">
              {displayIssues.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <CheckCircle className="w-12 h-12 mx-auto mb-3 opacity-20" />
                  <p>No issues found in {activeTab}.</p>
                </div>
              ) : (
                displayIssues.map((issue) => (
                  <div 
                    key={issue.id}
                    onClick={() => setSelectedIssue(issue)}
                    className={cn(
                      "group p-4 rounded-lg border cursor-pointer transition-all duration-200 hover:shadow-md",
                      selectedIssue?.id === issue.id 
                        ? "bg-slate-800 border-emerald-500/50 shadow-emerald-900/10" 
                        : "bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50"
                    )}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <Badge variant="outline" className={cn(
                        "font-mono text-[10px] tracking-wider uppercase",
                        getSeverityColor(issue.risk_rating)
                      )}>
                        {issue.root_cause_type?.replace(/_/g, ' ')}
                      </Badge>
                      <span className="text-xs text-slate-500 whitespace-nowrap">
                        {formatDistanceToNow(new Date(issue.timestamp_utc), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-sm text-slate-300 font-medium line-clamp-2 leading-snug group-hover:text-white transition-colors">
                      {issue.original_error_message || "Unknown System Error"}
                    </p>
                    <div className="flex items-center gap-2 mt-3 text-xs text-slate-500">
                      {issue.is_destructive_action && (
                        <span className="flex items-center text-amber-500/80 bg-amber-500/10 px-1.5 py-0.5 rounded">
                          <AlertTriangle className="w-3 h-3 mr-1" /> Destructive
                        </span>
                      )}
                      <span className={cn(
                        "ml-auto px-2 py-0.5 rounded-full capitalize",
                        getStatusColor(issue.execution_status)
                      )}>
                        {issue.execution_status?.toLowerCase().replace(/_/g, ' ')}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </Card>

        {/* Right Column: Remediation Plan */}
        <div className="col-span-1 lg:col-span-2 h-full">
          {selectedIssue ? (
            <Card className="h-full bg-slate-900 border-slate-800 flex flex-col shadow-xl shadow-black/20 animate-in fade-in slide-in-from-right-4 duration-300">
              <CardHeader className="border-b border-slate-800 bg-slate-950/30">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl font-bold text-white mb-1 flex items-center gap-2">
                      <Terminal className="w-5 h-5 text-emerald-400" />
                      Remediation Plan
                    </CardTitle>
                    <CardDescription className="text-slate-400">
                      AI-generated fix proposal and impact analysis.
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    {activeTab === 'queue' && (
                      <>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setManualPlanOpen(true)}
                          className="border-slate-700 hover:bg-slate-800 text-slate-300"
                        >
                          <FileCode className="w-4 h-4 mr-2" />
                          Edit SQL
                        </Button>
                        <Button 
                          size="sm"
                          onClick={() => executeFixMutation.mutate(selectedIssue.id)}
                          disabled={executeFixMutation.isLoading || (safeMode && selectedIssue.is_destructive_action)}
                          className={cn(
                            "text-white border-0 transition-all",
                            safeMode && selectedIssue.is_destructive_action 
                              ? "bg-slate-700 cursor-not-allowed opacity-50" 
                              : "bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-900/20"
                          )}
                        >
                          {executeFixMutation.isLoading ? (
                            <Loader2 className="w-4 h-4 animate-spin mr-2" />
                          ) : safeMode && selectedIssue.is_destructive_action ? (
                            <Lock className="w-4 h-4 mr-2" />
                          ) : (
                            <Play className="w-4 h-4 mr-2 fill-current" />
                          )}
                          {safeMode && selectedIssue.is_destructive_action ? "Blocked by Safe Mode" : "Execute Fix"}
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <ScrollArea className="flex-1 p-0">
                <div className="p-6 space-y-6">
                  
                  {/* Analysis Section */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-2">
                      <Activity className="w-4 h-4" /> Root Cause Analysis
                    </h3>
                    <div className="bg-slate-950/50 rounded-lg p-4 border border-slate-800">
                      <p className="text-slate-300 leading-relaxed font-mono text-sm">
                        {selectedIssue.doctor_response_jsonb?.analysis || "No detailed analysis available."}
                      </p>
                    </div>
                  </div>

                  {/* Plan Steps */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-2">
                      <Database className="w-4 h-4" /> Execution Steps
                    </h3>
                    <div className="space-y-3">
                      {selectedIssue.fix_plan_jsonb?.steps?.map((step, idx) => (
                        <div key={idx} className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden group">
                          <div className="px-4 py-3 bg-slate-900/50 border-b border-slate-800 flex items-center justify-between">
                            <span className="text-sm font-medium text-slate-300 flex items-center gap-2">
                              <span className="bg-slate-800 text-slate-400 w-5 h-5 rounded-full flex items-center justify-center text-xs">
                                {step.order || idx + 1}
                              </span>
                              {step.description}
                            </span>
                            {step.is_destructive && (
                              <Badge variant="destructive" className="bg-red-900/20 text-red-400 border-red-900/50">
                                Destructive
                              </Badge>
                            )}
                          </div>
                          <div className="p-4 bg-slate-950 font-mono text-xs text-emerald-400/90 overflow-x-auto whitespace-pre-wrap">
                            {step.sql}
                          </div>
                        </div>
                      )) || (
                        <div className="text-slate-500 italic p-4 text-center border border-dashed border-slate-800 rounded-lg">
                          No specific steps generated.
                        </div>
                      )}
                    </div>
                  </div>

                </div>
              </ScrollArea>
              
              <CardFooter className="bg-slate-950/30 border-t border-slate-800 py-3 px-6 text-xs text-slate-500 flex justify-between">
                <div className="flex gap-4">
                  <span>ID: {selectedIssue.id}</span>
                  <span>Feature: {selectedIssue.feature_id}</span>
                </div>
                {selectedIssue.confidence_score && (
                  <div className="flex items-center gap-1.5">
                    <span>AI Confidence:</span>
                    <span className={cn(
                      "font-bold",
                      selectedIssue.confidence_score > 0.8 ? "text-emerald-400" : "text-amber-400"
                    )}>
                      {Math.round(selectedIssue.confidence_score * 100)}%
                    </span>
                  </div>
                )}
              </CardFooter>
            </Card>
          ) : (
            <Card className="h-full bg-slate-900 border-slate-800 border-dashed flex flex-col items-center justify-center text-center p-12 animate-in fade-in duration-500">
              <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mb-6">
                <Terminal className="w-10 h-10 text-slate-600" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Ready to Diagnose</h3>
              <p className="text-slate-400 max-w-sm">
                Select an issue from the diagnostics queue on the left to review the AI-generated remediation plan.
              </p>
            </Card>
          )}
        </div>
      </div>

      {/* Manual Plan Dialog */}
      <Dialog open={manualPlanOpen} onOpenChange={setManualPlanOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-slate-200 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <FileCode className="w-5 h-5 text-indigo-400" />
              Override Remediation Plan
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Manually define the SQL logic for this fix. This bypasses the AI recommendation.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase text-slate-500">SQL Content</label>
              <Textarea 
                value={manualSql}
                onChange={(e) => setManualSql(e.target.value)}
                placeholder="UPDATE table SET column = value WHERE condition..."
                className="font-mono text-xs h-64 bg-slate-950 border-slate-800 text-emerald-400 placeholder:text-slate-700 resize-none focus-visible:ring-indigo-500"
              />
            </div>
            {safeMode && (
              <div className="flex items-center gap-2 p-3 bg-amber-500/10 border border-amber-500/20 rounded-md text-amber-200 text-sm">
                <Shield className="w-4 h-4 shrink-0" />
                Safe Mode is active. DROP/DELETE statements may be blocked during execution.
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setManualPlanOpen(false)} className="text-slate-400 hover:text-white hover:bg-slate-800">
              Cancel
            </Button>
            <Button 
              onClick={() => saveManualPlanMutation.mutate({
                issueId: selectedIssue?.id,
                sql: manualSql,
                description: "Manual Admin Override"
              })}
              disabled={!manualSql.trim() || saveManualPlanMutation.isLoading}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {saveManualPlanMutation.isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
              Save Plan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// --- Helpers ---

const StatCard = ({ title, value, icon: Icon, color, bg, border }) => (
  <Card className={cn("bg-slate-900 relative overflow-hidden", border)}>
    <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
      <CardTitle className="text-sm font-medium text-slate-400">{title}</CardTitle>
      <Icon className={cn("h-4 w-4", color)} />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold text-white">{value}</div>
      <div className={cn("absolute right-0 top-0 h-full w-24 opacity-10 transform skew-x-12 translate-x-4", bg)} />
    </CardContent>
  </Card>
);

const getSeverityColor = (rating) => {
  switch (rating) {
    case 'CRITICAL': return 'bg-red-500/10 text-red-500 border-red-500/20';
    case 'HIGH': return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
    case 'MEDIUM': return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
    default: return 'bg-slate-800 text-slate-400 border-slate-700';
  }
};

const getStatusColor = (status) => {
  switch (status) {
    case 'SUCCESS': return 'bg-emerald-500/10 text-emerald-400';
    case 'FAILURE': return 'bg-red-500/10 text-red-400';
    case 'IN_PROGRESS': return 'bg-blue-500/10 text-blue-400';
    case 'PENDING_REVIEW': return 'bg-amber-500/10 text-amber-400';
    default: return 'bg-slate-800 text-slate-500';
  }
};

export default SystemDoctorConsole;
