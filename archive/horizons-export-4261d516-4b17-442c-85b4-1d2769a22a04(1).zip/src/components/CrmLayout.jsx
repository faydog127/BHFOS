import React, { useState } from 'react';
import { Outlet, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useSupabaseAuth } from '@/contexts/SupabaseAuthContext';
import { useTrainingMode } from '@/contexts/TrainingModeContext';
import { 
  LayoutDashboard, Users, FileText, Settings, LogOut, Menu, X, 
  BarChart3, Calendar, Phone, MessageSquare, Briefcase, Calculator,
  GraduationCap, AlertTriangle, ShieldCheck, DollarSign, Wrench
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import SystemModeToggle from '@/components/SystemModeToggle';
import TrainingModeToggle from '@/components/TrainingModeToggle';

const SidebarLink = ({ to, icon: Icon, children, badge }) => {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 group relative",
          isActive 
            ? "bg-blue-600 text-white shadow-md shadow-blue-900/20" 
            : "text-slate-400 hover:text-white hover:bg-slate-800/50"
        )
      }
    >
      <Icon className="w-5 h-5 flex-shrink-0" />
      <span className="truncate">{children}</span>
      {badge && (
        <span className="ml-auto bg-blue-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">
          {badge}
        </span>
      )}
    </NavLink>
  );
};

const SectionHeader = ({ title }) => (
  <div className="px-3 mb-2 mt-6">
    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">{title}</h3>
  </div>
);

const CrmLayout = () => {
  const { signOut, user } = useSupabaseAuth();
  const { isTrainingMode } = useTrainingMode();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden backdrop-blur-sm transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed lg:static inset-y-0 left-0 z-50 w-64 bg-slate-950 text-white transform transition-transform duration-300 ease-in-out lg:transform-none flex flex-col shadow-2xl border-r border-slate-800",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center px-6 bg-slate-950 border-b border-slate-800/50 flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-900/30">
              <span className="font-bold text-white text-lg">VG</span>
            </div>
            <span className="font-bold text-lg tracking-tight text-white">The Vent Guys</span>
          </div>
          <button 
            onClick={() => setIsMobileMenuOpen(false)}
            className="ml-auto lg:hidden text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Nav Content */}
        <ScrollArea className="flex-1 py-4">
          <div className="px-3 space-y-1">
            <SidebarLink to="/crm/dashboard" icon={LayoutDashboard}>Dashboard</SidebarLink>
            
            <SectionHeader title="Sales & Pipeline" />
            <SidebarLink to="/crm/pipeline" icon={BarChart3}>Pipeline</SidebarLink>
            <SidebarLink to="/crm/leads" icon={Users}>Leads List</SidebarLink>
            <SidebarLink to="/crm/leads/qualify" icon={ShieldCheck}>Lead Qualification</SidebarLink>
            <SidebarLink to="/crm/estimates" icon={Calculator}>Estimates</SidebarLink> 
            <SidebarLink to="/crm/jobs" icon={Briefcase}>Jobs & Work Orders</SidebarLink>
            <SidebarLink to="/crm/jobs/complete" icon={FileText}>Job Completion</SidebarLink>
            <SidebarLink to="/crm/proposals" icon={FileText}>Proposals</SidebarLink>
            <SidebarLink to="/crm/referrals" icon={Users}>Referrals</SidebarLink>
            <SidebarLink to="/crm/partners" icon={Briefcase}>Partners</SidebarLink>

            <SectionHeader title="Communications" />
            <SidebarLink to="/crm/inbox" icon={MessageSquare}>Inbox</SidebarLink>
            <SidebarLink to="/crm/sms-inbox" icon={MessageSquare}>SMS Conversations</SidebarLink>
            <SidebarLink to="/crm/calls" icon={Phone}>Calls</SidebarLink>
            <SidebarLink to="/crm/call-scripts" icon={FileText}>Scripts & Protocols</SidebarLink>

            <SectionHeader title="Operations" />
            <SidebarLink to="/crm/schedule" icon={Calendar}>Schedule</SidebarLink>
            <SidebarLink to="/crm/appointments/schedule" icon={Calendar}>Appointments</SidebarLink>
            <SidebarLink to="/crm/customers" icon={Users}>Customers</SidebarLink>
            <SidebarLink to="/crm/money" icon={DollarSign}>My Money</SidebarLink>

            <SectionHeader title="Admin" />
            <SidebarLink to="/crm/marketing" icon={BarChart3}>Marketing</SidebarLink>
            <SidebarLink to="/crm/reporting" icon={BarChart3}>Reporting</SidebarLink>
            <SidebarLink to="/crm/settings" icon={Settings}>Settings</SidebarLink>
            
             {/* Tech Portal Link (Role based normally, but showing for ease) */}
             <div className="mt-6 pt-4 border-t border-slate-800">
                <SidebarLink to="/tech" icon={Wrench}>Tech Portal</SidebarLink>
             </div>
          </div>
        </ScrollArea>

        {/* Sidebar Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex-shrink-0 space-y-3">
          <TrainingModeToggle />
          <div className="flex items-center gap-3 px-2 py-2 rounded-lg bg-slate-900/50 border border-slate-800">
             <div className="w-8 h-8 rounded-full bg-blue-900/30 flex items-center justify-center text-blue-200 text-xs font-bold border border-blue-800">
                {user?.email?.charAt(0).toUpperCase()}
             </div>
             <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-200 truncate">
                    {user?.user_metadata?.full_name || 'User'}
                </p>
                <p className="text-xs text-slate-500 truncate">{user?.email}</p>
             </div>
             <Button variant="ghost" size="icon" onClick={handleSignOut} className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-800">
                <LogOut className="w-4 h-4" />
             </Button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-slate-50 h-screen overflow-hidden">
        {/* Mobile Header */}
        <header className="lg:hidden h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 shadow-sm z-30 flex-shrink-0">
           <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(true)}>
                 <Menu className="w-6 h-6 text-slate-600" />
              </Button>
              <span className="font-bold text-slate-800">The Vent Guys</span>
           </div>
           {isTrainingMode && (
              <div className="flex items-center gap-1.5 px-2 py-1 bg-amber-100 text-amber-700 text-xs font-bold rounded-full border border-amber-200">
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>TRAINING</span>
              </div>
           )}
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto relative scroll-smooth">
           {isTrainingMode && (
              <div className="sticky top-0 left-0 right-0 z-20 bg-amber-500 text-white px-4 py-1.5 text-xs font-bold text-center shadow-md flex items-center justify-center gap-2 animate-in slide-in-from-top-2 duration-300">
                  <GraduationCap className="w-4 h-4" />
                  TRAINING MODE ACTIVE - Data is isolated
              </div>
           )}
           <Outlet />
        </main>
      </div>
    </div>
  );
};

export default CrmLayout;