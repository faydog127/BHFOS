import React, { useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertCircle, CheckCircle2, ShieldAlert, Activity, Database, Lock, Search, AlertTriangle, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

const SystemDoctorWidget = forwardRef(({ autoRun = false }, ref) => {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [lastRun, setLastRun] = useState(null);
  const [safeModeActive, setSafeModeActive] = useState(true);

  // Default targets for the "Health Check"
  const TARGET_TABLE = 'leads';
  const TARGET_COLUMN = 'id';

  // runDiagnosis now accepts isSafeMode argument
  const runDiagnosis = async (isSafeMode = true) => {
    setLoading(true);
    setError(null);
    setResults(null);
    setSafeModeActive(isSafeMode);

    try {
      const { data, error: functionError } = await supabase.functions.invoke('system-doctor', {
        body: { 
          action: 'diagnose', 
          table: TARGET_TABLE, 
          column: TARGET_COLUMN,
          is_safe_mode: isSafeMode 
        }
      });

      if (functionError) throw functionError;
      setResults(data);
      setLastRun(new Date());
      return true;
    } catch (err) {
      console.error('Diagnosis failed:', err);
      setError(err.message || 'System Doctor check failed.');
      return false;
    } finally {
      setLoading(false);
    }
  };

  useImperativeHandle(ref, () => ({
    run: runDiagnosis,
    isLoading: loading
  }));

  useEffect(() => {
    if (autoRun) {
      runDiagnosis();
    }
  }, []);

  const StatusIcon = ({ ok }) => {
    if (loading) return <Activity className="h-5 w-5 text-blue-500 animate-spin" />;
    if (!results) return <div className="h-5 w-5 bg-gray-200 rounded-full dark:bg-gray-700" />;
    return ok ? (
      <CheckCircle2 className="h-5 w-5 text-green-500" />
    ) : (
      <AlertTriangle className="h-5 w-5 text-yellow-500" />
    );
  };

  return (
    <div className="space-y-4">
      {/* Header Summary */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 flex items-center gap-2">
            System Doctor Diagnostics
            {results && safeModeActive && <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">Safe Mode Active</Badge>}
            {results && !safeModeActive && <Badge variant="outline" className="text-red-600 border-red-200 bg-red-50">Unrestricted Mode</Badge>}
          </h3>
          <p className="text-sm text-gray-500">
            Real-time analysis of database schema, security policies, and object dependencies.
          </p>
        </div>
        {lastRun && (
          <Badge variant="outline" className="text-xs">
            Last updated: {lastRun.toLocaleTimeString()}
          </Badge>
        )}
      </div>

      <AnimatePresence mode="wait">
        {error ? (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 p-4 rounded-md text-red-800 dark:text-red-200 flex items-center gap-3"
          >
            <AlertCircle className="h-5 w-5" />
            <span>{error}</span>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Schema Integrity */}
        <Card className={cn("border-t-4", results?.schema_integrity?.ok ? "border-t-green-500" : "border-t-gray-200")}>
          <CardHeader className="pb-2 space-y-0">
            <div className="flex justify-between items-start">
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Database className="h-4 w-4" /> Schema Integrity
              </CardTitle>
              <StatusIcon ok={results?.schema_integrity?.ok} />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            {loading ? (
              <div className="space-y-2 animate-pulse">
                <div className="h-4 bg-gray-100 dark:bg-gray-800 rounded w-3/4"></div>
                <div className="h-4 bg-gray-100 dark:bg-gray-800 rounded w-1/2"></div>
              </div>
            ) : results?.schema_integrity?.ok ? (
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Foreign Key relationships validated. No ambiguity detected in schema definitions.
              </div>
            ) : results?.schema_integrity ? (
               <div className="text-sm text-red-600 dark:text-red-400">
                 Issues found in {results.schema_integrity.ambiguous_fk_pairs?.length || 0} relationships.
               </div>
            ) : (
              <div className="text-sm text-gray-400 italic">Waiting for diagnostics...</div>
            )}
          </CardContent>
        </Card>

        {/* RLS Policies */}
        <Card className={cn("border-t-4", results?.rls_policies?.ok ? "border-t-green-500" : "border-t-gray-200")}>
          <CardHeader className="pb-2 space-y-0">
            <div className="flex justify-between items-start">
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Lock className="h-4 w-4" /> RLS Policies
              </CardTitle>
              <StatusIcon ok={results?.rls_policies?.ok} />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            {loading ? (
              <div className="space-y-2 animate-pulse">
                <div className="h-4 bg-gray-100 dark:bg-gray-800 rounded w-3/4"></div>
                <div className="h-4 bg-gray-100 dark:bg-gray-800 rounded w-1/2"></div>
              </div>
            ) : results?.rls_policies?.ok ? (
              <div className="space-y-2">
                <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {results.rls_policies.policies.length}
                </div>
                <div className="text-xs text-gray-500 uppercase font-semibold">
                  Active Policies on '{results.target?.table}'
                </div>
                {results.rls_policies.policies.length > 0 && (
                   <ScrollArea className="h-16 w-full rounded border bg-gray-50 dark:bg-gray-900 p-2">
                      <div className="text-xs space-y-1">
                        {results.rls_policies.policies.map(p => (
                          <div key={p.policyname} className="flex justify-between">
                            <span className="truncate max-w-[120px]" title={p.policyname}>{p.policyname}</span>
                            <span className="text-gray-400 text-[10px]">{p.cmd}</span>
                          </div>
                        ))}
                      </div>
                   </ScrollArea>
                )}
              </div>
            ) : (
              <div className="text-sm text-gray-400 italic">Waiting for diagnostics...</div>
            )}
          </CardContent>
        </Card>

        {/* Dependencies */}
        <Card className={cn("border-t-4", results?.dependencies?.ok ? "border-t-green-500" : "border-t-gray-200")}>
          <CardHeader className="pb-2 space-y-0">
             <div className="flex justify-between items-start">
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Search className="h-4 w-4" /> Dependencies
              </CardTitle>
              <StatusIcon ok={results?.dependencies?.ok} />
            </div>
          </CardHeader>
          <CardContent className="pt-4">
             {loading ? (
              <div className="space-y-2 animate-pulse">
                <div className="h-4 bg-gray-100 dark:bg-gray-800 rounded w-3/4"></div>
                <div className="h-4 bg-gray-100 dark:bg-gray-800 rounded w-1/2"></div>
              </div>
            ) : results?.dependencies?.ok ? (
               <div className="space-y-2">
                  <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                    {results.dependencies.column_dependencies?.length || 0}
                  </div>
                  <div className="text-xs text-gray-500 uppercase font-semibold">
                    Dependent Objects (Views/Triggers)
                  </div>
                   {results.dependencies.column_dependencies?.length > 0 ? (
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      Found {results.dependencies.column_dependencies.length} dependencies linked to {results.target?.table}.{results.target?.column}.
                    </div>
                  ) : (
                    <div className="text-xs text-green-600 dark:text-green-400">
                      Clean dependency tree. No direct view dependencies found.
                    </div>
                  )}
               </div>
            ) : (
              <div className="text-sm text-gray-400 italic">Waiting for diagnostics...</div>
            )}
          </CardContent>
        </Card>

      </div>
      
      {/* AI Recommendation (Only show if present in response) */}
      {results?.recommendation && (
        <Card className="bg-slate-50 dark:bg-slate-900 border-indigo-100 dark:border-indigo-900">
           <CardHeader className="pb-2">
             <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <FileText className="h-4 w-4 text-indigo-500" />
                AI Analysis & Recommendation
             </CardTitle>
           </CardHeader>
           <CardContent>
             <div className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
               {results.recommendation.notes}
             </div>
             {results.recommendation.sql && (
                <div className="mt-4">
                  <p className="text-xs font-semibold text-gray-500 uppercase mb-1">Generated Fix (SQL)</p>
                  <pre className="bg-black text-green-400 p-3 rounded-md text-xs font-mono overflow-x-auto">
                    {results.recommendation.sql}
                  </pre>
                </div>
             )}
             {!results.recommendation.sql && results.recommendation.notes && (
                <div className="mt-4 p-2 bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-200 dark:border-yellow-800 rounded text-xs text-yellow-800 dark:text-yellow-200">
                  <strong>Non-Destructive Mode:</strong> No SQL was generated. See notes for manual instructions.
                </div>
             )}
           </CardContent>
        </Card>
      )}

    </div>
  );
});

SystemDoctorWidget.displayName = "SystemDoctorWidget";

export default SystemDoctorWidget;