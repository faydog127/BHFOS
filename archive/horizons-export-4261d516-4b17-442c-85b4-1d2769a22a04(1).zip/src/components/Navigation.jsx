import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, Phone, Calendar, Calculator, LogIn, UserPlus, LayoutDashboard, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { trackCallClick, trackBookClick } from '@/lib/tracking';
import { useSupabaseAuth } from '@/contexts/SupabaseAuthContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, signOut } = useSupabaseAuth();
  const navigate = useNavigate();

  const handleBookClick = (placement) => {
    trackBookClick(placement);
    setIsOpen(false);
  };

  const handleCallClick = (placement) => {
    trackCallClick(placement);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
    setIsOpen(false);
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    // Removed "Instant Estimate" link as per request
    { name: 'Partners', path: '/partners' }, 
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50 border-b border-slate-100">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16 md:h-20">
          
          {/* Logo */}
          <Link to="/" className="flex items-center site-logo" onClick={() => setIsOpen(false)}>
            <img 
              src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/c042e0bf3434dbac49b80f9dc3eaa54a.png" 
              alt="The Vent Guys - We Clear What Others Miss" 
              className="h-[50px] md:h-[73.6px] w-auto" 
            />
          </Link>

          {/* Desktop Nav - Links */}
          <nav className="hidden lg:flex space-x-6 xl:space-x-8">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                to={link.path} 
                className={`font-medium transition-colors text-sm xl:text-base ${link.name === 'Instant Estimate' ? 'text-blue-600 font-semibold hover:text-blue-800' : 'text-slate-600 hover:text-blue-800'}`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Desktop Right Side - Actions */}
          <div className="hidden lg:flex items-center gap-3">
            <a 
              href="tel:3213609704" 
              onClick={() => handleCallClick('header_desktop')}
              className="flex items-center gap-2 text-slate-700 hover:text-blue-700 font-semibold transition-colors text-sm mr-2"
            >
              <Phone className="w-4 h-4" />
              (321) 360-9704
            </a>

            {!user ? (
              <>
                <Button variant="ghost" size="sm" asChild className="text-slate-600">
                  <Link to="/login">Log In</Link>
                </Button>
                <Button variant="outline" size="sm" asChild className="border-blue-200 text-blue-700 hover:bg-blue-50">
                   <Link to="/signup">Sign Up</Link>
                </Button>
              </>
            ) : (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-blue-100 text-blue-700 font-bold">
                        {user.email?.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuItem onClick={() => navigate('/crm')}>
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    <span>Dashboard</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="text-red-600 focus:text-red-600">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            <Button asChild onClick={() => handleBookClick('header_desktop')} className="bg-blue-600 hover:bg-blue-700">
              <Link to="/booking">Book Online</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center gap-4">
            {/* Show Call Icon on Mobile Header for quick access */}
            <a href="tel:3213609704" onClick={() => handleCallClick('header_mobile_icon')} className="text-slate-700">
              <Phone className="w-5 h-5" />
            </a>
            
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="text-slate-700 p-2 focus:outline-none"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isOpen && (
        <div className="lg:hidden bg-white border-t border-slate-100 absolute w-full shadow-lg animate-in slide-in-from-top-5 z-50 max-h-[90vh] overflow-y-auto">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            {/* Navigation Links */}
            <div className="space-y-2">
              {navLinks.map((link) => (
                <Link 
                  key={link.name} 
                  to={link.path} 
                  className="text-lg font-medium text-slate-800 py-2 border-b border-slate-50 flex items-center justify-between"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                  {link.name === 'Instant Estimate' && <Calculator className="w-4 h-4 text-blue-600" />}
                </Link>
              ))}
            </div>

            {/* Auth Actions Mobile */}
            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
              {!user ? (
                <>
                  <Button variant="outline" asChild onClick={() => setIsOpen(false)}>
                    <Link to="/login" className="flex items-center gap-2">
                      <LogIn className="w-4 h-4" /> Log In
                    </Link>
                  </Button>
                  <Button variant="outline" asChild onClick={() => setIsOpen(false)}>
                    <Link to="/signup" className="flex items-center gap-2">
                      <UserPlus className="w-4 h-4" /> Sign Up
                    </Link>
                  </Button>
                </>
              ) : (
                 <>
                  <Button variant="outline" onClick={() => { navigate('/crm'); setIsOpen(false); }}>
                    <LayoutDashboard className="w-4 h-4 mr-2" /> Dashboard
                  </Button>
                  <Button variant="ghost" onClick={handleSignOut} className="text-red-600 hover:text-red-700 hover:bg-red-50">
                    <LogOut className="w-4 h-4 mr-2" /> Log Out
                  </Button>
                 </>
              )}
            </div>

            {/* Primary Actions */}
            <div className="flex flex-col gap-3 pt-2">
              <a 
                href="tel:3213609704" 
                className="flex items-center justify-center gap-2 w-full py-3 bg-slate-100 text-slate-800 rounded-md font-semibold hover:bg-slate-200 transition-colors"
                onClick={() => handleCallClick('header_mobile_menu')}
              >
                <Phone className="w-5 h-5" />
                Call (321) 360-9704
              </a>
              <Button className="w-full py-6 text-lg bg-blue-600 hover:bg-blue-700" asChild onClick={() => handleBookClick('header_mobile_menu')}>
                <Link to="/booking">
                  <Calendar className="w-5 h-5 mr-2" />
                  Book Online
                </Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navigation;