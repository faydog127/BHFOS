import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import Pipeline from './Pipeline';
import TechDashboard from '@/pages/tech/TechDashboard';
import { useToast } from '@/components/ui/use-toast';

const CrmHome = () => {
    const [role, setRole] = useState(null);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();

    useEffect(() => {
        const checkRole = async () => {
            try {
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) return;

                // Check if user is a technician
                const { data: tech } = await supabase
                    .from('technicians')
                    .select('id')
                    .eq('user_id', user.id)
                    .single();

                if (tech) {
                    setRole('technician');
                } else {
                    setRole('office');
                }
            } catch (error) {
                console.error('Role check failed', error);
                setRole('office'); // Default to office on error
            } finally {
                setLoading(false);
            }
        };
        checkRole();
    }, []);

    if (loading) {
        return <div className="flex items-center justify-center h-screen bg-gray-50">Loading TVG OS...</div>;
    }

    // Role-based View Routing
    if (role === 'technician') {
        return <TechDashboard />;
    }

    // Default Office View is the Master Kanban
    return <Pipeline />;
};

export default CrmHome;