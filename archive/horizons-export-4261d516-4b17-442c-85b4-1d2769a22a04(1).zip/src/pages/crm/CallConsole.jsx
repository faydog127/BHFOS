/* 
  CALL CONSOLE - RESTORED MODULAR VERSION
  
  Integrates:
  - AiCopilot (Scripting, Objection Handling, Next Actions)
  - CallLog (History)
  - Supabase Data (partner_prospects)
*/
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { 
  Phone, MapPin, User, Building, ShieldCheck, 
  Search, Filter, RefreshCw, CheckCircle2, AlertCircle, ArrowRight
} from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { Card } from '@/components/ui/card';

// Restore Original Modular Components
import AiCopilot from '@/components/crm/call-console/AiCopilot';
import CallLog from '@/components/crm/call-console/CallLog';
import CardProgressionModal from '@/components/crm/kanban/CardProgressionModal';

const CallConsole = () => {
  const [prospects, setProspects] = useState([]);
  const [selectedLeadId, setSelectedLeadId] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filterText, setFilterText] = useState('');
  const [isCommitting, setIsCommitting] = useState(false);
  const [stageMoveLead, setStageMoveLead] = useState(null); // For modal trigger
  const { toast } = useToast();

  // Derived state
  const selectedLead = prospects.find(p => p.id === selectedLeadId);

  useEffect(() => {
    fetchProspects();
  }, []);

  const fetchProspects = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('partner_prospects')
        .select('*')
        .neq('status', 'converted')
        .neq('status', 'do_not_call')
        .order('score', { ascending: false })
        .limit(100);

      if (error) throw error;
      setProspects(data || []);
      if (data?.length > 0 && !selectedLeadId) {
        setSelectedLeadId(data[0].id);
      }
    } catch (err) {
      console.error('Error loading prospects:', err);
      toast({ title: 'Error', description: 'Failed to load prospect list', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleNextLead = () => {
      const currentIndex = prospects.findIndex(p => p.id === selectedLeadId);
      if (currentIndex < prospects.length - 1) {
          setSelectedLeadId(prospects[currentIndex + 1].id);
      } else {
          toast({ title: "End of List", description: "No more prospects in the current queue." });
      }
  };

  // Handle Action from AiCopilot (Save & Next)
  const handleActionComplete = async ({ final_outcome, notes, template }) => {
    if (!selectedLead) return;
    setIsCommitting(true);

    try {
      // 1. Log the Call in the 'calls' table
      const { error: logError } = await supabase.from('calls').insert({
        prospect_id: selectedLead.id,
        outcome: final_outcome,
        notes: notes || '',
        created_at: new Date().toISOString()
      });

      if (logError) throw logError;

      // 2. Update Prospect Status in 'partner_prospects' table
      const { error: updateError } = await supabase
        .from('partner_prospects')
        .update({ 
            status: final_outcome === 'booked' ? 'qualified' : 'contacted',
            last_contact_at: new Date().toISOString()
        })
        .eq('id', selectedLead.id);

      if (updateError) throw updateError;

      toast({ 
        title: 'Interaction Logged', 
        description: `Outcome: ${final_outcome}`,
        className: 'bg-green-50 border-green-200' 
      });
      
      // OPTIONAL: If result was positive, prompt for stage move
      if (['booked', 'qualified'].includes(final_outcome)) {
          // Keep current lead selected, show prompt
      } else {
          // Auto advance for simpler outcomes? 
          // For this request, we'll keep the lead active to allow stage move
      }

    } catch (err) {
      console.error('Error saving call:', err);
      toast({ title: 'Save Failed', description: err.message, variant: 'destructive' });
    } finally {
      setIsCommitting(false);
    }
  };

  const filteredProspects = prospects.filter(p => 
    p.business_name?.toLowerCase().includes(filterText.toLowerCase()) || 
    p.contact_name?.toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <div className="h-[calc(100vh-64px)] bg-slate-50 flex overflow-hidden">
      <Helmet>
        <title>Call Console | CRM</title>
      </Helmet>

      {/* --- LEFT: LEAD LIST --- */}
      <aside className="w-80 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-4 border-b border-slate-100">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-bold text-slate-700 flex items-center gap-2">
              <Phone className="h-4 w-4" /> Call Queue
            </h2>
            <Button variant="ghost" size="icon" onClick={fetchProspects} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
            <Input 
              placeholder="Search queue..." 
              className="pl-9 bg-slate-50" 
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
            />
          </div>
        </div>
        
        <ScrollArea className="flex-1">
          <div className="divide-y divide-slate-50">
            {filteredProspects.map((lead) => (
              <div 
                key={lead.id}
                onClick={() => setSelectedLeadId(lead.id)}
                className={`p-4 cursor-pointer hover:bg-slate-50 transition-all border-l-4 ${
                  selectedLeadId === lead.id 
                    ? 'bg-indigo-50 border-indigo-500' 
                    : 'border-transparent'
                }`}
              >
                <div className="flex justify-between items-start mb-1">
                  <span className={`font-semibold text-sm truncate ${selectedLeadId === lead.id ? 'text-indigo-900' : 'text-slate-700'}`}>
                    {lead.business_name}
                  </span>
                  <Badge variant="outline" className={lead.score > 80 ? 'text-green-600 bg-green-50' : 'text-slate-500'}>
                    {lead.score}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                  <User className="h-3 w-3" /> {lead.contact_name || 'Unknown'}
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <MapPin className="h-3 w-3" /> {lead.city || 'No Location'}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </aside>

      {/* --- CENTER: AI COPILOT --- */}
      <main className="flex-1 flex flex-col min-w-0">
        {selectedLead ? (
          <>
            {/* Lead Header */}
            <div className="bg-white border-b border-slate-200 px-6 py-4 shadow-sm z-10">
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-2xl font-bold text-slate-900">{selectedLead.business_name}</h1>
                  <div className="flex items-center gap-4 mt-2 text-sm text-slate-600">
                    <span className="flex items-center gap-1.5 px-2 py-1 bg-slate-100 rounded">
                      <User className="h-3 w-3" /> {selectedLead.contact_name}
                    </span>
                    <span className="flex items-center gap-1.5 px-2 py-1 bg-slate-100 rounded">
                      <MapPin className="h-3 w-3" /> {selectedLead.city}, {selectedLead.county}
                    </span>
                    <span className="flex items-center gap-1.5 px-2 py-1 bg-slate-100 rounded">
                      <ShieldCheck className="h-3 w-3" /> {selectedLead.service_type}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                    <Button 
                        size="lg" 
                        variant="outline"
                        className="border-blue-200 hover:bg-blue-50 text-blue-700"
                        onClick={() => setStageMoveLead(selectedLead)}
                    >
                        <ArrowRight className="h-4 w-4 mr-2" /> Move Stage
                    </Button>
                    <Button size="lg" className="bg-green-600 hover:bg-green-700 shadow-md" onClick={() => window.location.href = `tel:${selectedLead.phone}`}>
                        <Phone className="h-4 w-4 mr-2" /> Call
                    </Button>
                    <Button size="lg" variant="ghost" onClick={handleNextLead}>
                         Next &gt;
                    </Button>
                </div>
              </div>
            </div>

            {/* Copilot Interface */}
            <div className="flex-1 p-4 overflow-hidden">
              <AiCopilot 
                lead={selectedLead} 
                onCompleteAction={handleActionComplete}
                isCommitting={isCommitting}
              />
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center flex-col text-slate-400">
            <Search className="h-12 w-12 mb-2 opacity-20" />
            <p>Select a prospect to start calling</p>
          </div>
        )}
      </main>

      {/* --- RIGHT: HISTORY & INFO --- */}
      <aside className="w-80 bg-white border-l border-slate-200 flex flex-col">
        <div className="p-4 border-b border-slate-200 bg-slate-50">
          <h3 className="font-semibold text-sm text-slate-700 uppercase tracking-wider">Interaction History</h3>
        </div>
        <div className="flex-1 overflow-hidden">
          <CallLog lead={selectedLead} />
        </div>
      </aside>

      {/* Progression Modal */}
      {stageMoveLead && (
          <CardProgressionModal
              isOpen={!!stageMoveLead}
              onClose={() => setStageMoveLead(null)}
              entityId={stageMoveLead.id}
              entityType="lead" // Assuming prospects are leads for this context
              currentStageId="col_contacted" // Default starting point for console, usually they are being contacted
              onSuccess={() => {
                  fetchProspects();
                  toast({ title: "Updated", description: "Lead stage advanced." });
              }}
          />
      )}

    </div>
  );
};

export default CallConsole;