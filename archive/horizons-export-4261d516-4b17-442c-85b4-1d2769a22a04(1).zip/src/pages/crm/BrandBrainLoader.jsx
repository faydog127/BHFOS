import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, AlertTriangle, CheckCircle, Database, BrainCircuit, ShieldCheck, FileWarning, FileQuestion, BookOpen, HandMetal } from 'lucide-react';

const Dashboard = ({ stats }) => (
  <Card className="mb-8 bg-gray-800 border-gray-700">
    <CardHeader>
      <CardTitle className="flex items-center gap-2 text-white"><BrainCircuit /> Brand Brain Status</CardTitle>
      <CardDescription>Current row counts in foundational tables.</CardDescription>
    </CardHeader>
    <CardContent>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
        {stats.map(stat => (
          <div key={stat.label} className="p-4 bg-gray-900/50 rounded-lg">
            <p className="text-sm text-gray-400">{stat.label}</p>
            {stat.loading ? <Loader2 className="h-6 w-6 mx-auto my-1 animate-spin text-blue-400" /> : <p className="text-2xl font-bold text-white">{stat.count}</p>}
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const VerificationDialog = ({ table }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    const { data: result, error } = await supabase.from(table).select('*');
    if (error) {
      console.error(error);
    } else {
      setData(result);
    }
    setLoading(false);
  };

  return (
    <Dialog onOpenChange={(open) => open && fetchData()}>
      <DialogTrigger asChild>
        <Button variant="outline" className="mt-4">Verify Data</Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl h-[80vh] flex flex-col bg-gray-900 text-white border-gray-700">
        <DialogHeader>
          <DialogTitle>Verify Table: <span className="font-mono text-blue-400">{table}</span></DialogTitle>
          <DialogDescription>Showing current data in the table.</DialogDescription>
        </DialogHeader>
        <div className="flex-grow overflow-auto">
          {loading ? (
            <div className="flex items-center justify-center h-full"><Loader2 className="h-8 w-8 animate-spin" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  {data[0] && Object.keys(data[0]).map(key => <TableHead key={key}>{key}</TableHead>)}
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map(row => (
                  <TableRow key={row.id}>
                    {Object.entries(row).map(([key, value]) => (
                      <TableCell key={key} className="text-xs max-w-[200px] truncate">
                        {typeof value === 'object' && value !== null ? JSON.stringify(value) : String(value)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};


const ScriptSection = ({ title, description, icon, scriptKey, onRun, status }) => {
  const isRun = status.runStatus === 'success';
  const isLoading = status.runStatus === 'loading';

  const cardVariantClasses = {
    critical: 'border-red-500/50 bg-red-900/20',
    high: 'border-orange-500/50 bg-orange-900/20',
    medium: 'border-yellow-500/50 bg-yellow-900/20',
  };

  return (
    <Card className={`mb-6 ${cardVariantClasses[scriptKey]}`}>
      <CardHeader className="flex flex-row items-start justify-between">
        <div>
          <CardTitle className="flex items-center gap-3 text-xl text-white">{icon} {title}</CardTitle>
          <CardDescription className="mt-1">{description}</CardDescription>
        </div>
        <div>
          {isRun ? (
            <div className="flex items-center gap-2 text-green-400 font-semibold py-2 px-3 rounded-md bg-green-900/50">
              <ShieldCheck className="h-5 w-5" />
              <span>Loaded</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-yellow-400 font-semibold py-2 px-3 rounded-md bg-yellow-900/50">
                <FileQuestion className="h-5 w-5"/>
                <span>Pending</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {status.runStatus === 'error' && (
          <div className="mb-4 p-3 bg-red-900/50 border border-red-500/50 rounded-md text-red-300 text-sm">
            <p className="font-bold">Error:</p>
            <p className="font-mono">{status.message}</p>
          </div>
        )}
        {status.runStatus === 'success' && (
          <div className="mb-4 p-3 bg-green-900/50 border border-green-500/50 rounded-md text-green-300 text-sm">
            <p className="font-bold">Success:</p>
            <p>{status.message}</p>
          </div>
        )}
        <div className="flex items-center gap-4">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="lg" disabled={isLoading || isRun} className={isRun ? "bg-gray-500" : ""}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                {isRun ? "Data Loaded" : "Load Data"}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-gray-900 text-white border-gray-700">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2"><AlertTriangle className="text-yellow-400" /> Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will execute a SQL script to populate the database. This action is designed to be run once.
                  It will use `ON CONFLICT DO UPDATE` to avoid duplicates, but it's best to run on a clean slate.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => onRun(scriptKey)}>Proceed</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <VerificationDialog table={scriptKey === 'critical' ? 'brand_profile' : (scriptKey === 'high' ? 'services' : 'objections')} />
        </div>
      </CardContent>
    </Card>
  );
};

const BrandBrainLoader = () => {
  const { toast } = useToast();
  const [stats, setStats] = useState([
    { label: 'Brand Profile Entries', count: 0, loading: true },
    { label: 'Services Defined', count: 0, loading: true },
    { label: 'Objections Handled', count: 0, loading: true },
  ]);
  const [scriptStatuses, setScriptStatuses] = useState({
    critical: { runStatus: 'idle', message: null },
    high: { runStatus: 'idle', message: null },
    medium: { runStatus: 'idle', message: null },
  });

  const fetchStats = useCallback(async () => {
    setStats(prev => prev.map(s => ({ ...s, loading: true })));
    try {
      const [profile, services, objections] = await Promise.all([
        supabase.from('brand_profile').select('*', { count: 'exact', head: true }),
        supabase.from('services').select('*', { count: 'exact', head: true }),
        supabase.from('objections').select('*', { count: 'exact', head: true }),
      ]);

      setStats([
        { label: 'Brand Profile Entries', count: profile.count, loading: false },
        { label: 'Services Defined', count: services.count, loading: false },
        { label: 'Objections Handled', count: objections.count, loading: false },
      ]);
      
      // Update run status based on counts
      setScriptStatuses(prev => ({
        ...prev,
        critical: { ...prev.critical, runStatus: (profile.count || 0) > 0 ? 'success' : prev.critical.runStatus },
        high: { ...prev.high, runStatus: (services.count || 0) > 0 ? 'success' : prev.high.runStatus },
        medium: { ...prev.medium, runStatus: (objections.count || 0) > 0 ? 'success' : prev.medium.runStatus },
      }));

    } catch (error) {
      toast({ variant: 'destructive', title: 'Failed to fetch stats', description: error.message });
      setStats(prev => prev.map(s => ({ ...s, loading: false })));
    }
  }, [toast]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  const handleRunScript = async (scriptKey) => {
    setScriptStatuses(prev => ({ ...prev, [scriptKey]: { runStatus: 'loading', message: null } }));
    try {
      const { data, error } = await supabase.functions.invoke('execute-sql', {
        body: { scriptKey },
      });

      if (error) throw new Error(error.message);
      if (data.error) throw new Error(data.error);

      const successMessage = `${data.message}. Rows affected might be 0 if data already exists due to ON CONFLICT clause.`;
      setScriptStatuses(prev => ({ ...prev, [scriptKey]: { runStatus: 'success', message: successMessage } }));
      toast({ title: 'Script Successful', description: successMessage, action: <CheckCircle className="h-5 w-5 text-green-500"/> });
      
      await fetchStats();

    } catch (error) {
      setScriptStatuses(prev => ({ ...prev, [scriptKey]: { runStatus: 'error', message: error.message } }));
      toast({ variant: 'destructive', title: 'Script Execution Failed', description: error.message });
    }
  };

  return (
    <div className="h-full flex flex-col bg-gray-900 text-white p-4 md:p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-yellow-400 to-orange-400 text-transparent bg-clip-text">
          Brand Brain Initializer
        </h1>
        <p className="text-gray-400 mt-1">Utility to load foundational data into the AI knowledge base.</p>
      </header>

      <Dashboard stats={stats} />

      <main className="flex-grow">
        <ScriptSection
          title="CRITICAL: Core Brand Profile"
          description="Loads the entire brand identity, voice, rules, and protocols. This is the AI's core personality."
          icon={<AlertTriangle className="text-red-400" />}
          scriptKey="critical"
          onRun={handleRunScript}
          status={scriptStatuses.critical}
        />
        <ScriptSection
          title="HIGH: Service Offerings"
          description="Populates the 'services' table with your primary offerings, descriptions, and talking points."
          icon={<BookOpen className="text-orange-400" />}
          scriptKey="high"
          onRun={handleRunScript}
          status={scriptStatuses.high}
        />
        <ScriptSection
          title="MEDIUM: Objection Handling"
          description="Loads standard responses to common customer objections into the 'objections' table."
          icon={<HandMetal className="text-yellow-400" />}
          scriptKey="medium"
          onRun={handleRunScript}
          status={scriptStatuses.medium}
        />
      </main>
    </div>
  );
};

export default BrandBrainLoader;