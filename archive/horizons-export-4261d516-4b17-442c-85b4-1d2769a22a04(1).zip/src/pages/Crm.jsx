import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import CrmLayout from '@/components/CrmLayout';
import CrmHome from '@/pages/crm/CrmHome';
import Leads from '@/pages/crm/Leads';
import Jobs from '@/pages/crm/Jobs';
import Partners from '@/pages/crm/Partners';
import Inbox from '@/pages/crm/Inbox';
import Schedule from '@/pages/crm/Schedule';
import Customers from '@/pages/crm/Customers';
import MyMoney from '@/pages/crm/MyMoney';
import Payroll from '@/pages/crm/Payroll';
import Reporting from '@/pages/crm/Reporting';
import Marketing from '@/pages/crm/Marketing';
import SmartCallConsole from '@/pages/crm/SmartCallConsole';
import Settings from '@/pages/crm/Settings';
import ChatWidgetSettings from '@/pages/crm/ChatWidgetSettings';

const Crm = () => {
  return (
    <CrmLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/crm/dashboard" replace />} />
        <Route path="dashboard" element={<CrmHome />} />
        <Route path="leads" element={<Leads />} />
        <Route path="jobs" element={<Jobs />} />
        <Route path="partners" element={<Partners />} />
        <Route path="inbox" element={<Inbox />} />
        <Route path="schedule" element={<Schedule />} />
        <Route path="customers" element={<Customers />} />
        <Route path="money" element={<MyMoney />} />
        <Route path="payroll" element={<Payroll />} />
        <Route path="reporting" element={<Reporting />} />
        <Route path="marketing" element={<Marketing />} />
        <Route path="call-console" element={<SmartCallConsole />} />
        <Route path="chat-settings" element={<ChatWidgetSettings />} />
        <Route path="settings" element={<Settings />} />
        {/* Fallback for undefined sub-routes */}
        <Route path="*" element={<Navigate to="/crm/dashboard" replace />} />
      </Routes>
    </CrmLayout>
  );
};

export default Crm;