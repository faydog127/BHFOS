import React from 'react';
import { Link } from 'react-router-dom';
import { Edit, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';

const MobileCtaBar = () => {
    return (
        <motion.div 
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            transition={{ type: "spring", stiffness: 100, damping: 20 }}
            className="lg:hidden fixed bottom-0 left-0 right-0 bg-[#091e39] shadow-2xl z-40 grid grid-cols-2"
        >
            <Link 
                to="/contact" 
                className="flex flex-col items-center justify-center p-3 text-white bg-[#b52025] hover:bg-[#831618] transition-colors font-bold border-r border-[#173861]"
            >
                <Calendar className="h-5 w-5 mb-1" />
                <span className="text-xs font-medium uppercase tracking-wider">Book Audit</span>
            </Link>
            <Link 
                to="/contact" 
                className="flex flex-col items-center justify-center p-3 text-white hover:bg-[#173861] transition-colors"
            >
                <Edit className="h-5 w-5 mb-1" />
                <span className="text-xs font-medium uppercase tracking-wider">Free Check</span>
            </Link>
        </motion.div>
    );
};

export default MobileCtaBar;