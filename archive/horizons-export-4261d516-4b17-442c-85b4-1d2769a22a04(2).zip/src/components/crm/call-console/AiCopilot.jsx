import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, Copy, Send, Users, ChevronsRight, Zap, Bot, CheckCircle, Mail, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from '@/components/ui/use-toast';
import { invoke } from '@/lib/api';

// --- Call Flow Engine Data ---
const callFlows = {
    'Decision Maker': {
        start: {
            text: "Hi, this is [Rep Name] with The Vent Guys. I saw you just pulled a mechanical permit, and I'm calling to see if you need a certified post-construction duct cleaning to avoid a failed inspection.",
            responses: { 'Not Interested': 'objection_not_interested', 'What is this about?': 'clarification_what_is_this', 'We do it ourselves': 'objection_in_house', },
        },
        objection_not_interested: { text: "I understand. Many GCs say that at first. This is actually about passing final inspections faster. We provide the photo documentation that inspectors are now requiring for duct hygiene. Can I send you a one-pager on it?", responses: { 'Okay, send it': 'action_send_info', 'Still not interested': 'end_call_polite', 'How much is it?': 'objection_price', }, },
        objection_in_house: { text: "That's great for general cleaning. We specialize in the NADCA-certified, photo-documented deep cleaning that prevents dust-related callbacks and satisfies inspectors. It frees your crew up for punch-list items. Is your team currently NADCA certified?", responses: { 'No, they are not': 'pivot_certification_value', 'Yes, they are': 'objection_already_certified', 'Send me info': 'action_send_info', }, },
        clarification_what_is_this: { text: "We're a specialty contractor that helps HVAC partners and GCs pass inspections with certified duct cleaning. We noticed your recent permit and wanted to offer our services to ensure you don't face any delays. Are you the right person to speak to about this?", responses: { 'Yes, I am': 'start', 'No, talk to [X]': 'action_get_referral', 'Not interested': 'objection_not_interested', } },
        objection_price: { text: "It varies by the size of the job, but for most residential projects, it's a flat-rate that's far less than the cost of a failed inspection and a crew sitting idle. We can get you a firm quote in 5 minutes. What's the square footage?", responses: { 'Give Quote': 'action_gather_quote_info', 'Too expensive': 'end_call_polite', 'Send info first': 'action_send_info', } },
        pivot_certification_value: { text: "That's where we come in. We provide that certification so you're covered. It's a small price for peace of mind and avoiding project delays. We can handle the next job on your schedule to show you how seamless it is.", responses: { 'Book a job': 'action_book_job', 'Send me info': 'action_send_info', 'Not right now': 'end_call_polite', } },
        action_send_info: { text: "Great. What's the best email? I'll send it over right now. I'll also include a link to my calendar in case you want to book a 15-min chat.", isEnd: false, responses: {'Next Lead': 'start'} },
        end_call_polite: { text: "No problem at all. I appreciate your time. Have a great day.", isEnd: true, responses: {'Next Lead': 'start'} },
        action_get_referral: { text: "Thank you! Could you provide their contact information?", isEnd: false, responses: {'Next Lead': 'start'} },
        action_gather_quote_info: { text: "Perfect. Just need the square footage and number of systems to get you that quote.", isEnd: false, responses: {'Next Lead': 'start'} },
        action_book_job: { text: "Excellent. Let's get your project address and I can lock in a time for our crew.", isEnd: false, responses: {'Next Lead': 'start'} },
        objection_already_certified: { text: "That's fantastic, you're ahead of the curve! In that case, we can serve as a backup for when your team is overloaded. Can I send our capacity one-pager for your files?", responses: {'Okay, send it': 'action_send_info', 'No thanks': 'end_call_polite'} },
    },
    'Gatekeeper': {
        start: { text: "Hi, I'm calling from The Vent Guys for [DM Name if known]. We're a specialty contractor that works with GCs in the area. Is he/she available?", responses: { "What's this regarding?": 'clarify_purpose', 'They are busy': 'offer_callback', 'Not here': 'offer_callback' }, },
        clarify_purpose: { text: "It's about a recent mechanical permit for one of your projects. We help GCs avoid inspection delays with certified duct cleaning. It's a quick 2-minute call. Could you put me through?", responses: { "Okay, I'll transfer you": 'end_flow_positive', 'Let me take a message': 'action_leave_message' }, },
        offer_callback: { text: "No problem. Is there a better time to reach them? Or can I leave my direct line and a brief message?", responses: { 'Take a message': 'action_leave_message', "Try back at [Time]": 'end_flow_positive' }, },
        action_leave_message: { text: "Great. Please let them know [Rep Name] from The Vent Guys called about the [Project Name] permit. My number is [Rep Phone]. Thank you!", isEnd: true, responses: {'Next Lead': 'start'} },
        end_flow_positive: { text: "Thank you for your help!", isEnd: true, responses: {'Next Lead': 'start'} },
    },
};

const ManualQueryBox = () => {
    const { toast } = useToast();
    const [query, setQuery] = useState("");
    const handleQuery = () => { if (!query.trim()) return; toast({ title: "🚧 Manual Query Sent!", description: "This feature isn't fully implemented yet, but your query was: " + query }); setQuery(""); };
    return (<div className="p-4 border-t border-gray-200"> <Label htmlFor="ai-query" className="text-sm font-semibold text-gray-600 mb-2 block">Manual Query</Label> <div className="flex items-center space-x-2"> <Input id="ai-query" type="text" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Paste what prospect said..." /> <Button size="icon" onClick={handleQuery} className="bg-cyan-500 hover:bg-cyan-600 shrink-0"> <Send className="h-4 w-4" /> </Button> </div> </div>);
};

const SuggestionsPanel = ({ suggestions, isLoading, onSelect, selectedTemplate }) => {
    if (isLoading) return <div className="text-center p-4 text-gray-500">Loading AI Suggestions...</div>;
    if (!suggestions || suggestions.length === 0) return <div className="text-center p-4 text-gray-500">No suggestions for this outcome.</div>;

    const ChannelIcons = ({ channels }) => (<div className="flex items-center gap-2"> {channels.includes('email') && <Mail className="h-4 w-4 text-gray-500" />} {channels.includes('sms') && <MessageSquare className="h-4 w-4 text-gray-500" />} </div>);

    return (
        <div className="space-y-2">
            {suggestions.map((s, i) => (
                <motion.div key={s.template_id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                    <Card className={`cursor-pointer transition-all h-full ${selectedTemplate?.template_id === s.template_id ? 'ring-2 ring-blue-500 shadow-md' : 'hover:shadow-sm'}`} onClick={() => onSelect(s)}>
                        <CardHeader className="flex flex-row items-center justify-between p-3">
                            <CardTitle className="text-sm font-semibold">{s.template_id}</CardTitle>
                            {selectedTemplate?.template_id === s.template_id && <CheckCircle className="h-5 w-5 text-blue-500 flex-shrink-0" />}
                        </CardHeader>
                        <CardContent className="p-3 pt-0"> <p className="text-xs text-gray-500 mb-2">{s.reason}</p> <ChannelIcons channels={s.channels} /> </CardContent>
                    </Card>
                </motion.div>
            ))}
        </div>
    );
};

const AiCopilot = ({ lead, onCompleteAction, isCommitting }) => {
    const { toast } = useToast();
    const [scriptType, setScriptType] = useState('Decision Maker');
    const [currentNodeKey, setCurrentNodeKey] = useState('start');
    const callFlow = callFlows[scriptType];
    const currentNode = callFlow[currentNodeKey];

    const [finalOutcome, setFinalOutcome] = useState('');
    const [notes, setNotes] = useState('');
    const [suggestions, setSuggestions] = useState([]);
    const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState(null);

    const handleResponse = useCallback((nextNodeKey) => {
        if (!nextNodeKey) return;
        setCurrentNodeKey(nextNodeKey);
        toast({ title: "Pivoting script...", description: `Loading response for "${Object.keys(currentNode.responses).find(key => currentNode.responses[key] === nextNodeKey)}"`, duration: 2000 });
    }, [currentNode, toast]);
    
    const fetchSuggestions = useCallback(async (outcome) => {
        if (!outcome || !lead) return;
        setIsLoadingSuggestions(true);
        setSuggestions([]);
        setSelectedTemplate(null);
        const { ok, data, error } = await invoke('smartdocs-suggest', { body: JSON.stringify({ lead_id: lead.id, final_outcome: outcome }) });
        if (ok && data.suggestions) {
            setSuggestions(data.suggestions);
            if (data.suggestions.length > 0) setSelectedTemplate(data.suggestions[0]);
        } else {
            toast({ variant: 'destructive', title: 'Error fetching suggestions', description: error });
            setSuggestions([]);
        }
        setIsLoadingSuggestions(false);
    }, [lead, toast]);

    useEffect(() => {
        if (finalOutcome) fetchSuggestions(finalOutcome); else { setSuggestions([]); setSelectedTemplate(null); }
    }, [finalOutcome, fetchSuggestions]);

    const handleCommit = () => {
        if (!finalOutcome) {
            toast({ variant: 'destructive', title: 'Action Required', description: 'Please select a call outcome.' });
            return;
        }
        onCompleteAction({ final_outcome: finalOutcome, notes: notes, template: selectedTemplate });
    };

    useEffect(() => {
        const handleKeyDown = (event) => {
            if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') return;
            const key = parseInt(event.key, 10);
            if (key >= 1 && key <= 3) {
                const responseKeys = Object.keys(currentNode.responses || {});
                if (responseKeys[key - 1]) handleResponse(currentNode.responses[responseKeys[key - 1]]);
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [currentNode, handleResponse]);
    
    useEffect(() => { setCurrentNodeKey('start'); }, [lead, scriptType]);

    const onCopy = (text) => {
        navigator.clipboard.writeText(text);
        toast({ title: "Copied ✓", description: "Script copied to clipboard.", duration: 2000 });
    };

    const responseKeys = Object.keys(currentNode?.responses || {});

    return (
        <Card className="h-full flex flex-col bg-white text-gray-900 shadow-lg">
            <CardHeader className="pb-3 border-b">
                <CardTitle className="flex items-center"><BrainCircuit className="mr-2 text-blue-500"/> AI Call Flow</CardTitle>
                <CardDescription>Your real-time coach & playbook</CardDescription>
            </CardHeader>
            
            <div className="flex-1 flex flex-col overflow-hidden">
                <div className="p-4 space-y-4 overflow-y-auto">
                    {/* Persona & Script */}
                    <div className="space-y-2">
                        <Label>Persona</Label>
                        <div className="flex items-center space-x-2">
                            {Object.keys(callFlows).map(type => (
                                <Button key={type} size="sm" variant={scriptType === type ? 'default' : 'outline'} className="h-8" onClick={() => setScriptType(type)}>
                                    {type === 'Decision Maker' ? <Users size={14} className="mr-2" /> : <ChevronsRight size={14} className="mr-2" />}
                                    {type}
                                </Button>
                            ))}
                        </div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-lg group border flex-1 flex flex-col">
                        <AnimatePresence mode="wait">
                            <motion.div key={currentNodeKey} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -15 }} transition={{ duration: 0.25 }} className="flex-1 flex flex-col">
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="text-xs font-bold tracking-wider uppercase text-blue-600">AI-Generated Script</h3>
                                    <Button size="icon" variant="ghost" className="h-7 w-7 ml-2 -mt-1 opacity-50 group-hover:opacity-100 transition-opacity" onClick={() => onCopy(currentNode.text)}> <Copy className="h-4 w-4" /> </Button>
                                </div>
                                <p className="text-base text-gray-800 leading-relaxed flex-1">{currentNode?.text.replace('[Rep Name]', lead?.rep_name || 'your name')}</p>
                            </motion.div>
                        </AnimatePresence>
                    </div>

                    {/* Customer Response */}
                    <div className="space-y-2">
                        <Label>Customer Response (Hotkeys: 1, 2, 3)</Label>
                        <div className="grid grid-cols-1 gap-2">
                            {responseKeys.map((key, index) => (
                                <Button key={key} variant="outline" className="justify-start text-left h-auto py-2" onClick={() => handleResponse(currentNode.responses[key])}>
                                    <span className="font-mono text-xs bg-gray-200 text-gray-700 rounded px-1.5 py-0.5 mr-3">{index + 1}</span> {key}
                                </Button>
                            ))}
                        </div>
                    </div>
                </div>

                {/* After Call Log Section */}
                <div className="p-4 bg-gray-50 border-t space-y-4">
                    <h3 className="font-semibold text-md">After Call Log</h3>
                    <div className="grid grid-cols-1 gap-4">
                        <Select onValueChange={setFinalOutcome} value={finalOutcome}>
                            <SelectTrigger className="h-11 text-base"><SelectValue placeholder="Select Call Outcome..." /></SelectTrigger>
                            <SelectContent>{["booked", "qualified", "nurture", "lost", "no_answer", "voicemail"].map(v => <SelectItem key={v} value={v}>{v.charAt(0).toUpperCase() + v.slice(1)}</SelectItem>)}</SelectContent>
                        </Select>
                        <Textarea placeholder="Call notes for summary..." value={notes} onChange={(e) => setNotes(e.target.value)} className="h-20 text-base" />
                    </div>
                    
                    <AnimatePresence>
                    {finalOutcome && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                            <div className="space-y-3 pt-4">
                                <h3 className="font-semibold text-sm flex items-center"><Bot className="mr-2 text-blue-500" /> AI Suggested Actions</h3>
                                <div className="max-h-32 overflow-y-auto pr-2">
                                    <SuggestionsPanel suggestions={suggestions} isLoading={isLoadingSuggestions} onSelect={setSelectedTemplate} selectedTemplate={selectedTemplate} />
                                </div>
                            </div>
                        </motion.div>
                    )}
                    </AnimatePresence>
                </div>
            </div>

            {/* Commit Button */}
            <div className="p-4 bg-gray-100 border-t mt-auto">
                <Button onClick={handleCommit} size="lg" className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold text-lg" disabled={isCommitting || !finalOutcome || isLoadingSuggestions}>
                    <Zap className="mr-2 h-5 w-5" />
                    {isCommitting ? 'Committing...' : 'Send & Log'}
                </Button>
            </div>
             <ManualQueryBox />
        </Card>
    );
};

export default AiCopilot;