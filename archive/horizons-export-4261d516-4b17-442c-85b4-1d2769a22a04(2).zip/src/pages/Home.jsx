
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, CheckCircle, Award, Phone, Calendar, Wind, ArrowRight, Send, Mail, MapPin, TestTube } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Home = () => {
  const { toast } = useToast();
  
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = React.useState(false);


  const handleScrollToContact = (e) => {
    e.preventDefault();
    document.getElementById('contact-section').scrollIntoView({ behavior: 'smooth' });
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const payload = { ...formData, service: 'free-air-check', status: 'new', created_at: new Date().toISOString() };

    try {
        // Using direct insert instead of edge function for simplicity and immediate feedback
        const { data, error } = await supabase
          .from('submissions')
          .insert([payload]);

        if (error) {
            throw error;
        }

        toast({
            title: "Message Sent!",
            description: "We'll contact you within 24 hours to schedule your Free Air Check.",
        });
        setFormData({ name: '', email: '', phone: '', message: '' });
    } catch (error) {
        toast({
            variant: 'destructive',
            title: "Submission Failed",
            description: `There was a problem: ${error.message}`,
        });
    } finally {
        setIsSubmitting(false);
    }
  };
  
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "The Vent Guys",
    "url": "https://www.yourwebsite.com",
    "logo": "https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/08435323de98fe5fafabc3ec7d834166.png",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-321-360-9704",
      "contactType": "Customer Service"
    }
  };

  return (
    <>
      <Helmet>
        <title>The Vent Guys - NADCA Certified Air Duct Cleaning | Brevard County, FL</title>
        <meta name="description" content="Veteran-owned, NADCA-certified air duct cleaning and IAQ testing in Brevard County, FL. Improve your indoor air quality today. Book your IAQ audit now!" />
        <script type="application/ld+json">{JSON.stringify(organizationSchema)}</script>
      </Helmet>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1B263B] via-[#2a3f5f] to-[#1B263B] text-white py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.4"%3E%3Cpath d="M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')` }}></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <motion.div 
              initial={{ opacity: 0, y: -20 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ duration: 0.8 }}
            >
              <div className="inline-block bg-[#D7263D] text-white px-4 py-2 rounded-full text-sm font-semibold mb-6">
                NADCA Certified • Veteran Owned
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                Protect Your Home from the Air You Can't See
              </h1>
              <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
                Breathe easier with NADCA-certified air duct cleaning and IAQ solutions in Brevard County. We deliver results you can see and feel.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button onClick={handleScrollToContact} size="lg" className="bg-[#D7263D] hover:bg-[#b51f31] text-white px-8 py-6 text-lg font-semibold shadow-xl hover:shadow-2xl transition-all transform hover:scale-105">
                  <Calendar className="mr-2 h-5 w-5" />
                  Book Your Free Air Check
                </Button>
                <a href="tel:+13213609704">
                  <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-[#1B263B] px-8 py-6 text-lg font-semibold transition-all transform hover:scale-105">
                    <Phone className="mr-2 h-5 w-5" />
                    (321) 360-9704
                  </Button>
                </a>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Block 1 — Why Clean Air Matters */}
      <motion.section
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.6 }}
        className="py-20 bg-white"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-center md:text-left">
              <h2 className="text-3xl md:text-4xl font-bold text-[#1B263B] mb-4">Why Clean Air Matters More Than You Think</h2>
              <p className="text-lg font-semibold text-[#4DA6FF] mb-6">Your home's air system isn't just comfort — it's health protection.</p>
              <p className="text-gray-600 mb-8">
                Every time your system runs, it circulates more than air — it moves what's inside your ducts. Dust, humidity, and debris collect quietly until your filters can't keep up. We help homeowners and property managers protect their spaces through verified mechanical hygiene, restoring true indoor air quality the way national standards intended.
              </p>
              <Button onClick={handleScrollToContact} size="lg" className="bg-[#D7263D] hover:bg-[#4DA6FF] text-white">
                Book Your Free Air Check
              </Button>
            </div>
            <div>
              <img className="rounded-lg shadow-xl w-full h-auto" alt="Hispanic mother and teenage daughter review air quality report after IAQ testing in their modern Central Florida kitchen" src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7" />
            </div>
          </div>
        </div>
      </motion.section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1B263B]">Our Core Services</h2>
            <p className="text-xl text-gray-600 mt-4">Solutions for healthier indoor air.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {/* IAQ Testing */}
            <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all">
              <div className="p-6">
                <TestTube className="h-12 w-12 text-[#D7263D] mb-4" />
                <h3 className="text-2xl font-bold text-[#1B263B] mb-3">IAQ Testing</h3>
                <p className="text-gray-600 mb-4">Comprehensive indoor air quality assessment to identify and solve air quality issues.</p>
                <Link to="/services"><Button variant="outline" className="border-[#D7263D] text-[#D7263D] hover:bg-[#D7263D] hover:text-white">Learn More</Button></Link>
              </div>
            </div>
            {/* Air Duct Cleaning */}
            <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all">
              <div className="p-6">
                <Wind className="h-12 w-12 text-[#D7263D] mb-4" />
                <h3 className="text-2xl font-bold text-[#1B263B] mb-3">Air Duct Cleaning</h3>
                <p className="text-gray-600 mb-4">NADCA-certified cleaning removes dust, allergens, and contaminants from your HVAC system.</p>
                <Link to="/services"><Button variant="outline" className="border-[#D7263D] text-[#D7263D] hover:bg-[#D7263D] hover:text-white">Learn More</Button></Link>
              </div>
            </div>
            {/* Dryer Vent Cleaning */}
            <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all">
              <div className="p-6">
                <Award className="h-12 w-12 text-[#D7263D] mb-4" />
                <h3 className="text-2xl font-bold text-[#1B263B] mb-3">Dryer Vent Cleaning</h3>
                <p className="text-gray-600 mb-4">Prevent fire hazards and improve dryer efficiency with professional vent cleaning.</p>
                <Link to="/services"><Button variant="outline" className="border-[#D7263D] text-[#D7263D] hover:bg-[#D7263D] hover:text-white">Learn More</Button></Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Block 2 — What We Stand For */}
      <motion.section
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.6 }}
        className="py-20 bg-[#1B263B] text-white"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="md:order-2 text-center md:text-left">
              <div className="w-16 h-1 bg-[#D7263D] mb-4"></div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Mechanical Hygiene Done Right. Every Time.</h2>
              <p className="text-lg font-semibold text-gray-300 mb-6">Certified. Documented. Done Right. It's not just a slogan — it's how we work.</p>
              <p className="text-gray-400 mb-8">
                We believe indoor air should be as safe as the water you drink. That's why every job follows NADCA-certified mechanical hygiene standards — complete source removal, HEPA containment, and photo verification for proof of performance. No shortcuts. No surface dusting. Just honest, professional work built to protect your air, your home, and your reputation.
              </p>
              <Link to="/mechanical-hygiene-vs-duct-cleaning">
                <Button size="lg" className="bg-[#C2F5E9] text-[#D7263D] hover:bg-white">
                  See Our Process
                </Button>
              </Link>
            </div>
            <div className="md:order-1">
              <img className="rounded-lg shadow-xl w-full h-auto" alt="African American homeowner smiling while a Vent Guys technician explains the duct cleaning process in a Central Florida home" src="https://images.unsplash.com/photo-1581888224138-31a77a403d7e" />
            </div>
          </div>
        </div>
      </motion.section>

      {/* Block 3 — Proof in Every Project */}
      <motion.section
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true, amount: 0.5 }}
        transition={{ duration: 0.6 }}
        className="py-20 bg-[#F9FAFB]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-[#1B263B] mb-4">Proof in Every Project</h2>
          <p className="text-lg font-semibold text-[#D7263D] mb-6">We don't claim clean — we show it.</p>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Every service comes with before-and-after photo documentation and a Clean Air Verification Report. That means you see exactly what was removed and how your system improved. Because real trust isn't built with words — it's built with evidence.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-8">
            <img className="rounded-lg shadow-md w-full" alt="Before air duct cleaning: a duct interior thick with dust and debris" src="https://images.unsplash.com/photo-1616111112354-f7a67870dc12" />
            <img className="rounded-lg shadow-md w-full" alt="After air duct cleaning: a pristine, clean duct interior showing restored airflow" src="https://images.unsplash.com/photo-1574334292321-4844f63aefef" />
          </div>
          <Link to="/gallery">
            <Button size="lg" className="bg-[#D7263D] hover:bg-[#b51f31] text-white rounded-xl px-8">
              View Our Results
            </Button>
          </Link>
        </div>
      </motion.section>
      
      {/* Contact Form Section */}
      <section id="contact-section" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-center md:text-left"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-[#1B263B] mb-4">Get Your Free Air Check</h2>
              <p className="text-lg text-gray-600 mb-6">
                See what's hiding in your ducts. Our 15-minute visual inspection is fast, free, and comes with zero obligation.
              </p>
              <div className="space-y-4 text-left">
                <div className="flex items-start gap-4">
                    <Mail className="h-6 w-6 text-[#D7263D] mt-1 flex-shrink-0" />
                    <div>
                        <h3 className="font-semibold text-[#1B263B]">Email</h3>
                        <a href="mailto:info@vent-guys.com" className="text-gray-600 hover:text-[#D7263D]">info@vent-guys.com</a>
                    </div>
                </div>
                <div className="flex items-start gap-4">
                    <Phone className="h-6 w-6 text-[#D7263D] mt-1 flex-shrink-0" />
                    <div>
                        <h3 className="font-semibold text-[#1B263B]">Phone</h3>
                        <a href="tel:+13213609704" className="text-gray-600 hover:text-[#D7263D]">(321) 360-9704</a>
                    </div>
                </div>
                <div className="flex items-start gap-4">
                    <MapPin className="h-6 w-6 text-[#D7263D] mt-1 flex-shrink-0" />
                    <div>
                        <h3 className="font-semibold text-[#1B263B]">Location</h3>
                        <p className="text-gray-600">Serving Brevard County, FL</p>
                    </div>
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-gray-50 p-8 rounded-lg shadow-lg"
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">Name *</label>
                  <Input id="name" type="text" name="name" value={formData.name} onChange={handleChange} required placeholder="Your full name" disabled={isSubmitting}/>
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
                  <Input id="email" type="email" name="email" value={formData.email} onChange={handleChange} required placeholder="your@email.com" disabled={isSubmitting}/>
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">Phone</label>
                  <Input id="phone" type="tel" name="phone" value={formData.phone} onChange={handleChange} placeholder="(555) 123-4567" disabled={isSubmitting}/>
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">Message</label>
                  <Textarea id="message" name="message" value={formData.message} onChange={handleChange} rows={3} placeholder="Tell us about your air quality concerns..." disabled={isSubmitting}/>
                </div>
                <Button type="submit" size="lg" className="w-full bg-[#D7263D] hover:bg-[#b51f31] text-white" disabled={isSubmitting}>
                  <Send className="mr-2 h-5 w-5" />
                  {isSubmitting ? 'Sending...' : 'Request My Free Check'}
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </section>

    </>
  );
};

export default Home;
