import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Contact = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.functions.invoke('submit-form', {
        body: JSON.stringify(formData),
      });

      if (error) {
        throw error;
      }

      toast({
        title: "Quote Request Received! 🎉",
        description: "We'll contact you within 24 hours to discuss your needs and provide a free quote.",
      });

      setFormData({
        name: '',
        email: '',
        phone: '',
        service: '',
        message: '',
      });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: "Submission Failed",
        description: "There was a problem submitting your request. Please try again.",
      });
      console.error('Submission error:', error);
    } finally {
      setLoading(false);
    }
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'Phone',
      content: '(321) 555-0123',
      link: 'tel:3215550123',
    },
    {
      icon: Mail,
      title: 'Email',
      content: 'info@cleanairpros.com',
      link: 'mailto:info@cleanairpros.com',
    },
    {
      icon: MapPin,
      title: 'Location',
      content: 'Titusville, Florida',
      link: null,
    },
    {
      icon: Clock,
      title: 'Hours',
      content: 'Mon-Sat: 8AM-6PM',
      link: null,
    },
  ];

  return (
    <>
      <Helmet>
        <title>Contact Us - Get Free Quote | Clean Air Pros Titusville, FL</title>
        <meta name="description" content="Contact Clean Air Pros for a free quote on air duct or dryer vent cleaning in Titusville, FL. Fast response, professional service. Call (321) 555-0123." />
      </Helmet>

      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Get Your Free Quote</h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Ready to improve your indoor air quality? Contact us today for a free, no-obligation quote.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-1"
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Contact Information</h2>
              <p className="text-gray-700 mb-8">
                We're here to answer your questions and provide expert advice. Reach out to us using any of the methods below.
              </p>

              <div className="space-y-6">
                {contactInfo.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start space-x-4"
                  >
                    <div className="bg-blue-100 p-3 rounded-lg flex-shrink-0">
                      <item.icon className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{item.title}</h3>
                      {item.link ? (
                        <a
                          href={item.link}
                          className="text-gray-700 hover:text-blue-600 transition-colors"
                        >
                          {item.content}
                        </a>
                      ) : (
                        <p className="text-gray-700">{item.content}</p>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-8 p-6 bg-blue-50 rounded-xl">
                <h3 className="font-bold text-gray-900 mb-3">Service Areas</h3>
                <p className="text-gray-700 text-sm">
                  We proudly serve Titusville and surrounding areas in Brevard County, Florida. Contact us to confirm service availability in your area.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-2"
            >
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Request a Free Quote</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="John Doe"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="john@example.com"
                        className="mt-2"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="(321) 555-0123"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="service">Service Needed *</Label>
                      <select
                        id="service"
                        name="service"
                        required
                        value={formData.service}
                        onChange={handleChange}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select a service</option>
                        <option value="free-air-check">Free Air Check</option>
                        <option value="air-duct">Air Duct Cleaning</option>
                        <option value="dryer-vent">Dryer Vent Cleaning</option>
                        <option value="iaq-testing">IAQ Testing</option>
                        <option value="not-sure">Not Sure</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="message">Additional Details</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Tell us about your property, any specific concerns, or questions you have..."
                      rows={5}
                      className="mt-2"
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    disabled={loading}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    {loading ? 'Submitting...' : (
                      <>
                        <Send className="h-5 w-5 mr-2" />
                        Request Free Quote
                      </>
                    )}
                  </Button>

                  <p className="text-sm text-gray-600 text-center">
                    We'll respond within 24 hours. Your information is kept confidential.
                  </p>
                </form>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Why Choose Clean Air Pros?
            </h2>
            <div className="grid md:grid-cols-3 gap-8 mt-12">
              <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="text-4xl font-bold text-blue-600 mb-2">24hrs</div>
                <h3 className="font-semibold text-gray-900 mb-2">Fast Response</h3>
                <p className="text-gray-600">We respond to all inquiries within 24 hours</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="text-4xl font-bold text-blue-600 mb-2">100%</div>
                <h3 className="font-semibold text-gray-900 mb-2">Satisfaction Guaranteed</h3>
                <p className="text-gray-600">We stand behind our work with a complete guarantee</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="text-4xl font-bold text-blue-600 mb-2">15+</div>
                <h3 className="font-semibold text-gray-900 mb-2">Years Experience</h3>
                <p className="text-gray-600">Veteran-owned with extensive industry expertise</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Contact;