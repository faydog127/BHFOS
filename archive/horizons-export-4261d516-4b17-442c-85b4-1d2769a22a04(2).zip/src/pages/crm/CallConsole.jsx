import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import LeadList from '@/components/crm/call-console/LeadList';
import PreCallBrief from '@/components/crm/call-console/PreCallBrief';
import AiCopilot from '@/components/crm/call-console/AiCopilot';
import FastRepChecklist from '@/components/crm/call-console/FastRepChecklist';
import CallLog from '@/components/crm/call-console/CallLog';
import B2BLeadCaptureForm from '@/components/crm/call-console/B2BLeadCaptureForm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { invoke, logAndSendAction } from '@/lib/api';

const CallConsole = () => {
    const [leads, setLeads] = useState([]);
    const [selectedLead, setSelectedLead] = useState(null);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('Hot');
    const [isFindingLeads, setIsFindingLeads] = useState(false);
    const [searchCategory, setSearchCategory] = useState('hvac');
    const [isTrainingMode, setIsTrainingMode] = useState(false);
    const [isCommitting, setIsCommitting] = useState(false);
    
    const { toast } = useToast();
    
    const scoreProp = isTrainingMode ? 'kaqi_score' : 'pqi';

    const fetchLeads = useCallback(async () => {
        setLoading(true);
        const fromTable = isTrainingMode ? 'training_leads' : 'v_leads_public';
        const scoreColumn = isTrainingMode ? 'kaqi_score' : 'pqi';
        
        let query = supabase.from(fromTable).select('*');
        
        if (!isTrainingMode) {
             query = query.in('pipeline_stage', ['New Lead', 'Attempting Contact', 'Discovery Call', 'New Intel', 'Nurture']);
        }

        const applyFilter = (q, score) => {
            if (activeTab === 'Hot') return q.gte(score, 80);
            if (activeTab === 'Warm') return q.gte(score, 60).lt(score, 80);
            if (activeTab === 'Nurture') return q.lt(score, 60);
            return q;
        };

        query = applyFilter(query, scoreColumn);
        
        const { data, error } = await query.order(scoreColumn, { ascending: false });

        if (error) {
            toast({ variant: 'destructive', title: 'Error fetching leads', description: error.message });
            setLeads([]);
        } else {
            const mappedData = data.map(l => ({
                ...l,
                id: l.id,
                name: l.company || `${l.first_name || ''} ${l.last_name || ''}`.trim(),
                [scoreProp]: l[scoreColumn] || l.pqi || 0,
            }));
            setLeads(mappedData);
            
            if (mappedData.length > 0) {
                if (!selectedLead || !mappedData.some(l => l.id === selectedLead.id)) {
                    setSelectedLead(mappedData[0]);
                }
            } else {
                 setSelectedLead(null);
            }
        }
        setLoading(false);
    }, [activeTab, toast, isTrainingMode, scoreProp, selectedLead]);

    useEffect(() => {
        fetchLeads();
    
        const channelName = `call-console-realtime-${isTrainingMode ? 'training' : 'live'}`;
        const tableName = isTrainingMode ? 'training_leads' : 'leads';
        const channel = supabase.channel(channelName)
          .on('postgres_changes', { event: '*', schema: 'public', table: tableName }, (payload) => {
            fetchLeads();
          })
          .subscribe();
    
        return () => {
          supabase.removeChannel(channel);
        };
    }, [fetchLeads, isTrainingMode]);
    
    const handleFindNewLeads = async () => {
        setIsFindingLeads(true);
        toast({ title: 'AI Deep Search Initiated...', description: `Searching for ${isTrainingMode ? 'training' : 'live'} leads in category: ${searchCategory}` });
        try {
            const { ok, data, error } = await invoke('find-and-score-leads', {
                body: JSON.stringify({ category: searchCategory, training: isTrainingMode })
            });
            if (!ok) throw new Error(data?.error || error);
            toast({ title: 'AI Search Complete!', description: data.message || `${data.inserted_leads} leads added.`, duration: 5000 });
            fetchLeads();
        } catch(e) {
            toast({ variant: 'destructive', title: 'Failed to find new leads', description: e.message });
        }
        setIsFindingLeads(false);
    };

    const handleSelectLead = (lead) => {
        if (selectedLead?.id !== lead.id) {
            setSelectedLead(lead);
        }
    };
    
    const handleToggleTrainingMode = (checked) => {
        setIsTrainingMode(checked);
        setSelectedLead(null);
        setLeads([]);
    };

    const handleCommitAction = async (actionData) => {
        if (!selectedLead) return;
        setIsCommitting(true);

        const { final_outcome, notes, template } = actionData;

        const payload = {
            lead_id: selectedLead.id,
            final_outcome: final_outcome,
            notes: notes,
            template_id: template?.template_id,
            channels: template?.channels,
            suggestion_source: template?.reason,
            merge_data: {
                first_name: selectedLead.first_name || selectedLead.name.split(' ')[0],
                rep_name: "Erron",
            }
        };

        const { ok, data, error } = await logAndSendAction(payload);

        if (ok) {
            toast({ title: "Action Committed!", description: `Lead stage updated to ${data.new_stage || final_outcome}.` });
            fetchLeads();
        } else {
            toast({ variant: 'destructive', title: "Commit Failed", description: error });
        }
        setIsCommitting(false);
    };

    return (
        <>
            <Helmet><title>Call Console | TVG CRM</title></Helmet>
            <div className="grid grid-cols-12 gap-4 p-4 h-screen bg-gray-100 overflow-hidden">
                <div className="col-span-3 h-full">
                     <LeadList 
                        leads={leads}
                        selectedLead={selectedLead}
                        onSelectLead={handleSelectLead}
                        loading={loading}
                        activeTab={activeTab}
                        setActiveTab={setActiveTab}
                        onFindNewLeads={handleFindNewLeads}
                        isFindingLeads={isFindingLeads}
                        searchCategory={searchCategory}
                        setSearchCategory={setSearchCategory}
                        isTrainingMode={isTrainingMode}
                        onToggleTrainingMode={handleToggleTrainingMode}
                    />
                </div>

                <div className="col-span-5 flex flex-col gap-4 h-full">
                    <div className="flex-[2_2_0%]">
                        {selectedLead ? <PreCallBrief key={selectedLead.id} lead={selectedLead} /> : <div className="h-full bg-white rounded-lg flex items-center justify-center text-gray-500">Select a lead for intel.</div>}
                    </div>
                     <div className="flex-[3_3_0%] min-h-0">
                         <Tabs defaultValue="checklist" className="h-full flex flex-col bg-white rounded-lg">
                            <TabsList className="grid w-full grid-cols-3 rounded-t-lg rounded-b-none">
                                <TabsTrigger value="checklist">Fast Rep Checklist</TabsTrigger>
                                <TabsTrigger value="log">Call Log</TabsTrigger>
                                <TabsTrigger value="new_b2b">New B2B Lead</TabsTrigger>
                            </TabsList>
                            <TabsContent value="checklist" className="flex-1 overflow-hidden">
                                <FastRepChecklist key={selectedLead?.id || 'empty-checklist'} lead={selectedLead} onUpdate={() => fetchLeads()} />
                            </TabsContent>
                             <TabsContent value="log" className="flex-1 overflow-hidden">
                                <CallLog key={selectedLead?.id || 'empty-calllog'} lead={selectedLead} />
                            </TabsContent>
                            <TabsContent value="new_b2b" className="flex-1 overflow-hidden">
                                <B2BLeadCaptureForm onLeadAdded={() => fetchLeads()} />
                            </TabsContent>
                        </Tabs>
                    </div>
                </div>

                <div className="col-span-4 h-full">
                    {selectedLead ? (
                        <AiCopilot
                            key={selectedLead.id}
                            lead={selectedLead}
                            onCompleteAction={handleCommitAction}
                            isCommitting={isCommitting}
                        />
                    ) : (
                        <div className="h-full bg-white rounded-lg flex items-center justify-center text-gray-500 p-4 text-center">
                            Select a lead to activate AI Copilot.
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

export default CallConsole;