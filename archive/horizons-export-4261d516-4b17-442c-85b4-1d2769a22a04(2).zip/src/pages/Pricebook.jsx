import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Pricebook = () => {
    const services = [
        {
            category: "Core Hygiene Services",
            items: [
                { name: "IAQ Audit & System Inspection", price: "$149", description: "Full system inspection with photo documentation. Credited towards any work performed." },
                { name: "Air Handler / Furnace Cleaning", price: "Starts at $399", description: "Blower, coil, and cabinet cleaning to NADCA standards." },
                { name: "Complete Duct System Cleaning", price: "Starts at $599", description: "Supply/return ductwork, registers, and grilles." },
                { name: "Dryer Vent Cleaning", price: "$129 - $249", description: "Improves safety and efficiency. Price varies by length and access." },
            ]
        },
        {
            category: "Add-On & Specialty Services",
            items: [
                { name: "UV-C Light Installation", price: "Call for Quote", description: "Germicidal UV light to inhibit microbial growth on coils." },
                { name:- "Enhanced Filtration Upgrades", price: "Call for Quote", description: "High-MERV filters and media cabinets for superior air quality." },
                { name: "Duct Sealing & Repair", price: "Call for Quote", description: "Seal leaks to improve efficiency and prevent contaminant entry." },
            ]
        }
    ];

    return (
        <>
            <Helmet>
                <title>Pricebook | The Vent Guys</title>
                <meta name="description" content="Transparent pricing for our air duct cleaning, dryer vent cleaning, and IAQ services." />
            </Helmet>

            <section className="relative bg-[#091e39] text-white py-20 md:py-24 overflow-hidden">
                <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(#d1d3d4 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
                <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
                    <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-5xl md:text-6xl font-bold mb-4 leading-tight title-case">
                        Our Pricebook
                    </motion.h1>
                    <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="text-lg text-[#d1d3d4] max-w-3xl mx-auto">
                        Transparent, upfront pricing. No games, no hidden fees.
                    </motion.p>
                </div>
            </section>

            <section className="py-20 bg-gray-50">
                <div className="max-w-screen-lg mx-auto px-4 sm:px-6 lg:px-8">
                    {services.map((serviceCategory, catIndex) => (
                        <div key={catIndex} className="mb-16">
                            <h2 className="text-3xl font-bold text-center text-[#091e39] mb-8 title-case">{serviceCategory.category}</h2>
                            <div className="space-y-8">
                                {serviceCategory.items.map((item, itemIndex) => (
                                    <motion.div 
                                        key={itemIndex}
                                        initial={{ opacity: 0, y: 20 }}
                                        whileInView={{ opacity: 1, y: 0 }}
                                        viewport={{ once: true, amount: 0.5 }}
                                        transition={{ delay: itemIndex * 0.1 }}
                                        className="bg-white p-8 rounded-xl shadow-lg border border-gray-200"
                                    >
                                        <div className="flex flex-col sm:flex-row justify-between items-start">
                                            <div>
                                                <h3 className="text-xl font-bold text-[#173861]">{item.name}</h3>
                                                <p className="text-gray-600 mt-1">{item.description}</p>
                                            </div>
                                            <div className="text-right mt-4 sm:mt-0 sm:ml-8 flex-shrink-0">
                                                <p className="text-2xl font-bold text-[#b52025]">{item.price}</p>
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        </div>
                    ))}

                    <div className="text-center mt-16">
                        <h3 className="text-2xl font-bold text-[#091e39] mb-4">Ready to Breathe Better?</h3>
                        <p className="text-gray-600 max-w-2xl mx-auto mb-6">Every job is custom. The prices above are a guide. For a firm, no-obligation quote, book an IAQ Audit.</p>
                        <Button asChild size="lg" className="bg-[#b52025] hover:bg-[#831618] uppercase tracking-wider">
                            <Link to="/contact">Book Your $149 Audit</Link>
                        </Button>
                    </div>
                </div>
            </section>
        </>
    );
};

export default Pricebook;