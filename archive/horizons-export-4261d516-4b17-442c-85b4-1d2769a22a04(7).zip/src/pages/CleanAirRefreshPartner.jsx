
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle, Send, Loader2, Shield, Award, Building, FileText, AlertCircle, HelpCircle, DollarSign, Users, ClipboardCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { invoke } from '@/lib/api';

const CleanAirRefreshPartner = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const [formData, setFormData] = useState({
    // Agent Info
    agentName: '',
    agencyName: '',
    licenseNumber: '',
    yearsInBusiness: '',
    
    // Contact Info
    email: '',
    phone: '',
    preferredContactMethod: 'email',
    officeAddress: '',
    
    // Service Area
    primaryCounties: '',
    
    // Volume / Use Cases
    monthlyTransactions: '',
    primaryFocus: 'residential', 
    interestedIn: {
      preListing: false,
      closingGift: false,
      inspectionResponse: false,
      rentalTurnover: false
    },
    
    // Terms
    agreeToTerms: false,
    agreeToPrivacy: false,
  });

  const formatPhoneNumber = (value) => {
    if (!value) return value;
    // Strip all non-numeric characters
    const phoneNumber = value.replace(/[^\d]/g, '');
    const phoneNumberLength = phoneNumber.length;
    
    if (phoneNumberLength < 4) return phoneNumber;
    if (phoneNumberLength < 7) {
      return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
    }
    return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'phone') {
      // Allow user to delete freely, but enforce format when typing
      const formattedPhone = formatPhoneNumber(value);
      // Limit to 14 chars: (XXX) XXX-XXXX
      if (formattedPhone.length <= 14) {
         setFormData(prev => ({ ...prev, [name]: formattedPhone }));
      }
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleCheckboxChange = (name, checked) => {
    if (name.startsWith('interest_')) {
      const interestKey = name.replace('interest_', '');
      setFormData(prev => ({
        ...prev,
        interestedIn: {
          ...prev.interestedIn,
          [interestKey]: checked
        }
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: checked }));
    }
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    // Phone Validation
    const phoneDigits = formData.phone.replace(/[^\d]/g, '');
    if (phoneDigits.length !== 10) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid 10-digit phone number formatted as (XXX) XXX-XXXX.",
        variant: "destructive"
      });
      return false;
    }
    
    // Email Validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
        toast({
            title: "Invalid Email Address",
            description: "Please enter a valid email address (e.g., name@company.com).",
            variant: "destructive"
          });
          return false;
    }
    
    if (!formData.agreeToTerms || !formData.agreeToPrivacy) {
      toast({
        title: "Required Fields Missing",
        description: "Please agree to the Program Terms and Privacy Policy to continue.",
        variant: "destructive"
      });
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);

    try {
      const payload = {
        subject: `Partner Registration: ${formData.agentName} - ${formData.agencyName}`,
        data: {
          ...formData,
          formType: 'clean-air-refresh-partner'
        }
      };

      const { ok, error } = await invoke('send-partner-registration', {
        body: JSON.stringify(payload)
      });

      if (!ok) throw new Error(error || 'Failed to submit registration');

      setSubmitted(true);
      toast({
        title: "Registration Successful!",
        description: "Welcome to the Clean Air Refresh Program. We'll be in touch shortly.",
        className: "bg-green-50 border-green-200 text-green-900"
      });
      
      window.scrollTo({ top: 0, behavior: 'smooth' });

    } catch (err) {
      console.error('Submission error:', err);
      toast({
        title: "Submission Failed",
        description: "There was a problem submitting your registration. Please try again or contact info@vent-guys.com.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 py-20 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
        <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8 md:p-12 text-center animate-in fade-in zoom-in duration-300">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-[#1B263B] mb-4">Registration Confirmed!</h1>
          <p className="text-xl text-gray-600 mb-8">
            Thank you for joining the <span className="font-semibold text-[#D7263D]">Clean Air Refresh</span> program.
          </p>
          <div className="bg-gray-50 rounded-lg p-6 text-left mb-8 border border-gray-100">
            <h3 className="font-semibold text-[#1B263B] mb-2">Next Steps:</h3>
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-start gap-2">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-[#1B263B] text-white flex items-center justify-center text-sm font-bold mt-0.5">1</span>
                <span>We've sent a confirmation to <strong>{formData.email}</strong>.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-[#1B263B] text-white flex items-center justify-center text-sm font-bold mt-0.5">2</span>
                <span>Our partner manager will review your service area and activate your account within 24 hours.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-[#1B263B] text-white flex items-center justify-center text-sm font-bold mt-0.5">3</span>
                <span>You'll receive your digital partner kit with logos and marketing materials.</span>
              </li>
            </ul>
          </div>
          <Button onClick={() => window.location.href = '/'} size="lg" className="bg-[#1B263B] text-white hover:bg-[#2a3f5f]">
            Return to Homepage
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Partner Registration | Clean Air Refresh Program</title>
        <meta name="description" content="Join The Vent Guys' Clean Air Refresh program for real estate agents and property managers. Add value to your listings with NADCA-certified air quality assurance." />
      </Helmet>

      {/* Hero Header */}
      <div className="bg-[#1B263B] text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block py-1 px-3 rounded-full bg-[#D7263D] text-white text-xs font-bold tracking-wider uppercase mb-4">
              For Real Estate Professionals
            </span>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 font-oswald uppercase tracking-wide">
              Clean Air <span className="text-[#4DA6FF]">Refresh</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto font-light">
              The strategic partner program that turns indoor air quality into your listing's competitive advantage.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-12 gap-12">
          
          {/* Left Column: Program Details */}
          <div className="lg:col-span-5 space-y-10">
            {/* NEW: Exclusive Access Block */}
            <div className="bg-gradient-to-br from-blue-50 to-white border border-blue-100 p-6 rounded-xl shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-5 group-hover:opacity-10 transition-opacity">
                    <Award className="w-24 h-24 text-[#1B263B]" />
                </div>
                <div className="relative z-10">
                    <h3 className="font-bold text-xl text-[#1B263B] mb-3 flex items-center gap-2">
                        <Award className="text-[#D7263D] w-6 h-6" /> 
                        Exclusive Access & Pricing
                    </h3>
                    <p className="text-gray-600 leading-relaxed text-sm">
                        As a registered partner, you unlock exclusive wholesale pricing not available to the general public. This allows you to offer premium air quality certification at a fraction of the retail cost—giving your listings a distinct competitive edge.
                    </p>
                </div>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-[#1B263B] mb-6 font-oswald">Why Partner With Us?</h2>
              <p className="text-gray-600 text-lg mb-6">
                In Florida's humidity, "move-in ready" means nothing if the air system is compromised. The <span className="font-bold">Clean Air Refresh</span> program gives your clients certified peace of mind.
              </p>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                    <Shield className="w-6 h-6 text-[#1B263B]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#1B263B] text-lg">Liability Protection</h3>
                    <p className="text-gray-600 text-sm">Documented mechanical hygiene reports protect sellers from post-closing disputes regarding mold or air quality.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                    <Award className="w-6 h-6 text-[#D7263D]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#1B263B] text-lg">NADCA Certification</h3>
                    <p className="text-gray-600 text-sm">We don't just clean; we certify. Every job adheres to National Air Duct Cleaners Association standards.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                    <Building className="w-6 h-6 text-[#1B263B]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#1B263B] text-lg">Priority Scheduling</h3>
                    <p className="text-gray-600 text-sm">Partners get 48-hour priority booking windows to ensure closings stay on schedule.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#F8FAFC] p-6 rounded-2xl border border-gray-100">
              <h3 className="font-bold text-[#1B263B] mb-4">Ideal Use Cases:</h3>
              <ul className="space-y-3">
                {[
                  "Pre-Listing Value Add (Certify the air!)",
                  "Inspection Objection Handling",
                  "Premium Closing Gifts",
                  "Luxury Rental Turnovers"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-700 text-sm font-medium">
                    <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="border-t pt-8">
              <div className="flex items-center gap-4 mb-4">
                 <img src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/e72bce9f7a2ca70965b162625bec1491.jpg" alt="NADCA Certified" className="h-12 w-auto" />
                 <img src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/ce0f4417890ef8b3cac12b2bceb2a897.jpg" alt="SDVOSB Certified" className="h-12 w-auto" />
              </div>
              <p className="text-xs text-gray-500">
                The Vent Guys is a Service-Disabled Veteran-Owned Small Business and a certified member of NADCA.
              </p>
            </div>
          </div>

          {/* Right Column: Registration Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
              <div className="bg-gray-50 px-8 py-6 border-b border-gray-100">
                <h3 className="text-xl font-bold text-[#1B263B] flex items-center gap-2">
                  <FileText className="w-5 h-5 text-[#D7263D]" />
                  Partner Registration
                </h3>
                <p className="text-gray-500 text-sm mt-1">Complete the form below to activate your partner status.</p>
              </div>
              
              <form onSubmit={handleSubmit} className="p-8 space-y-8">
                
                {/* Section 1: Agent Info */}
                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wider border-b pb-2">Agent Information</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="agentName">Full Name <span className="text-red-500">*</span></Label>
                      <Input 
                        id="agentName" name="agentName" 
                        value={formData.agentName} onChange={handleInputChange} 
                        required placeholder="Jane Doe" 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="agencyName">Brokerage / Agency <span className="text-red-500">*</span></Label>
                      <Input 
                        id="agencyName" name="agencyName" 
                        value={formData.agencyName} onChange={handleInputChange} 
                        required placeholder="Premier Realty Group" 
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="licenseNumber">License Number (Optional)</Label>
                      <Input 
                        id="licenseNumber" name="licenseNumber" 
                        value={formData.licenseNumber} onChange={handleInputChange} 
                        placeholder="SL3456789" 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="yearsInBusiness">Years in Business</Label>
                      <Select name="yearsInBusiness" onValueChange={(val) => handleSelectChange('yearsInBusiness', val)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0-2">0-2 Years</SelectItem>
                          <SelectItem value="3-5">3-5 Years</SelectItem>
                          <SelectItem value="5-10">5-10 Years</SelectItem>
                          <SelectItem value="10+">10+ Years</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Section 2: Contact Info */}
                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wider border-b pb-2">Contact Details</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address <span className="text-red-500">*</span></Label>
                      <Input 
                        id="email" name="email" type="email"
                        value={formData.email} onChange={handleInputChange} 
                        required placeholder="jane@premier-realty.com" 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number <span className="text-red-500">*</span></Label>
                      <Input 
                        id="phone" name="phone" type="tel"
                        value={formData.phone} onChange={handleInputChange} 
                        required placeholder="(321) 555-0123"
                        maxLength="14"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="officeAddress">Office Address</Label>
                    <Input 
                      id="officeAddress" name="officeAddress" 
                      value={formData.officeAddress} onChange={handleInputChange} 
                      placeholder="123 Ocean Ave, Melbourne Beach, FL 32951" 
                    />
                  </div>
                </div>

                {/* Section 3: Service Area & Volume */}
                <div className="space-y-4">
                  <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wider border-b pb-2">Business Profile</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="primaryCounties">Primary Counties Served</Label>
                      <Input 
                        id="primaryCounties" name="primaryCounties" 
                        value={formData.primaryCounties} onChange={handleInputChange} 
                        placeholder="e.g. Brevard, Volusia" 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="monthlyTransactions">Avg. Monthly Transactions</Label>
                      <Select name="monthlyTransactions" onValueChange={(val) => handleSelectChange('monthlyTransactions', val)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select volume" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1-2">1-2 Deals</SelectItem>
                          <SelectItem value="3-5">3-5 Deals</SelectItem>
                          <SelectItem value="6-10">6-10 Deals</SelectItem>
                          <SelectItem value="10+">10+ Deals</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-3 pt-2">
                    <Label className="text-base font-medium">I'm interested in using this program for (Check all that apply):</Label>
                    <div className="grid sm:grid-cols-2 gap-3 mt-2">
                      <div className="flex items-center space-x-2 p-2 rounded hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-colors">
                        <Checkbox id="interest_preListing" checked={formData.interestedIn.preListing} onCheckedChange={(c) => handleCheckboxChange('interest_preListing', c)} />
                        <Label htmlFor="interest_preListing" className="font-normal cursor-pointer">Pre-Listing Value Add</Label>
                      </div>
                      <div className="flex items-center space-x-2 p-2 rounded hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-colors">
                        <Checkbox id="interest_closingGift" checked={formData.interestedIn.closingGift} onCheckedChange={(c) => handleCheckboxChange('interest_closingGift', c)} />
                        <Label htmlFor="interest_closingGift" className="font-normal cursor-pointer">Closing Gifts</Label>
                      </div>
                      <div className="flex items-center space-x-2 p-2 rounded hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-colors">
                        <Checkbox id="interest_inspectionResponse" checked={formData.interestedIn.inspectionResponse} onCheckedChange={(c) => handleCheckboxChange('interest_inspectionResponse', c)} />
                        <Label htmlFor="interest_inspectionResponse" className="font-normal cursor-pointer">Inspection Responses</Label>
                      </div>
                      <div className="flex items-center space-x-2 p-2 rounded hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-colors">
                        <Checkbox id="interest_rentalTurnover" checked={formData.interestedIn.rentalTurnover} onCheckedChange={(c) => handleCheckboxChange('interest_rentalTurnover', c)} />
                        <Label htmlFor="interest_rentalTurnover" className="font-normal cursor-pointer">Rental / PM Turnovers</Label>
                      </div>
                    </div>
                  </div>
                </div>

                {/* NEW: 3-Step Guide */}
                <div className="pt-4 pb-2">
                    <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                        <HelpCircle className="w-4 h-4 text-gray-400" /> What Happens After I Register?
                    </h4>
                    <div className="grid grid-cols-3 gap-4">
                        <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 text-center">
                            <div className="w-8 h-8 bg-[#1B263B] text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-sm shadow-sm">1</div>
                            <div className="text-sm font-bold text-[#1B263B] mb-1">We Review</div>
                            <p className="text-[11px] text-gray-500 leading-tight">We verify your brokerage details & coverage area.</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 text-center">
                            <div className="w-8 h-8 bg-[#1B263B] text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-sm shadow-sm">2</div>
                            <div className="text-sm font-bold text-[#1B263B] mb-1">You Receive</div>
                            <p className="text-[11px] text-gray-500 leading-tight">Get your unique Partner ID & Welcome Kit.</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 text-center">
                            <div className="w-8 h-8 bg-[#1B263B] text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold text-sm shadow-sm">3</div>
                            <div className="text-sm font-bold text-[#1B263B] mb-1">You Book</div>
                            <p className="text-[11px] text-gray-500 leading-tight">Access priority scheduling for your clients.</p>
                        </div>
                    </div>
                </div>

                {/* Section 4: Terms & Submission */}
                <div className="space-y-4 pt-4 bg-gray-50 p-4 rounded-lg border border-gray-100">
                   {/* NEW: Pricing Note */}
                   <div className="flex gap-2 items-start mb-2 border-b border-gray-200 pb-3">
                      <AlertCircle className="w-4 h-4 text-[#D7263D] flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-gray-600 italic font-medium">
                        Partner pricing is designed to be passed directly to your clients as a value-add on your services.
                      </p>
                   </div>

                   <div className="flex items-start space-x-2">
                      <Checkbox id="agreeToTerms" checked={formData.agreeToTerms} onCheckedChange={(c) => handleCheckboxChange('agreeToTerms', c)} className="mt-1" />
                      <Label htmlFor="agreeToTerms" className="font-normal text-sm leading-snug cursor-pointer">
                        I agree to the Clean Air Refresh Program Terms. I understand that this program is designed to provide certified services to my clients and that scheduling priority is subject to availability.
                      </Label>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Checkbox id="agreeToPrivacy" checked={formData.agreeToPrivacy} onCheckedChange={(c) => handleCheckboxChange('agreeToPrivacy', c)} className="mt-1" />
                      <Label htmlFor="agreeToPrivacy" className="font-normal text-sm leading-snug cursor-pointer">
                        I consent to The Vent Guys storing my information and contacting me about partnership opportunities.
                      </Label>
                    </div>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-gray-500 bg-blue-50 p-3 rounded text-center justify-center">
                   <Shield className="w-4 h-4 text-blue-600" />
                   Form will be securely submitted to info@vent-guys.com
                </div>

                <Button type="submit" size="lg" className="w-full bg-[#D7263D] hover:bg-[#b51f31] text-white h-14 text-lg font-bold shadow-lg transition-all hover:translate-y-[-1px]" disabled={loading}>
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Processing Registration...
                    </>
                  ) : (
                    <>
                      Complete Partner Registration <Send className="ml-2 h-5 w-5" />
                    </>
                  )}
                </Button>

              </form>
            </div>
          </div>
        </div>

        {/* NEW: Quick Partner FAQ Section */}
        <div className="mt-24 border-t border-gray-200 pt-16">
            <div className="text-center mb-12">
                <span className="inline-block py-1 px-3 rounded-full bg-blue-50 text-[#1B263B] text-xs font-bold tracking-wider uppercase mb-3">
                  Common Questions
                </span>
                <h2 className="text-3xl font-bold text-[#1B263B] font-oswald">Quick Partner FAQ</h2>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
                {/* FAQ 1: Cost */}
                <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                    <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center mb-4">
                        <DollarSign className="w-5 h-5 text-green-600" />
                    </div>
                    <h3 className="font-bold text-[#1B263B] mb-3 text-lg">Is there a cost to join?</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">
                        No. The Partner Program is completely free for licensed real estate professionals. There are no monthly fees or minimums. You only pay for the services booked, or your clients pay directly.
                    </p>
                </div>

                {/* FAQ 2: How Clients Get Rate */}
                <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                    <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center mb-4">
                        <Users className="w-5 h-5 text-blue-600" />
                    </div>
                    <h3 className="font-bold text-[#1B263B] mb-3 text-lg">How do clients get the rate?</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">
                        Once registered, you'll receive a Partner ID. You can book directly on their behalf via your portal, or they can simply mention your Partner ID when calling us to receive the preferred pricing and priority scheduling.
                    </p>
                </div>

                {/* FAQ 3: Service Scope */}
                <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                    <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center mb-4">
                        <ClipboardCheck className="w-5 h-5 text-orange-600" />
                    </div>
                    <h3 className="font-bold text-[#1B263B] mb-3 text-lg">What is the service scope?</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">
                        The program covers comprehensive air system cleaning and NADCA-certified hygiene inspection. It is not a mold remediation service. If we discover mold issues during inspection, we will refer you to a licensed remediation specialist.
                    </p>
                </div>
            </div>
        </div>

      </div>
    </>
  );
};

export default CleanAirRefreshPartner;
