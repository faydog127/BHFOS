
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Home, Send, Loader2, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { formatPhoneNumber, validateEmail, validatePhone } from '@/lib/formUtils';

const RealtorPartner = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    // Core
    contact_name: '',
    title: '',
    email: '',
    mobile_phone: '',
    sms_consent: false,
    office_phone: '',
    address: '',
    counties_served: '',
    preferred_contact: 'email',
    referral_source: '',
    
    // Realtor Specific
    brokerage_name: '',
    license_number: '',
    years_in_business: '',
    transactions_per_year: '',
    primary_focus: 'Residential',
    price_range: '',
    program_use: {
        preListing: false,
        closingGift: false,
        inspectionResponse: false
    },
    lead_gen_preference: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'mobile_phone' || name === 'office_phone') {
      const formatted = formatPhoneNumber(value);
      if (formatted.length <= 14) setFormData(prev => ({ ...prev, [name]: formatted }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSelect = (name, value) => setFormData(prev => ({ ...prev, [name]: value }));
  
  const handleCheckbox = (name, checked) => {
      if (name.startsWith('use_')) {
          const key = name.replace('use_', '');
          setFormData(prev => ({
              ...prev,
              program_use: { ...prev.program_use, [key]: checked }
          }));
      } else {
          setFormData(prev => ({ ...prev, [name]: checked }));
      }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateEmail(formData.email)) {
      toast({ title: "Invalid Email", description: "Please check your email address.", variant: "destructive" });
      return;
    }
    if (!validatePhone(formData.mobile_phone)) {
      toast({ title: "Invalid Phone", description: "Please enter a valid mobile number.", variant: "destructive" });
      return;
    }

    setLoading(true);

    // Prepare data for DB
    const dbData = {
        partner_type: 'realtor',
        organization_name: formData.brokerage_name,
        contact_name: formData.contact_name,
        title: formData.title,
        email: formData.email,
        mobile_phone: formData.mobile_phone,
        sms_consent: formData.sms_consent,
        office_phone: formData.office_phone,
        address: formData.address,
        counties_served: formData.counties_served,
        preferred_contact: formData.preferred_contact,
        referral_source: formData.referral_source,
        
        brokerage_name: formData.brokerage_name,
        license_number: formData.license_number,
        years_in_business: formData.years_in_business,
        transactions_per_year: formData.transactions_per_year,
        primary_focus: formData.primary_focus,
        price_range: formData.price_range,
        program_use: formData.program_use,
        lead_gen_preference: formData.lead_gen_preference
    };

    const { error } = await supabase.from('partner_registrations').insert([dbData]);

    if (error) {
      console.error(error);
      toast({ title: "Error", description: "Submission failed. Please try again.", variant: "destructive" });
    } else {
      setSubmitted(true);
      window.scrollTo(0, 0);
    }
    setLoading(false);
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="bg-white p-8 rounded-xl shadow-lg max-w-lg w-full text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Registration Complete!</h2>
            <p className="text-gray-600 mb-6">Thank you for joining our Realtor Partner Program. We will be in touch shortly with your partner kit.</p>
            <Button onClick={() => window.location.href='/'}>Return Home</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <Helmet>
        <title>Realtor Partner Registration | The Vent Guys</title>
      </Helmet>
      
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-[#1B263B] py-8 px-8">
            <div className="flex items-center gap-4 mb-2">
                <div className="bg-white/10 p-2 rounded-lg">
                    <Home className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-white font-oswald tracking-wide">Realtor Partner Registration</h1>
            </div>
            <p className="text-blue-100 ml-14">Exclusive pricing and priority scheduling for real estate professionals.</p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-8">
            
            {/* Contact Section */}
            <section className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Contact Information</h3>
                <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label>Full Name *</Label>
                        <Input name="contact_name" value={formData.contact_name} onChange={handleChange} required />
                    </div>
                    <div className="space-y-2">
                        <Label>Title</Label>
                        <Input name="title" value={formData.title} onChange={handleChange} placeholder="e.g. Associate Broker" />
                    </div>
                    <div className="space-y-2">
                        <Label>Email *</Label>
                        <Input name="email" type="email" value={formData.email} onChange={handleChange} required />
                    </div>
                    <div className="space-y-2">
                        <Label>Mobile Phone *</Label>
                        <Input name="mobile_phone" value={formData.mobile_phone} onChange={handleChange} placeholder="(555) 123-4567" required maxLength={14} />
                    </div>
                </div>
                <div className="flex items-center space-x-2">
                    <Checkbox id="sms" checked={formData.sms_consent} onCheckedChange={(c) => handleCheckbox('sms_consent', c)} />
                    <Label htmlFor="sms" className="text-sm text-gray-500 font-normal">I agree to receive text messages regarding my partner account.</Label>
                </div>
            </section>

            {/* Agency Section */}
            <section className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Brokerage Details</h3>
                <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label>Brokerage Name *</Label>
                        <Input name="brokerage_name" value={formData.brokerage_name} onChange={handleChange} required />
                    </div>
                    <div className="space-y-2">
                        <Label>License Number</Label>
                        <Input name="license_number" value={formData.license_number} onChange={handleChange} />
                    </div>
                    <div className="space-y-2">
                        <Label>Office Phone</Label>
                        <Input name="office_phone" value={formData.office_phone} onChange={handleChange} maxLength={14} />
                    </div>
                    <div className="space-y-2">
                        <Label>Years in Business</Label>
                        <Select onValueChange={(v) => handleSelect('years_in_business', v)}>
                            <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="0-2">0-2 Years</SelectItem>
                                <SelectItem value="3-5">3-5 Years</SelectItem>
                                <SelectItem value="5-10">5-10 Years</SelectItem>
                                <SelectItem value="10+">10+ Years</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>
                <div className="space-y-2">
                    <Label>Office Address</Label>
                    <Input name="address" value={formData.address} onChange={handleChange} placeholder="Street, City, Zip" />
                </div>
            </section>

            {/* Business Profile */}
            <section className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Business Profile</h3>
                <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label>Transactions Per Year</Label>
                        <Select onValueChange={(v) => handleSelect('transactions_per_year', v)}>
                            <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="0-5">0-5 Deals</SelectItem>
                                <SelectItem value="6-12">6-12 Deals</SelectItem>
                                <SelectItem value="13-24">13-24 Deals</SelectItem>
                                <SelectItem value="25+">25+ Deals</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>Primary Focus</Label>
                        <Select onValueChange={(v) => handleSelect('primary_focus', v)}>
                            <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Residential">Residential</SelectItem>
                                <SelectItem value="Commercial">Commercial</SelectItem>
                                <SelectItem value="Luxury">Luxury</SelectItem>
                                <SelectItem value="Investment">Investment</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>Avg. Price Range</Label>
                        <Input name="price_range" value={formData.price_range} onChange={handleChange} placeholder="e.g. $400k - $600k" />
                    </div>
                    <div className="space-y-2">
                        <Label>Counties Served</Label>
                        <Input name="counties_served" value={formData.counties_served} onChange={handleChange} placeholder="e.g. Brevard, Orange" />
                    </div>
                </div>
                
                <div className="space-y-3">
                    <Label>I plan to use this program for:</Label>
                    <div className="flex gap-4 flex-wrap">
                        <div className="flex items-center gap-2">
                            <Checkbox id="use_preListing" onCheckedChange={(c) => handleCheckbox('use_preListing', c)} />
                            <Label htmlFor="use_preListing" className="font-normal">Pre-Listing</Label>
                        </div>
                        <div className="flex items-center gap-2">
                            <Checkbox id="use_closingGift" onCheckedChange={(c) => handleCheckbox('use_closingGift', c)} />
                            <Label htmlFor="use_closingGift" className="font-normal">Closing Gift</Label>
                        </div>
                        <div className="flex items-center gap-2">
                            <Checkbox id="use_inspectionResponse" onCheckedChange={(c) => handleCheckbox('use_inspectionResponse', c)} />
                            <Label htmlFor="use_inspectionResponse" className="font-normal">Inspection Responses</Label>
                        </div>
                    </div>
                </div>
            </section>

            <Button type="submit" className="w-full h-12 text-lg bg-[#D7263D] hover:bg-[#b01c2e]" disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : "Submit Registration"}
            </Button>

          </form>
        </div>
      </div>
    </div>
  );
};

export default RealtorPartner;
