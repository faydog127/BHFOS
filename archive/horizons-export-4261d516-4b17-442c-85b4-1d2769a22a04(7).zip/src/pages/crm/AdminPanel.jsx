import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { UserPlus, Trash2, ShieldCheck, Shield, User } from 'lucide-react';
import { useToast as useCustomToast } from '@/components/ui/use-toast';

const AdminPanel = () => {
    const { toast } = useCustomToast();
    
    useEffect(() => {
        toast({
            variant: 'destructive',
            title: 'Admin Panel Disabled',
            description: 'User management is not available in public mode. This is now a read-only view.',
        });
    }, [toast]);

    const users = [
        { id: '1', email: 'demo-admin@example.com', role: 'owner', created_at: new Date().toISOString(), last_sign_in_at: new Date().toISOString() },
        { id: '2', email: 'demo-rep@example.com', role: 'rep', created_at: new Date().toISOString(), last_sign_in_at: new Date().toISOString() },
    ];

    const RoleIcon = ({ role }) => {
        if (role === 'owner') return <ShieldCheck className="h-5 w-5 text-green-600" />;
        if (role === 'rep') return <Shield className="h-5 w-5 text-blue-600" />;
        return <User className="h-5 w-5 text-gray-500" />;
    };

    return (
        <div className="p-4 md:p-6 space-y-8">
            <h1 className="text-3xl font-bold text-gray-800">Admin Panel</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Invite New User</CardTitle>
                    <CardDescription>User invitations are disabled in public access mode.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="flex flex-col sm:flex-row gap-4">
                        <Input type="email" placeholder="new.user@example.com" disabled />
                        <Select disabled>
                            <SelectTrigger className="w-full sm:w-[180px]">
                                <SelectValue placeholder="Select a role" />
                            </SelectTrigger>
                        </Select>
                        <Button type="submit" disabled className="w-full sm:w-auto">
                            <UserPlus className="mr-2 h-4 w-4" />
                            Send Invite
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>This is a read-only demonstration. Role changes are disabled.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>User</TableHead>
                                <TableHead>Role</TableHead>
                                <TableHead>Last Seen</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {users.map((user) => (
                                <TableRow key={user.id}>
                                    <TableCell>
                                        <div className="font-medium">{user.email}</div>
                                        <div className="text-xs text-gray-500">Joined: {new Date(user.created_at).toLocaleDateString()}</div>
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex items-center gap-2">
                                            <RoleIcon role={user.role} />
                                            <span className="capitalize font-medium">{user.role}</span>
                                        </div>
                                    </TableCell>
                                    <TableCell>{user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleString() : 'Never'}</TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="destructive" size="sm" disabled>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
};

export default AdminPanel;