
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { 
  Phone, Mic, MicOff, User, 
  MessageSquare, ShieldCheck, Sparkles, Loader2, Save, AlertCircle,
  ClipboardCheck, Check, GripVertical, Forward
} from 'lucide-react';

// UI Components
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

// Stores & Data
import useCallStore from '@/store/useCallStore';
import useHistoryStore from '@/store/useHistoryStore';
import { mockLeads, mockCompanyIntel, mockAnticipatoryReplies, mockNextBestReply } from '@/data/mockData';
import { WRAP_UP_FORM_OPTIONS } from '@/data/callFormOptions';

// Services
import { logAndOutreach } from '@/services/callService';

// --- Constants ---
const TRANSFER_REPS = ['Erron', 'Kai', 'Dispatcher A', 'CSR B'];
const VARIANT_OPTIONS = ['HIRING', 'PERMITS', 'IAQ'];
const AGENT_NAME = 'Alex';

// --- Helpers ---

const formatTimer = (seconds) => {
    const safeSeconds = typeof seconds === 'number' ? seconds : 0;
    const m = Math.floor(safeSeconds / 60);
    const s = safeSeconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
};

const StatusBadge = ({ status }) => {
    const safeStatus = (typeof status === 'string' ? status : 'idle').toLowerCase();
    
    const styles = {
        idle: 'bg-slate-100 text-slate-600 border-slate-200',
        connecting: 'bg-yellow-50 text-yellow-700 border-yellow-200 animate-pulse',
        ringing: 'bg-blue-50 text-blue-700 border-blue-200 animate-pulse',
        connected: 'bg-green-50 text-green-700 border-green-200',
        wrap_up: 'bg-purple-50 text-purple-700 border-purple-200',
        ended: 'bg-red-50 text-red-700 border-red-200',
    };
    
    return (
        <Badge variant="outline" className={cn("capitalize shadow-sm h-6", styles[safeStatus] || styles.idle)}>
            {safeStatus.replace('_', ' ')}
        </Badge>
    );
};

// --- Main Component ---

const CallConsole = () => {
    const { toast } = useToast();

    // --- Global State (Stores) ---
    const { 
        callState, 
        duration: timer, 
        lead: activeStoreLead, 
        startCall, 
        setCallState, 
        endCall,
        incrementDuration,
        setTimerInterval,
        clearCall
    } = useCallStore();
    
    const history = useHistoryStore((state) => state.history);
    const addEntry = useHistoryStore((state) => state.addEntry);

    // --- Local State (UI & Forms) ---
    // Selection State
    const [previewLead, setPreviewLead] = useState(null);
    
    // Call Control State
    const [callId, setCallId] = useState(null);
    const [callStartTime, setCallStartTime] = useState(null);
    const [isMuted, setIsMuted] = useState(false);

    // AI Copilot
    const [selectedPersona, setSelectedPersona] = useState('DM'); // DM | GATEKEEPER
    const [selectedVariant, setSelectedVariant] = useState('HIRING'); // HIRING | PERMITS | IAQ | REVIEWS
    
    // Wrap-up Form
    const [scriptType, setScriptType] = useState('');
    const [result, setResult] = useState('');
    const [nextStep, setNextStep] = useState('');
    const [notes, setNotes] = useState('');
    
    // Form Status
    const [isSaving, setIsSaving] = useState(false);
    const [errorMsg, setErrorMsg] = useState(null);
    const [successMsg, setSuccessMsg] = useState(null);
    
    // Checklist (Local)
    const [checklist, setChecklist] = useState({
        verify: false,
        purpose: false,
        discovery: false,
        objection: false
    });

    // Derived State
    // Prioritize store lead during active call, otherwise use local preview
    const activeLead = (callState === 'idle') ? previewLead : (activeStoreLead || previewLead);
    
    const isReady = callState === 'idle' && !!activeLead;
    const isInCall = ['connecting', 'ringing', 'connected'].includes(callState);
    const isWrapUp = callState === 'wrap_up';

    // --- Effects ---

    // Timer Tick
    useEffect(() => {
        let interval;
        if (callState === 'connected') {
            interval = setInterval(() => {
                if (incrementDuration) incrementDuration();
            }, 1000);
            setTimerInterval(interval); 
        } else {
            setTimerInterval(null); 
        }
        return () => {
          if (interval) {
            clearInterval(interval);
          }
        };
    }, [callState, incrementDuration, setTimerInterval]);

    // Mock Connection Sequence
    useEffect(() => {
        if (callState === 'connecting') {
            const t = setTimeout(() => setCallState('ringing'), 1500);
            return () => clearTimeout(t);
        }
        if (callState === 'ringing') {
            const t = setTimeout(() => setCallState('connected'), 2000);
            return () => clearTimeout(t);
        }
    }, [callState, setCallState]);

    // Reset Local State on Lead Change
    useEffect(() => {
        if (activeLead) {
            // Reset AI Copilot defaults based on simple logic
            const role = (activeLead.roleTag || '').toLowerCase();
            setSelectedPersona(role.includes('gate') || role.includes('reception') ? 'GATEKEEPER' : 'DM');
            
            const variant = (activeLead.personaVariant || '').toUpperCase();
            if (variant.includes('PERMITS')) setSelectedVariant('PERMITS');
            else if (variant.includes('IAQ')) setSelectedVariant('IAQ');
            else if (variant.includes('REVIEWS')) setSelectedVariant('REVIEWS');
            else setSelectedVariant('HIRING');
            
            // Reset Checklist
            setChecklist({ verify: false, purpose: false, discovery: false, objection: false });
        }
    }, [activeLead]);


    // --- Handlers ---

    const handleLeadClick = (lead) => {
        if (callState !== 'idle') {
            toast({ 
                title: "Call in Progress", 
                description: "Please wrap up the current call before starting a new one.",
                variant: "destructive"
            });
            return;
        }
        // Set preview lead to enable "Ready" state
        setPreviewLead(lead);
        
        // Reset call-specific local state
        setCallId(null);
        setCallStartTime(null);
        setIsMuted(false);
        
        // Reset form fields
        setScriptType('');
        setResult('');
        setNextStep('');
        setNotes('');
        setErrorMsg(null);
        setSuccessMsg(null);
    };

    const handlePlaceCall = () => {
        if (!activeLead) return;

        // Generate ID and Timestamp
        const newCallId = `Call-${Date.now().toString().slice(-6)}`;
        setCallId(newCallId);
        setCallStartTime(Date.now());
        
        // Trigger store action (transitions to 'connecting')
        startCall(activeLead);
    };

    const handleMuteToggle = () => {
        const newState = !isMuted;
        setIsMuted(newState);
        toast({ description: newState ? "🔇 Call muted" : "🔊 Call unmuted" });
    };

    const handleTransfer = (repName) => {
        toast({ 
            title: "Transfer Initiated",
            description: `Call is being transferred to ${repName}.`,
            className: "bg-green-50 border-green-200"
        });
    };

    const handleEndCall = () => {
        endCall(); // Sets state to 'wrap_up'
    };

    const handleLogAndOutreach = async () => {
        // 1. Basic Validation
        if (!activeLead) {
            setErrorMsg('No active lead selected.');
            return;
        }
        if (!scriptType || !result || !nextStep) {
            setErrorMsg('Script Used, Result, and Next Step are required.');
            return;
        }

        setIsSaving(true);
        setErrorMsg(null);
        setSuccessMsg(null);

        try {
            // 2. Build Payload
            const payload = {
                lead_id: activeLead.id,
                script_type: scriptType,
                result: result,
                next_step: nextStep,
                notes: notes,
                call_state: callState,
                duration_seconds: timer
            };

            // 3. Call Service
            const response = await logAndOutreach(payload);

            if (!response.success) {
                setErrorMsg(response.error || 'Failed to log call.');
                setIsSaving(false);
                return;
            }

            // 4. Success Handling
            // Add to local history
            addEntry({
                timestamp: new Date().toISOString(),
                leadId: activeLead.id,
                leadName: activeLead.name,
                result: WRAP_UP_FORM_OPTIONS.results.find(r => r.value === result)?.label || result,
                nextStep: WRAP_UP_FORM_OPTIONS.nextSteps.find(n => n.value === nextStep)?.label || nextStep,
                durationSeconds: timer,
                pipelineStage: response.pipeline_stage
            });

            setSuccessMsg('✅ Call logged and pipeline updated.');

            // Clear form fields
            setScriptType('');
            setResult('');
            setNextStep('');
            setNotes('');
            
            // 5. Delay & Idle
            setTimeout(() => {
                clearCall(); // Use the new clearCall action to reset all state
                setIsSaving(false);
                setSuccessMsg(null);
            }, 1500);

        } catch (error) {
            console.error("Logging error:", error);
            setErrorMsg('Unexpected error logging call.');
            setIsSaving(false);
        }
    };

    // --- Data Prep ---

    // Script Lookup
    const replyKey = `${selectedPersona}_${selectedVariant}`;
    const rawScript = (mockNextBestReply && mockNextBestReply[replyKey]) 
        ? mockNextBestReply[replyKey] 
        : (mockNextBestReply?.['DEFAULT'] || "No script available.");
    
    // Safe Interpolation
    const formattedScript = String(rawScript)
        .replace(/\[Lead Name\]/g, activeLead?.name || 'Lead')
        .replace(/\[Your Name\]/g, AGENT_NAME)
        .replace(/\[Company Name\]/g, activeLead?.company || 'their company');

    // Intel Lookup
    const activeIntel = (activeLead && mockCompanyIntel) ? mockCompanyIntel[activeLead.id] : null;


    // --- Render ---

    return (
        <div className="h-[calc(100vh-4rem)] p-4 bg-slate-50 overflow-hidden grid grid-cols-12 gap-4 font-sans">
            <Helmet><title>Call Console | CRM</title></Helmet>

            {/* LEFT COLUMN: LEAD QUEUE */}
            <Card className="col-span-3 h-full flex flex-col border-none shadow-md bg-white">
                <CardHeader className="pb-3 border-b">
                    <CardTitle className="text-lg flex items-center gap-2">
                        <GripVertical className="h-4 w-4 text-slate-400" />
                        Lead Queue
                    </CardTitle>
                    <CardDescription>Priority outreach list</CardDescription>
                </CardHeader>
                <ScrollArea className="flex-1 bg-slate-50/30 p-3">
                    <div className="space-y-3">
                        {mockLeads && mockLeads.length > 0 ? mockLeads.map(lead => (
                            <Card 
                                key={lead.id} 
                                onClick={() => handleLeadClick(lead)}
                                className={cn(
                                    "cursor-pointer hover:shadow-md transition-all group border-l-4",
                                    activeLead?.id === lead.id 
                                        ? "border-l-primary ring-1 ring-primary/20 bg-indigo-50/40" 
                                        : "border-l-transparent hover:border-l-indigo-300 bg-white"
                                )}
                            >
                                <CardContent className="p-3">
                                    <div className="flex justify-between items-start mb-1">
                                        <Badge variant={lead.heat === 'HOT' ? 'destructive' : 'secondary'} className="text-[10px] h-5 px-1.5">
                                            {lead.heat}
                                        </Badge>
                                        <span className="text-xs text-slate-400 font-mono">PQI: {lead.score}</span>
                                    </div>
                                    <h4 className="font-bold text-slate-800 group-hover:text-primary transition-colors text-sm">{lead.name}</h4>
                                    <p className="text-xs text-slate-500 truncate mb-2">{lead.company}</p>
                                    <div className="flex items-center gap-2 text-[10px] text-slate-400">
                                        <Phone className="h-3 w-3" /> {lead.phone}
                                    </div>
                                </CardContent>
                            </Card>
                        )) : (
                            <div className="text-center text-slate-400 py-8 text-sm">No leads available.</div>
                        )}
                    </div>
                </ScrollArea>
            </Card>

            {/* CENTER COLUMN: WORKSPACE */}
            <div className="col-span-6 flex flex-col gap-4 h-full overflow-hidden relative">
                
                {/* Idle State Placeholder */}
                {!activeLead && (
                    <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/80 backdrop-blur-[2px] rounded-lg border-2 border-dashed border-slate-200">
                        <div className="text-center max-w-sm p-6">
                            <div className="bg-indigo-50 h-20 w-20 rounded-full flex items-center justify-center mx-auto mb-5 shadow-inner">
                                <Phone className="h-8 w-8 text-indigo-400" />
                            </div>
                            <h2 className="text-xl font-bold text-slate-800 mb-2">Ready to Call</h2>
                            <p className="text-sm text-slate-500 mb-6">Select a lead from the queue to initialize the AI Copilot and begin your outreach session.</p>
                            <Button variant="outline" disabled className="bg-slate-50">Waiting for selection...</Button>
                        </div>
                    </div>
                )}

                {/* Active Lead / Call Control Panel */}
                {activeLead && (
                    <Card className="shrink-0 border-none shadow-sm bg-white z-0 transition-all duration-300">
                        <CardContent className="p-4">
                            <div className="flex justify-between items-start gap-4">
                                {/* Left: Lead Info */}
                                <div className="flex gap-3 shrink-0">
                                    <Avatar className="h-12 w-12 border-2 border-white shadow-sm">
                                        <AvatarFallback className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white font-bold text-lg">
                                            {activeLead?.name?.charAt?.(0) || '?'}
                                        </AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <h2 className="text-lg font-bold text-slate-900">{activeLead.name}</h2>
                                            <Badge variant="outline" className="text-[10px] h-5">PQI {activeLead.score}</Badge>
                                        </div>
                                        <div className="text-sm text-slate-500 flex items-center gap-3 mt-1">
                                            <span className="flex items-center gap-1"><User className="h-3 w-3" /> {activeLead.roleTag}</span>
                                            <Separator orientation="vertical" className="h-3" />
                                            <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {activeLead.phone}</span>
                                        </div>
                                    </div>
                                </div>

                                {/* Right: Call Control Panel */}
                                <div className="flex-1 flex flex-col items-end gap-2">
                                    
                                    {/* READY STATE */}
                                    {isReady && (
                                        <div className="flex flex-col items-end gap-2 w-full max-w-[240px]">
                                            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                                                <StatusBadge status="ready" />
                                                <span>Ready to connect</span>
                                            </div>
                                            <Button 
                                                className="w-full bg-indigo-600 hover:bg-indigo-700 shadow-sm" 
                                                onClick={handlePlaceCall}
                                            >
                                                <Phone className="mr-2 h-4 w-4" /> Place Call
                                            </Button>
                                        </div>
                                    )}

                                    {/* IN CALL STATE */}
                                    {isInCall && (
                                        <div className="flex flex-col items-end w-full animate-in fade-in slide-in-from-right-2">
                                            <div className="flex items-center justify-end gap-4 w-full mb-2">
                                                {/* Active Call Info */}
                                                <div className="flex flex-col items-end text-xs text-slate-400 mr-auto pl-4">
                                                    <span className="font-mono">Call ID: {callId}</span>
                                                    <span>Lead: {activeLead.name}</span>
                                                </div>

                                                {/* Timer */}
                                                <div className={cn(
                                                    "text-2xl font-mono font-bold tabular-nums transition-colors",
                                                    callState === 'connected' ? "text-green-600" : "text-slate-400 animate-pulse"
                                                )}>
                                                    {formatTimer(timer)}
                                                </div>
                                            </div>
                                            
                                            {/* Controls */}
                                            <div className="flex items-center gap-2">
                                                <Button 
                                                    variant={isMuted ? "destructive" : "outline"} 
                                                    size="sm" 
                                                    onClick={handleMuteToggle}
                                                    className={cn("w-24", isMuted && "bg-red-100 text-red-700 border-red-200 hover:bg-red-200")}
                                                >
                                                    {isMuted ? <MicOff className="h-4 w-4 mr-1" /> : <Mic className="h-4 w-4 mr-1" />}
                                                    {isMuted ? "Unmute" : "Mute"}
                                                </Button>
                                                
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="outline" size="sm" className="w-28">
                                                            <Forward className="h-4 w-4 mr-1" /> Transfer
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end" className="w-48">
                                                       <DropdownMenuLabel>Transfer to Agent</DropdownMenuLabel>
                                                       <DropdownMenuSeparator />
                                                       {TRANSFER_REPS.map(rep => (
                                                           <DropdownMenuItem key={rep} onClick={() => handleTransfer(rep)} className="cursor-pointer">
                                                               <User className="mr-2 h-3 w-3 opacity-50" /> {rep}
                                                           </DropdownMenuItem>
                                                       ))}
                                                    </DropdownMenuContent>
                                                </DropdownMenu>

                                                <Button 
                                                    variant="secondary" 
                                                    size="sm" 
                                                    onClick={handleEndCall}
                                                    className="text-red-600 hover:bg-red-50 border border-transparent hover:border-red-100"
                                                >
                                                     <span className="mr-2 text-lg leading-none">⏹️</span> End Call
                                                </Button>
                                            </div>
                                        </div>
                                    )}

                                    {/* WRAP UP STATE */}
                                    {isWrapUp && (
                                        <div className="flex items-center gap-2 bg-purple-50 px-3 py-1.5 rounded border border-purple-100">
                                            <div className="h-2 w-2 rounded-full bg-purple-500 animate-pulse" />
                                            <span className="text-sm font-medium text-purple-700">Wrapping Up...</span>
                                        </div>
                                    )}

                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {/* Pre-Call Brief */}
                {activeLead && (
                    <Card className="shrink-0 bg-gradient-to-r from-indigo-50 via-white to-white border-indigo-100 shadow-sm z-0">
                        <CardHeader className="pb-2 pt-3 px-4">
                            <CardTitle className="text-xs uppercase tracking-wider text-indigo-600 flex items-center gap-2 font-bold">
                                <Sparkles className="h-3 w-3" /> Pre-Call Intelligence
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="px-4 pb-3 text-sm grid grid-cols-1 gap-2">
                            <div className="grid grid-cols-[80px_1fr] gap-2">
                                <span className="font-semibold text-slate-700 text-xs mt-0.5">Pain Signals:</span>
                                <div className="flex flex-wrap gap-1">
                                    {activeIntel?.painSignals?.map((s) => (
                                        <Badge key={s} variant="secondary" className="text-[10px] h-5 bg-white border-indigo-100 text-slate-600 font-normal px-1.5">
                                            {s}
                                        </Badge>
                                    )) || <span className="text-slate-400 text-xs italic">None detected</span>}
                                </div>
                            </div>
                            <div className="grid grid-cols-[80px_1fr] gap-2">
                                <span className="font-semibold text-slate-700 text-xs mt-0.5">AI Insight:</span>
                                <p className="text-slate-600 text-xs leading-snug">"{activeIntel?.aiInsight || 'No insight available'}"</p>
                            </div>
                        </CardContent>
                    </Card>
                )}

                {/* Tabs & Wrap-up */}
                {activeLead && (
                    <Card className="flex-1 border-none shadow-md flex flex-col overflow-hidden bg-white z-0 relative">
                        
                        {/* Wrap-Up Modal Overlay */}
                        {isWrapUp && (
                            <div className="absolute inset-0 z-20 bg-white/95 backdrop-blur-sm p-6 flex flex-col animate-in fade-in duration-200">
                                <div className="max-w-md mx-auto w-full space-y-4 bg-white p-6 rounded-xl shadow-xl border border-indigo-100 ring-1 ring-indigo-50">
                                    <div className="flex items-center justify-between mb-2 border-b pb-2">
                                        <h3 className="text-md font-bold text-slate-900 flex items-center gap-2">
                                            <Check className="h-4 w-4 text-white bg-green-500 rounded-full p-0.5" /> 
                                            Call Wrap-Up
                                        </h3>
                                        <Badge variant="secondary" className="bg-purple-50 text-purple-700 border-purple-100">Post-Call Work</Badge>
                                    </div>
                                    
                                    {/* Error Message */}
                                    {errorMsg && (
                                        <div className="bg-red-50 text-red-600 text-xs p-2 rounded border border-red-100 flex items-center gap-2">
                                            <AlertCircle className="h-3 w-3" /> {errorMsg}
                                        </div>
                                    )}
                                    
                                    {/* Success Message */}
                                    {successMsg && (
                                        <div className="bg-green-50 text-green-600 text-xs p-2 rounded border border-green-100 flex items-center gap-2">
                                            <Check className="h-3 w-3" /> {successMsg}
                                        </div>
                                    )}

                                    <div className="grid grid-cols-2 gap-3">
                                        <div className="space-y-1.5">
                                            <Label className="text-xs">Script Used <span className="text-red-500">*</span></Label>
                                            <Select value={scriptType} onValueChange={setScriptType}>
                                                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select..." /></SelectTrigger>
                                                <SelectContent>
                                                    {WRAP_UP_FORM_OPTIONS.scripts.map(o => <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>)}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                        <div className="space-y-1.5">
                                            <Label className="text-xs">Result <span className="text-red-500">*</span></Label>
                                            <Select value={result} onValueChange={setResult}>
                                                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select..." /></SelectTrigger>
                                                <SelectContent>
                                                    {WRAP_UP_FORM_OPTIONS.results.map(o => <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>)}
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>
                                    
                                    <div className="space-y-1.5">
                                        <Label className="text-xs">Next Step <span className="text-red-500">*</span></Label>
                                        <Select value={nextStep} onValueChange={setNextStep}>
                                            <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Choose action..." /></SelectTrigger>
                                            <SelectContent>
                                                {WRAP_UP_FORM_OPTIONS.nextSteps.map(o => <SelectItem key={o.value} value={o.value} className="text-xs">{o.label}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="space-y-1.5">
                                        <Label className="text-xs">Call Notes</Label>
                                        <Textarea 
                                            placeholder="Summarize key points..." 
                                            className="resize-none h-20 text-xs"
                                            value={notes}
                                            onChange={(e) => setNotes(e.target.value)}
                                        />
                                    </div>

                                    <Button 
                                        className="w-full bg-indigo-600 hover:bg-indigo-700 mt-2" 
                                        size="sm"
                                        onClick={handleLogAndOutreach}
                                        disabled={isSaving}
                                    >
                                        {isSaving ? <><Loader2 className="mr-2 h-3 w-3 animate-spin" /> Saving...</> : <><Save className="mr-2 h-3 w-3" /> Log & Action</>}
                                    </Button>
                                </div>
                            </div>
                        )}

                        <Tabs defaultValue="checklist" className="flex-1 flex flex-col">
                            <div className="px-4 pt-2 border-b">
                                <TabsList className="w-full justify-start bg-transparent p-0 h-8 gap-6">
                                    <TabsTrigger value="checklist" className="text-xs data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 data-[state=active]:shadow-none rounded-none px-0 pb-2">Rep Checklist</TabsTrigger>
                                    <TabsTrigger value="history" className="text-xs data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 data-[state=active]:shadow-none rounded-none px-0 pb-2">Call History</TabsTrigger>
                                    <TabsTrigger value="new-lead" disabled className="text-xs data-[state=active]:border-b-2 data-[state=active]:border-indigo-600 data-[state=active]:shadow-none rounded-none px-0 pb-2 opacity-50 cursor-not-allowed">New B2B Lead</TabsTrigger>
                                </TabsList>
                            </div>

                            <TabsContent value="checklist" className="flex-1 p-4 m-0 overflow-y-auto">
                                <div className="space-y-2">
                                    <div className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-all">
                                        <Checkbox id="verify" checked={checklist.verify} onCheckedChange={(c) => setChecklist(p => ({...p, verify: c}))} />
                                        <div className="grid gap-1 leading-none">
                                            <label htmlFor="verify" className="text-sm font-medium text-slate-900 cursor-pointer">Verify Decision Maker</label>
                                            <p className="text-xs text-slate-500">Confirm you are speaking with {activeLead.name}.</p>
                                        </div>
                                    </div>
                                    <div className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-all">
                                        <Checkbox id="purpose" checked={checklist.purpose} onCheckedChange={(c) => setChecklist(p => ({...p, purpose: c}))} />
                                        <div className="grid gap-1 leading-none">
                                            <label htmlFor="purpose" className="text-sm font-medium text-slate-900 cursor-pointer">State Purpose</label>
                                            <p className="text-xs text-slate-500">Reference the {activeLead.personaVariant?.split('_')[1] || 'project'} immediately.</p>
                                        </div>
                                    </div>
                                    <div className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-all">
                                        <Checkbox id="discovery" checked={checklist.discovery} onCheckedChange={(c) => setChecklist(p => ({...p, discovery: c}))} />
                                        <div className="grid gap-1 leading-none">
                                            <label htmlFor="discovery" className="text-sm font-medium text-slate-900 cursor-pointer">Ask Discovery Question</label>
                                            <p className="text-xs text-slate-500">"How are you currently handling X?"</p>
                                        </div>
                                    </div>
                                </div>
                            </TabsContent>

                            <TabsContent value="history" className="flex-1 p-0 m-0 overflow-hidden">
                                <ScrollArea className="h-full p-4">
                                    <div className="space-y-3">
                                        {history.length === 0 ? (
                                            <div className="text-center text-slate-400 py-8 text-xs">No calls logged this session.</div>
                                        ) : (
                                            history.map((h) => (
                                                <div key={`${h.leadId}-${h.timestamp}`} className="flex flex-col p-3 bg-slate-50/50 rounded border border-slate-100 text-sm">
                                                    <div className="flex justify-between items-center mb-1">
                                                        <span className="font-semibold text-slate-700">{h.leadName}</span>
                                                        <span className="text-[10px] text-slate-400 font-mono">{new Date(h.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center text-xs text-slate-500">
                                                        <span className="capitalize flex items-center gap-1"><Check className="h-3 w-3 text-green-500" /> {h.result}</span>
                                                        <span>{formatTimer(h.durationSeconds)}</span>
                                                    </div>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </ScrollArea>
                            </TabsContent>
                        </Tabs>
                    </Card>
                )}
            </div>

            {/* RIGHT COLUMN: AI COPILOT */}
            <Card className="col-span-3 h-full flex flex-col border-none shadow-md bg-white overflow-hidden">
                <CardHeader className="pb-2 border-b bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
                    <CardTitle className="flex items-center gap-2 text-base">
                        <Sparkles className="h-4 w-4 text-yellow-300" /> 
                        AI Copilot
                    </CardTitle>
                    <CardDescription className="text-indigo-100 text-xs">Real-time conversation intelligence</CardDescription>
                </CardHeader>
                
                <div className="p-3 border-b bg-slate-50 space-y-3">
                    {/* Persona Toggle */}
                    <div className="flex bg-white rounded border p-1 shadow-sm">
                        <button 
                            onClick={() => setSelectedPersona('DM')}
                            className={cn(
                                "flex-1 text-[10px] uppercase font-bold py-1.5 rounded text-center transition-colors",
                                selectedPersona === 'DM' ? "bg-indigo-100 text-indigo-700" : "text-slate-400 hover:text-slate-600"
                            )}
                        >
                            Decision Maker
                        </button>
                        <button 
                            onClick={() => setSelectedPersona('GATEKEEPER')}
                            className={cn(
                                "flex-1 text-[10px] uppercase font-bold py-1.5 rounded text-center transition-colors",
                                selectedPersona === 'GATEKEEPER' ? "bg-indigo-100 text-indigo-700" : "text-slate-400 hover:text-slate-600"
                            )}
                        >
                            Gatekeeper
                        </button>
                    </div>

                    {/* Variant Chips */}
                    <div className="flex flex-wrap gap-1.5 justify-center">
                        {VARIANT_OPTIONS.map(variant => (
                            <Badge 
                                key={variant}
                                variant={selectedVariant === variant ? 'default' : 'outline'}
                                className={cn(
                                    "cursor-pointer text-[10px] px-2 h-5 transition-colors",
                                    selectedVariant === variant 
                                        ? "bg-indigo-600 hover:bg-indigo-700 border-indigo-600" 
                                        : "text-slate-500 hover:bg-indigo-50 border-slate-200"
                                )}
                                onClick={() => setSelectedVariant(variant)}
                            >
                                {variant}
                            </Badge>
                        ))}
                    </div>
                </div>

                <ScrollArea className="flex-1 p-4 bg-slate-50/30">
                    <div className="space-y-5">
                        
                        {/* Next Best Reply */}
                        <div>
                            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                                <MessageSquare className="h-3 w-3" /> Next Best Reply
                            </h4>
                            <div className="bg-white border border-indigo-100 rounded-lg p-3 text-slate-800 text-xs leading-relaxed shadow-sm relative group">
                                {formattedScript}
                                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Button variant="ghost" size="icon" className="h-5 w-5 text-slate-300 hover:text-indigo-600">
                                        <ClipboardCheck className="h-3 w-3" />
                                    </Button>
                                </div>
                            </div>
                        </div>

                        <Separator className="bg-slate-200/60" />

                        {/* Anticipatory Replies */}
                        <div>
                             <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                                <ShieldCheck className="h-3 w-3" /> Anticipatory Replies
                            </h4>
                            <div className="space-y-3">
                                {mockAnticipatoryReplies && mockAnticipatoryReplies.map((item) => (
                                    <div key={item.label || item.ifTheySay} className="group border bg-white rounded-lg p-2.5 hover:border-indigo-300 hover:shadow-sm transition-all cursor-pointer">
                                        <div className="text-xs font-semibold text-indigo-700 mb-1">
                                            "{item.ifTheySay}"
                                        </div>
                                        <div className="text-xs text-slate-600 pl-2 border-l-2 border-indigo-100 group-hover:border-indigo-400 transition-colors">
                                            "{item.youSay}"
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                        
                        {/* Gatekeeper Extra Intel */}
                        {activeIntel?.gatekeeperIntel && selectedPersona === 'GATEKEEPER' && (
                             <div className="mt-4 bg-orange-50 border border-orange-200 rounded p-3 animate-in slide-in-from-bottom-2">
                                <h4 className="text-[10px] font-bold text-orange-800 uppercase mb-1 flex items-center gap-1">
                                    <User className="h-3 w-3" /> Gatekeeper Note
                                </h4>
                                <p className="text-xs text-orange-800/80 italic leading-relaxed">{activeIntel.gatekeeperIntel}</p>
                             </div>
                        )}
                    </div>
                </ScrollArea>
            </Card>
        </div>
    );
};

export default CallConsole;
