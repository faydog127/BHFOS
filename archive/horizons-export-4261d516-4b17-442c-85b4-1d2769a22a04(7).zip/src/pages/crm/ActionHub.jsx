import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { List, LayoutGrid, Calendar } from 'lucide-react';
import ActionHubKanbanView from '@/components/crm/action-hub/ActionHubKanbanView';
import ActionHubListView from '@/components/crm/action-hub/ActionHubListView';
import ActionHubCalendarView from '@/components/crm/action-hub/ActionHubCalendarView';

const ActionHub = () => {
    const { toast } = useToast();
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [view, setView] = useState('kanban'); // 'list', 'kanban', 'calendar'

    const fetchTasks = useCallback(async () => {
        setLoading(true);
        // Query the new public view 'v_tasks_public'
        const { data, error } = await supabase
            .from('v_tasks_public')
            .select(`
                *,
                lead:v_leads_public (
                    id,
                    first_name,
                    last_name,
                    company
                )
            `)
            .order('due_at', { ascending: true });

        if (error) {
            toast({ variant: 'destructive', title: 'Error fetching tasks', description: "Public access to tasks is restricted for security." });
            setTasks([]);
        } else {
            setTasks(data);
        }
        setLoading(false);
    }, [toast]);

    useEffect(() => {
        fetchTasks();
    }, [fetchTasks]);

    const handleTaskUpdate = useCallback(async (taskId, updates) => {
        toast({ variant: 'destructive', title: 'Update failed', description: 'Public access to tasks is restricted.' });
    }, [toast]);

    const renderView = () => {
        if (loading) {
            return <div className="text-center p-10">Loading tasks...</div>;
        }
        
        if (tasks.length === 0) {
            return <div className="text-center p-10 text-gray-500">Task data is not available in public mode for security reasons.</div>;
        }

        switch (view) {
            case 'list':
                return <ActionHubListView tasks={tasks} onTaskUpdate={handleTaskUpdate} />;
            case 'kanban':
                return <ActionHubKanbanView tasks={tasks} onTaskUpdate={handleTaskUpdate} />;
            case 'calendar':
                return <ActionHubCalendarView tasks={tasks} onTaskUpdate={handleTaskUpdate} />;
            default:
                return <ActionHubKanbanView tasks={tasks} onTaskUpdate={handleTaskUpdate} />;
        }
    };

    return (
        <>
            <Helmet>
                <title>Action Hub | TVG CRM</title>
            </Helmet>
            <div className="h-full flex flex-col p-4 md:p-6">
                <header className="flex justify-between items-center mb-6">
                    <h1 className="text-3xl font-bold text-gray-800">Action Hub</h1>
                    <div className="flex items-center gap-2 p-1 bg-gray-200 rounded-lg">
                        <Button variant={view === 'list' ? 'secondary' : 'ghost'} size="sm" onClick={() => setView('list')}>
                            <List className="h-4 w-4 mr-2" /> List
                        </Button>
                        <Button variant={view === 'kanban' ? 'secondary' : 'ghost'} size="sm" onClick={() => setView('kanban')}>
                            <LayoutGrid className="h-4 w-4 mr-2" /> Kanban
                        </Button>
                        <Button variant={view === 'calendar' ? 'secondary' : 'ghost'} size="sm" onClick={() => setView('calendar')}>
                            <Calendar className="h-4 w-4 mr-2" /> Calendar
                        </Button>
                    </div>
                </header>
                <div className="flex-1 overflow-auto">
                    {renderView()}
                </div>
            </div>
        </>
    );
};

export default ActionHub;