
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Calendar, HeartHandshake as Handshake } from 'lucide-react'; // Added Handshake icon
import { Button } from '@/components/ui/button';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Partners', path: '/partners' }, // Added Partners link
    { name: 'Gallery', path: '/gallery' },
    { name: 'Blog', path: '/blog' },
    { name: 'FAQ', path: '/faq' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path) => location.pathname === path || (path === '/partners' && location.pathname.startsWith('/partners/')); // Improved active state for partners

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Logo */}
          <Link to="/" className="flex-shrink-0">
            <img 
              src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/08435323de98fe5fafabc3ec7d834166.png" 
              alt="The Vent Guys Logo" 
              className="h-[73.6px] w-auto" 
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-semibold transition-colors ${
                  isActive(link.path)
                    ? 'text-[#D7263D]'
                    : 'text-gray-700 hover:text-[#D7263D]'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* Desktop CTA Buttons */}
          <div className="hidden lg:flex items-center space-x-4">
            <a href="tel:+13213609704">
              <Button variant="outline" className="border-[#1B263B] text-[#1B263B] hover:bg-[#1B263B] hover:text-white">
                <Phone className="mr-2 h-4 w-4" />
                (321) 360-9704
              </Button>
            </a>
            <Link to="/contact">
              <Button className="bg-[#D7263D] hover:bg-[#b51f31] text-white">
                <Calendar className="mr-2 h-4 w-4" />
                Book Now
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2 rounded-md text-gray-700 hover:text-[#D7263D] hover:bg-gray-100 transition-colors"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="lg:hidden py-4 border-t">
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`text-base font-semibold px-4 py-2 rounded-md transition-colors ${
                    isActive(link.path)
                      ? 'text-[#D7263D] bg-[#D7263D]/10'
                      : 'text-gray-700 hover:text-[#D7263D] hover:bg-gray-100'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
              <div className="px-4 pt-4 border-t space-y-3">
                <a href="tel:+13213609704" className="block">
                  <Button variant="outline" className="w-full border-[#1B263B] text-[#1B263B]">
                    <Phone className="mr-2 h-4 w-4" />
                    (321) 360-9704
                  </Button>
                </a>
                <Link to="/contact" onClick={() => setIsOpen(false)} className="block">
                  <Button className="w-full bg-[#D7263D] hover:bg-[#b51f31] text-white">
                    <Calendar className="mr-2 h-4 w-4" />
                    Book Now
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;
