// This file is obsolete and has been replaced by the logic in CallConsole.jsx.
// It is being cleared to prevent conflicts.
import React from 'react';

const NewCallConsole = () => {
  return null;
};

export default NewCallConsole;