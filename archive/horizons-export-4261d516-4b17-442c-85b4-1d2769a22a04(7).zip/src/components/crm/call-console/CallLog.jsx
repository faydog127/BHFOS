import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Book, MessageSquare, Mail, Phone, Calendar } from 'lucide-react';

const LogItem = ({ log }) => {
    const icons = {
        'call': <Phone className="h-4 w-4 text-gray-500" />,
        'email': <Mail className="h-4 w-4 text-gray-500" />,
        'sms': <MessageSquare className="h-4 w-4 text-gray-500" />,
        'meeting': <Calendar className="h-4 w-4 text-gray-500" />,
        'note': <Book className="h-4 w-4 text-gray-500" />,
    };

    const getIcon = () => {
        if(log.final_outcome_at_send) return icons.call; // Defaulting call logs
        if(log.channels_used?.includes('email')) return icons.email;
        if(log.channels_used?.includes('sms')) return icons.sms;
        return icons.note;
    }

    return (
        <div className="flex items-start space-x-3 py-3">
            <div className="flex-shrink-0 pt-1">
                {getIcon()}
            </div>
            <div className="flex-1">
                <div className="flex justify-between items-center">
                    <p className="text-sm font-semibold text-gray-800">
                        {log.template_id || `Call: ${log.final_outcome_at_send}`}
                    </p>
                    <p className="text-xs text-gray-400">
                        {new Date(log.timestamp_utc || log.created_at).toLocaleDateString()}
                    </p>
                </div>
                 <p className="text-sm text-gray-600">
                    {log.notes || 'No notes for this interaction.'}
                </p>
            </div>
        </div>
    );
}

const CallLog = ({ lead }) => {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLogs = async () => {
            if (!lead) {
                setLogs([]);
                setLoading(false);
                return;
            }

            setLoading(true);
            const { data: callLogs, error: callError } = await supabase
                .from('call_logs')
                .select('*')
                .eq('lead_id', lead.id);

            const { data: sendLogs, error: sendError } = await supabase
                .from('send_log')
                .select('*')
                .eq('lead_id', lead.id);

            if (callError || sendError) {
                console.error("Error fetching logs:", callError || sendError);
                setLogs([]);
            } else {
                const combined = [
                    ...(callLogs || []),
                    ...(sendLogs || [])
                ].sort((a, b) => new Date(b.created_at || b.timestamp_utc) - new Date(a.created_at || a.timestamp_utc));
                setLogs(combined);
            }
            setLoading(false);
        };

        fetchLogs();
    }, [lead]);

    if (!lead) {
        return (
            <div className="flex flex-col items-center justify-center h-full p-4 text-center">
                <Book className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-semibold text-gray-700">No Lead Selected</h3>
                <p className="text-sm text-gray-500">Select a lead to view their interaction history.</p>
            </div>
        );
    }
    
    if (loading) return <div className="p-4 text-center text-gray-500">Loading log...</div>

    return (
        <div className="h-full p-4 flex flex-col">
            <div className="flex-1 overflow-y-auto divide-y divide-gray-200">
                {logs.length > 0 ? (
                    logs.map(log => <LogItem key={log.id || log.send_id} log={log} />)
                ) : (
                    <div className="text-center text-gray-500 pt-8">
                        <p>No interactions logged for this lead yet.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CallLog;