
import React from 'react';
import { Phone, Calendar, HeartHandshake as Handshake } from 'lucide-react';
import { Link } from 'react-router-dom';

const MobileCtaBar = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-[#1B263B] shadow-lg lg:hidden z-40">
      <div className="flex justify-around items-center h-16">
        <a href="tel:+13213609704" className="flex flex-col items-center text-white text-xs font-semibold">
          <Phone className="h-5 w-5 mb-1" />
          Call Now
        </a>
        <Link to="/contact" className="flex flex-col items-center text-white text-xs font-semibold">
          <Calendar className="h-5 w-5 mb-1" />
          Book Online
        </Link>
        <Link to="/partners" className="flex flex-col items-center text-white text-xs font-semibold">
          <Handshake className="h-5 w-5 mb-1" />
          Partners
        </Link>
      </div>
    </div>
  );
};

export default MobileCtaBar;
