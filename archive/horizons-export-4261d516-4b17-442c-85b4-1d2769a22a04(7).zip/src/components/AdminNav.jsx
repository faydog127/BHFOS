import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Settings, LogOut, Image, Users, Upload, BarChart2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const AdminNav = () => {
    const { toast } = useToast();
    const location = useLocation();

    const handleLogout = () => {
        toast({
            title: "Logout Clicked",
            description: "Authentication and logout functionality will be implemented here.",
        });
    };

    const navLinks = [
        { to: "/admin", icon: LayoutDashboard, text: "Dashboard" },
        { to: "/admin/image-diversity-tracker", icon: BarChart2, text: "Diversity Tracker" },
        { to: "/admin/upload-image", icon: Upload, text: "Upload Image" },
        { to: "/admin/testimonials", icon: Users, text: "Testimonials" },
    ];

    const isActive = (path) => location.pathname === path;

    return (
        <nav className="bg-[#1B263B] text-white w-64 min-h-screen p-4 flex flex-col">
            <div className="text-2xl font-bold mb-10">
                TVG Admin
            </div>
            <ul className="space-y-2 flex-grow">
                {navLinks.map(link => (
                     <li key={link.to}>
                        <Link to={link.to} className={`flex items-center p-2 rounded-lg transition-colors ${isActive(link.to) ? 'bg-[#D7263D] text-white' : 'hover:bg-gray-700'}`}>
                            <link.icon className="mr-3" />
                            {link.text}
                        </Link>
                    </li>
                ))}
                {/* Placeholder for future settings page */}
                <li>
                    <a href="#" onClick={() => toast({ description: "Settings page not yet implemented."})} className="flex items-center p-2 rounded-lg hover:bg-gray-700 opacity-50 cursor-not-allowed">
                        <Settings className="mr-3" />
                        Settings
                    </a>
                </li>
            </ul>
            <div>
                <button onClick={handleLogout} className="flex items-center w-full p-2 rounded-lg hover:bg-gray-700">
                    <LogOut className="mr-3" />
                    Logout
                </button>
            </div>
        </nav>
    );
};

export default AdminNav;