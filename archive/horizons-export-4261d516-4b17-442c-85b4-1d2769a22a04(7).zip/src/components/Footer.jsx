import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const brevardCounty = [
    { name: "Rockledge", path: "/rockledge-air-duct-cleaning" },
    { name: "Merritt Island", path: "/merritt-island-air-duct-cleaning" },
    { name: "Cocoa", path: "/cocoa-air-duct-cleaning" },
    { name: "Titusville", path: "/titusville-air-duct-cleaning" },
    { name: "Melbourne", path: "/melbourne-air-duct-cleaning" },
    { name: "Viera", path: "/viera-air-duct-cleaning" },
    { name: "Suntree", path: "/suntree-air-duct-cleaning" },
    { name: "Port St. John", path: "/port-st-john-air-duct-cleaning" },
  ];

  const volusiaCounty = [
    { name: "New Smyrna Beach", path: "/new-smyrna-beach-air-duct-cleaning" },
  ];

  return (
    <footer className="bg-[#1B263B] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Company Info */}
          <div className="lg:col-span-1">
            <Link to="/" className="mb-4 inline-block">
                <img 
                  src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/08435323de98fe5fafabc3ec7d834166.png" 
                  alt="The Vent Guys Logo" 
                  className="h-20 w-auto"
                />
            </Link>
            <p className="text-gray-300 mb-4 text-sm">
              NADCA-certified, veteran-owned air duct cleaning serving Brevard County, FL with excellence and integrity.
            </p>
            <div className="flex items-center gap-2 mb-2">
              <Link to="/nadca-standards-air-quality-protection">
                <img src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/e72bce9f7a2ca70965b162625bec1491.jpg" alt="NADCA Certified" className="h-12"/>
              </Link>
              <img src="https://horizons-cdn.hostinger.com/4261d516-4b17-442c-85b4-1d2769a22a04/ce0f4417890ef8b3cac12b2bceb2a897.jpg" alt="Service-Disabled Veteran-Owned Small Business Certified" className="h-12"/>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">Home</Link></li>
              <li><Link to="/about" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">About Us</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">Services</Link></li>
              <li><Link to="/gallery" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">Gallery</Link></li>
              <li><Link to="/blog" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">Blog</Link></li>
              <li><Link to="/contact" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h4 className="text-lg font-bold mb-4">Service Areas</h4>
            <div className="space-y-3">
              <div>
                <h5 className="font-semibold text-gray-200 mb-1">Brevard County</h5>
                <ul className="space-y-1">
                  {brevardCounty.map(area => (
                    <li key={area.name}><Link to={area.path} className="text-gray-300 hover:text-[#C2F5E9] transition-colors text-sm">{area.name}</Link></li>
                  ))}
                </ul>
              </div>
              <div>
                <h5 className="font-semibold text-gray-200 mb-1">Volusia County</h5>
                <ul className="space-y-1">
                  {volusiaCounty.map(area => (
                    <li key={area.name}><Link to={area.path} className="text-gray-300 hover:text-[#C2F5E9] transition-colors text-sm">{area.name}</Link></li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Our Services */}
          <div>
            <h4 className="text-lg font-bold mb-4">Our Services</h4>
            <ul className="space-y-2">
              <li><Link to="/services" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">Air Duct Cleaning</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">Dryer Vent Cleaning</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">IAQ Testing</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">HVAC Maintenance</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-[#D7263D] flex-shrink-0 mt-0.5" />
                <a href="tel:+13213609704" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">
                  (321) 360-9704
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-[#D7263D] flex-shrink-0 mt-0.5" />
                <a href="mailto:info@vent-guys.com" className="text-gray-300 hover:text-[#C2F5E9] transition-colors">
                  info@vent-guys.com
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-[#D7263D] flex-shrink-0 mt-0.5" />
                <span className="text-gray-300">
                  530 Loxley Ct, Titusville FL 32780
                </span>
              </li>
            </ul>

            {/* Social Media */}
            <div className="flex gap-4 mt-6">
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#D7263D] transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#D7263D] transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#D7263D] transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 mt-8 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; {currentYear} The Vent Guys. All rights reserved. | <Link to="/privacy" className="hover:text-[#C2F5E9] transition-colors">Privacy Policy</Link></p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;