import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';
import { Bot, Save, Plus, Trash2, Loader2 } from 'lucide-react';

const ChatWidgetSettings = () => {
    const [settings, setSettings] = useState({ enabled: true, greeting: '' });
    const [objections, setObjections] = useState([]);
    const [loadingSettings, setLoadingSettings] = useState(true);
    const [loadingObjections, setLoadingObjections] = useState(true);
    const { toast } = useToast();

    const fetchSettings = async () => {
        setLoadingSettings(true);
        const { data, error } = await supabase.from('widget_settings').select('*');
        if (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch widget settings.' });
        } else if (data) {
            const newSettings = {};
            data.forEach(item => {
                newSettings[item.key] = item.value;
            });
            setSettings(prev => ({ ...prev, ...newSettings }));
        }
        setLoadingSettings(false);
    };

    const fetchObjections = async () => {
        setLoadingObjections(true);
        const { data, error } = await supabase.from('objections').select('*').order('created_at');
        if (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch objections.' });
        } else {
            setObjections(data);
        }
        setLoadingObjections(false);
    };

    useEffect(() => {
        fetchSettings();
        fetchObjections();
    }, []);

    const handleSettingChange = (key, value) => {
        setSettings(prev => ({ ...prev, [key]: value }));
    };

    const handleObjectionChange = (index, field, value) => {
        const newObjections = [...objections];
        newObjections[index][field] = value;
        setObjections(newObjections);
    };
    
    const addNewObjection = () => {
        setObjections([...objections, { id: null, keyword: '', response: '' }]);
    };
    
    const removeObjection = async (id, index) => {
        if (id) {
            const { error } = await supabase.from('objections').delete().eq('id', id);
            if (error) {
                toast({ variant: 'destructive', title: 'Error', description: 'Could not delete objection.' });
                return;
            }
        }
        const newObjections = objections.filter((_, i) => i !== index);
        setObjections(newObjections);
        toast({ title: 'Success', description: 'Objection removed.' });
    };

    const handleSave = async () => {
        const settingsPromises = Object.entries(settings).map(([key, value]) =>
            supabase.from('widget_settings').upsert({ key, value }, { onConflict: 'key' })
        );
        
        const objectionsToUpsert = objections.map(({ id, keyword, response }) => ({ id: id || undefined, keyword, response }));
        const objectionsPromise = supabase.from('objections').upsert(objectionsToUpsert);
        
        const [settingsResults, objectionsResult] = await Promise.all([
            Promise.all(settingsPromises),
            objectionsPromise
        ]);

        const hasError = settingsResults.some(res => res.error) || objectionsResult.error;

        if (hasError) {
            toast({ variant: 'destructive', title: 'Error', description: 'Could not save all settings.' });
            console.error('Settings errors:', settingsResults.map(r => r.error).filter(Boolean));
            console.error('Objections error:', objectionsResult.error);
        } else {
            toast({ title: 'Success!', description: 'All settings saved successfully.' });
            fetchObjections(); // re-fetch to get new IDs
        }
    };

    return (
        <>
            <Helmet>
                <title>Chat Widget Settings | CRM</title>
            </Helmet>
            <div className="space-y-8 max-w-4xl mx-auto">
                <div className="flex items-center justify-between">
                    <h1 className="text-3xl font-bold text-[#091e39] flex items-center gap-3"><Bot /> Chat Widget Settings</h1>
                    <Button onClick={handleSave}>
                        <Save className="h-4 w-4 mr-2" /> Save All Changes
                    </Button>
                </div>
                
                <Card>
                    <CardHeader>
                        <CardTitle>General Settings</CardTitle>
                        <CardDescription>Control the basic behavior of the chat widget.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {loadingSettings ? <Loader2 className="animate-spin" /> : (
                            <>
                                <div className="flex items-center space-x-2">
                                    <Switch
                                        id="widget-enabled"
                                        checked={settings.enabled}
                                        onCheckedChange={(checked) => handleSettingChange('enabled', checked)}
                                    />
                                    <Label htmlFor="widget-enabled">Enable Chat Widget on Website</Label>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="greeting-message">Initial Greeting Message</Label>
                                    <Textarea
                                        id="greeting-message"
                                        placeholder="Hi there! I'm Klaire, the virtual assistant..."
                                        value={settings.greeting}
                                        onChange={(e) => handleSettingChange('greeting', e.target.value)}
                                    />
                                </div>
                            </>
                        )}
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Objection Handling</CardTitle>
                        <CardDescription>Teach Klaire how to respond to common sales objections or difficult questions.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {loadingObjections ? <Loader2 className="animate-spin" /> : (
                            <>
                                {objections.map((obj, index) => (
                                    <div key={obj.id || index} className="flex items-start gap-4 p-4 border rounded-lg">
                                        <div className="flex-1 space-y-2">
                                            <Label htmlFor={`keyword-${index}`}>Keyword/Phrase</Label>
                                            <Input
                                                id={`keyword-${index}`}
                                                value={obj.keyword}
                                                onChange={(e) => handleObjectionChange(index, 'keyword', e.target.value)}
                                                placeholder="e.g., 'too expensive'"
                                            />
                                            <Label htmlFor={`response-${index}`}>Klaire's Response</Label>
                                            <Textarea
                                                id={`response-${index}`}
                                                value={obj.response}
                                                onChange={(e) => handleObjectionChange(index, 'response', e.target.value)}
                                                placeholder="e.g., 'I understand that budget is a concern...'"
                                            />
                                        </div>
                                        <Button variant="destructive" size="icon" className="mt-6" onClick={() => removeObjection(obj.id, index)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                ))}
                                <Button variant="outline" onClick={addNewObjection}>
                                    <Plus className="h-4 w-4 mr-2" /> Add New Objection
                                </Button>
                            </>
                        )}
                    </CardContent>
                </Card>
            </div>
        </>
    );
};

export default ChatWidgetSettings;