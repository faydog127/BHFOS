import React, { useState, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Terminal, Trash2, RefreshCw, Cpu, Database, 
  CheckCircle2, AlertTriangle, XCircle, ArrowRight, ShieldCheck, Activity,
  Server, Lock, Copy, ClipboardCheck
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/customSupabaseClient';
import { useNavigate } from 'react-router-dom';

// Import the BlackHorse manifest and the checkTable utility
import { blackhorseManifest } from '@/build/manifests/blackhorse';
import { checkTable } from '@/build/modules';

// The Feature Tree is derived directly from the manifest
const FEATURE_TREE = blackhorseManifest;

const SystemHealth = () => {
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('features');
    const [loading, setLoading] = useState(false);
    
    // Feature Audit State
    const [auditResults, setAuditResults] = useState({});
    const [auditLoading, setAuditLoading] = useState(true);

    // Environment & Session State
    const [session, setSession] = useState(null);
    const [envCheck, setEnvCheck] = useState([]);
    const [isAuthorized, setIsAuthorized] = useState(false);
    const [authChecking, setAuthChecking] = useState(true);

    // Prescription / SQL Copy State
    const [copiedKey, setCopiedKey] = useState(null);

    useEffect(() => {
        checkAuthorization();
    }, []);

    // -------------------------------------------------------------------------
    // SECURITY GATE
    // -------------------------------------------------------------------------
    const checkAuthorization = async () => {
        setAuthChecking(true);
        const { data: { session: currentSession } } = await supabase.auth.getSession();
        
        if (!currentSession) {
            navigate('/login');
            return;
        }

        setSession(currentSession);

        // Check user role in app_user_roles
        const { data: roleData, error } = await supabase
            .from('app_user_roles')
            .select('role')
            .eq('user_id', currentSession.user.id)
            .single();

        if (error || !roleData || !['admin', 'owner', 'manager'].includes(roleData.role)) {
            toast({
                variant: "destructive",
                title: "Access Denied",
                description: "You do not have permission to view the System Health Console.",
            });
            navigate('/crm/dashboard');
            return;
        }

        setIsAuthorized(true);
        setAuthChecking(false);
        
        // Only run audit if authorized
        runSystemAudit();
        checkEnv();
    };

    // -------------------------------------------------------------------------
    // SYSTEM AUDIT LOGIC
    // -------------------------------------------------------------------------
    const runSystemAudit = async () => {
        setAuditLoading(true);
        const results = {};
        
        // 1. Audit Tables for every module in the manifest
        // We use the imported checkTable utility for consistency
        for (const key of Object.keys(FEATURE_TREE)) {
            const feature = FEATURE_TREE[key];
            
            // Check all tables defined in the module
            const tableChecks = await Promise.all(
                feature.tables.map(async (table) => ({
                    table,
                    exists: await checkTable(table)
                }))
            );
            
            const missingTables = tableChecks.filter(t => !t.exists).map(t => t.table);
            
            // 2. Custom Module Checks
            let customCheckError = null;
            // Only run checks if tables are present (otherwise checks will likely just fail on missing tables)
            if (missingTables.length === 0 && feature.checks) {
                try {
                    const checkPassed = await feature.checks();
                    if (!checkPassed) {
                        customCheckError = "Self-diagnostic check returned failure.";
                    }
                } catch (err) {
                    console.error(`Health check failed for ${key}:`, err);
                    customCheckError = err.message || "Unknown error during self-diagnostic.";
                }
            }

            results[key] = {
                missingTables,
                customCheckError,
                tableStatus: missingTables.length === 0 ? 'ok' : 'error'
            };
        }

        // 3. Check Dependencies (Post-Table Check)
        for (const key of Object.keys(FEATURE_TREE)) {
            const feature = FEATURE_TREE[key];
            const deps = feature.dependencies || [];
            const result = results[key];
            
            const brokenDeps = deps.filter(depId => {
                // Find the manifest key that corresponds to this dependency ID
                const matchingManifestKey = Object.keys(FEATURE_TREE).find(k => FEATURE_TREE[k].id === depId);
                
                // If dependency module isn't even in the manifest, it's missing entirely
                if (!matchingManifestKey) return true; 

                const depResult = results[matchingManifestKey];
                // Dependency is considered broken if it has missing tables OR failed custom checks
                return !depResult || depResult.missingTables.length > 0 || !!depResult.customCheckError;
            });
            
            results[key].brokenDependencies = brokenDeps;
            
            // Determine overall health status
            if (result.missingTables.length > 0 || result.customCheckError || brokenDeps.length > 0) {
                 results[key].status = 'degraded';
            } else {
                 results[key].status = 'healthy';
            }
        }

        setAuditResults(results);
        setAuditLoading(false);
        
        if (Object.values(results).some(r => r.status === 'degraded')) {
            toast({
                variant: "destructive",
                title: "System Audit Complete",
                description: "Issues detected in one or more modules.",
            });
        } else {
            toast({
                title: "System Audit Complete",
                description: "All systems nominal.",
                className: "bg-green-50 border-green-200"
            });
        }
    };

    const getPrescriptionSQL = (missingTables) => {
        if (!missingTables || missingTables.length === 0) return '';
        
        return `-- SAFETY PRESCRIPTION
-- Run this in your Supabase SQL Editor
-- WARNING: Always backup data before running migrations.

${missingTables.map(t => `-- Missing Table: ${t}
CREATE TABLE public.${t} (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  -- TODO: Add specific columns for ${t}
);
ALTER TABLE public.${t} ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable all access for authenticated users" ON public.${t} FOR ALL USING (auth.role() = 'authenticated');
`).join('\n')}
`;
    };

    const handleCopyPrescription = (key, missingTables) => {
        const sql = getPrescriptionSQL(missingTables);
        navigator.clipboard.writeText(sql);
        setCopiedKey(key);
        
        toast({
            title: "Prescription Copied",
            description: "SQL template copied to clipboard. Paste into Supabase SQL Editor.",
            className: "bg-amber-50 border-amber-200"
        });

        setTimeout(() => setCopiedKey(null), 3000);
    };

    const getPrescription = (featureKey) => {
        const result = auditResults[featureKey];
        if (!result) return "Loading...";
        
        if (result.status === 'healthy') return "System Nominal. No action required.";

        const prescriptions = [];
        if (result.brokenDependencies.length > 0) {
            // Map broken dependency IDs back to names for readability
            const depNames = result.brokenDependencies.map(dId => {
                 const mod = Object.values(FEATURE_TREE).find(m => m.id === dId);
                 return mod ? mod.name : dId;
            });
            prescriptions.push(`CRITICAL: Fix dependency modules first: ${depNames.join(', ')}`);
        }
        if (result.missingTables.length > 0) {
            prescriptions.push(`DATABASE: Missing tables detected: ${result.missingTables.join(', ')}`);
        }
        if (result.customCheckError) {
             prescriptions.push(`DIAGNOSTIC: ${result.customCheckError}`);
        }
        
        return prescriptions.join(' | ');
    };

    // -------------------------------------------------------------------------
    // ENV & UTILS LOGIC
    // -------------------------------------------------------------------------
    const checkEnv = () => {
        const vars = [
            { key: 'VITE_SUPABASE_URL', label: 'Supabase URL', exists: !!import.meta.env.VITE_SUPABASE_URL },
            { key: 'VITE_SUPABASE_ANON_KEY', label: 'Anon Key', exists: !!import.meta.env.VITE_SUPABASE_ANON_KEY },
            { key: 'MODE', label: 'Build Mode', value: import.meta.env.MODE },
        ];
        setEnvCheck(vars);
    };

    const handleClearStorage = () => {
        if (window.confirm('Clear all local storage? You will be logged out.')) {
            localStorage.clear();
            sessionStorage.clear();
            window.location.reload();
        }
    };

    const handleInvalidateQueries = async () => {
        setLoading(true);
        await queryClient.invalidateQueries();
        setTimeout(() => {
            setLoading(false);
            toast({ title: "Cache Invalidated", description: "All queries refetched." });
        }, 500);
    };

    if (authChecking) {
        return (
            <div className="flex h-screen items-center justify-center bg-slate-50">
                <div className="flex flex-col items-center gap-4">
                    <RefreshCw className="h-8 w-8 animate-spin text-indigo-600" />
                    <p className="text-sm font-medium text-slate-600">Verifying Security Clearance...</p>
                </div>
            </div>
        );
    }

    if (!isAuthorized) return null; // Should have redirected

    return (
        <div className="space-y-6 p-6 max-w-7xl mx-auto">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                        <Server className="h-6 w-6 text-indigo-600" />
                        System Health Console
                    </h2>
                    <p className="text-sm text-slate-500 mt-1">
                        Architecture: <span className="font-mono text-indigo-600 font-medium">BlackHorse Manifest v2.1</span>
                    </p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={runSystemAudit} disabled={auditLoading}>
                        <RefreshCw className={cn("h-4 w-4 mr-2", auditLoading && "animate-spin")} />
                        Run Audit
                    </Button>
                </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                <TabsList className="bg-slate-100 p-1">
                    <TabsTrigger value="features" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
                        <Database className="h-4 w-4 mr-2" /> Module Matrix
                    </TabsTrigger>
                    <TabsTrigger value="environment" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
                        <Cpu className="h-4 w-4 mr-2" /> Environment
                    </TabsTrigger>
                    <TabsTrigger value="debug" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
                        <Terminal className="h-4 w-4 mr-2" /> Debug Tools
                    </TabsTrigger>
                </TabsList>

                {/* FEATURE MATRIX TAB */}
                <TabsContent value="features" className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                        {Object.keys(FEATURE_TREE).map((key) => {
                            const feature = FEATURE_TREE[key];
                            const result = auditResults[key];
                            const isHealthy = result?.status === 'healthy';
                            const isLoading = !result;
                            const isCore = feature.id === 'core';
                            const hasMissingTables = result?.missingTables?.length > 0;

                            return (
                                <Card key={key} className={cn(
                                    "transition-all duration-200 flex flex-col",
                                    isHealthy ? "border-l-4 border-l-green-500" : "border-l-4 border-l-red-500",
                                    isCore && "bg-slate-50/80 shadow-sm"
                                )}>
                                    <CardHeader className="pb-3 pt-4 px-4 flex-grow-0">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex flex-col">
                                                <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-800">
                                                    {feature.name}
                                                </CardTitle>
                                                <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider mt-0.5">{feature.id}</span>
                                            </div>
                                            {isLoading ? (
                                                <Badge variant="outline" className="animate-pulse text-[10px]">...</Badge>
                                            ) : isHealthy ? (
                                                <div className="bg-green-100 p-1 rounded-full">
                                                    <CheckCircle2 className="h-3 w-3 text-green-600" />
                                                </div>
                                            ) : (
                                                <div className="bg-red-100 p-1 rounded-full">
                                                    <Activity className="h-3 w-3 text-red-600" />
                                                </div>
                                            )}
                                        </div>
                                        <CardDescription className="text-xs line-clamp-2 min-h-[2.5em]">
                                            {feature.description}
                                        </CardDescription>
                                    </CardHeader>
                                    
                                    <CardContent className="px-4 pb-4 pt-0 text-sm space-y-3 flex-grow">
                                        <div className="h-px bg-slate-100 w-full" />
                                        
                                        {/* Status Indicators */}
                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                            <div className={cn("p-1.5 rounded border text-center", 
                                                result?.missingTables?.length > 0 ? "bg-red-50 border-red-100" : "bg-slate-50 border-slate-100"
                                            )}>
                                                <span className="text-slate-500 block text-[10px] uppercase tracking-wide">Tables</span>
                                                <span className={cn("font-bold", result?.missingTables?.length > 0 ? "text-red-600" : "text-slate-700")}>
                                                    {result?.missingTables?.length > 0 ? `${result.missingTables.length} MISSING` : `${feature.tables.length} OK`}
                                                </span>
                                            </div>
                                            <div className={cn("p-1.5 rounded border text-center", 
                                                result?.brokenDependencies?.length > 0 ? "bg-amber-50 border-amber-100" : "bg-slate-50 border-slate-100"
                                            )}>
                                                <span className="text-slate-500 block text-[10px] uppercase tracking-wide">Deps</span>
                                                <span className={cn("font-bold", result?.brokenDependencies?.length > 0 ? "text-amber-600" : "text-slate-700")}>
                                                    {result?.brokenDependencies?.length > 0 ? "BROKEN" : "OK"}
                                                </span>
                                            </div>
                                        </div>

                                        {/* Prescription (if error) */}
                                        {!isHealthy && !isLoading && (
                                            <div className="p-2 bg-red-50 border border-red-100 rounded text-[11px] leading-tight text-red-900 mt-2 space-y-2">
                                                <div>
                                                    <strong className="flex items-center gap-1 mb-1 text-red-700 font-semibold uppercase tracking-wider">
                                                        <AlertTriangle className="h-3 w-3" /> Action Required:
                                                    </strong>
                                                    {getPrescription(key)}
                                                </div>
                                                
                                                {/* ACTION BUTTON: Copy Prescription */}
                                                {hasMissingTables && (
                                                    <Button 
                                                        size="sm" 
                                                        variant="outline" 
                                                        className="w-full h-7 text-[10px] bg-white hover:bg-amber-50 border-amber-200 text-amber-700 hover:text-amber-800 transition-colors"
                                                        onClick={() => handleCopyPrescription(key, result.missingTables)}
                                                    >
                                                        {copiedKey === key ? (
                                                            <>
                                                                <ClipboardCheck className="h-3 w-3 mr-1.5" />
                                                                Copied!
                                                            </>
                                                        ) : (
                                                            <>
                                                                <Copy className="h-3 w-3 mr-1.5" />
                                                                Copy Repair SQL
                                                            </>
                                                        )}
                                                    </Button>
                                                )}
                                            </div>
                                        )}
                                        
                                        {/* Dependencies List */}
                                        {feature.dependencies && feature.dependencies.length > 0 && (
                                            <div className="flex flex-wrap gap-1 mt-3">
                                                {feature.dependencies.map(dId => {
                                                    const mod = Object.values(FEATURE_TREE).find(m => m.id === dId);
                                                    const isDepHealthy = auditResults[Object.keys(FEATURE_TREE).find(k => FEATURE_TREE[k].id === dId)]?.status === 'healthy';
                                                    return (
                                                        <Badge 
                                                            key={dId} 
                                                            variant="secondary" 
                                                            className={cn("text-[10px] px-1.5 py-0 h-5 font-normal", isDepHealthy ? "text-slate-500 bg-slate-100" : "text-red-500 bg-red-50")}
                                                        >
                                                            <ArrowRight className="h-2 w-2 mr-1 opacity-50" />
                                                            {mod ? mod.name.split(' ')[0] : dId}
                                                        </Badge>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            );
                        })}
                    </div>
                </TabsContent>

                {/* ENVIRONMENT TAB */}
                <TabsContent value="environment" className="space-y-4">
                     <Card>
                        <CardHeader>
                            <CardTitle className="text-base flex items-center gap-2">
                                <ShieldCheck className="h-5 w-5 text-indigo-600" />
                                Environment Variables
                            </CardTitle>
                            <CardDescription>Build-time configuration check</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {envCheck.map((item, i) => (
                                <div key={i} className="flex justify-between items-center text-sm p-3 bg-slate-50 rounded border">
                                    <span className="font-mono text-xs text-slate-600 font-semibold">{item.key}</span>
                                    {item.exists !== undefined ? (
                                        <Badge variant={item.exists ? "outline" : "destructive"} className={item.exists ? "bg-green-50 text-green-700 border-green-200" : ""}>
                                            {item.exists ? 'Available' : 'Missing'}
                                        </Badge>
                                    ) : (
                                        <span className="font-mono text-xs bg-slate-200 px-2 py-1 rounded text-slate-700">{item.value}</span>
                                    )}
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* DEBUG TOOLS TAB */}
                <TabsContent value="debug" className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                         <Card>
                            <CardHeader>
                                <CardTitle className="text-base">Client State</CardTitle>
                                <CardDescription>Manage local persistence and cache</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex justify-between items-center p-3 bg-slate-50 rounded border">
                                    <div className="flex flex-col">
                                        <span className="text-sm font-medium">React Query Cache</span>
                                        <span className="text-xs text-slate-500">Force refetch all data</span>
                                    </div>
                                    <Button variant="outline" size="sm" onClick={handleInvalidateQueries} disabled={loading}>
                                        <RefreshCw className={cn("h-4 w-4 mr-2", loading && "animate-spin")} />
                                        Invalidate
                                    </Button>
                                </div>
                                <div className="flex justify-between items-center p-3 bg-red-50 border border-red-100 rounded">
                                    <div className="flex flex-col">
                                        <span className="text-sm font-medium text-red-900">Local Storage</span>
                                        <span className="text-xs text-red-700">Clear all local data & logout</span>
                                    </div>
                                    <Button variant="destructive" size="sm" onClick={handleClearStorage}>
                                        <Trash2 className="h-4 w-4 mr-2" />
                                        Clear All
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                        
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-base flex items-center gap-2">
                                    <Lock className="h-4 w-4 text-slate-500" />
                                    Session Inspector
                                </CardTitle>
                                <CardDescription>Current authenticated context</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <ScrollArea className="h-[200px] w-full rounded-md border bg-slate-950 p-4 shadow-inner">
                                    <code className="text-xs font-mono text-green-400 block whitespace-pre font-medium">
                                        {session ? JSON.stringify({
                                            id: session.user.id,
                                            email: session.user.email,
                                            role: session.user.role,
                                            app_metadata: session.user.app_metadata,
                                            expires_at: new Date(session.expires_at * 1000).toLocaleString()
                                        }, null, 2) : '// No active session'}
                                    </code>
                                </ScrollArea>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    );
};

export default SystemHealth;