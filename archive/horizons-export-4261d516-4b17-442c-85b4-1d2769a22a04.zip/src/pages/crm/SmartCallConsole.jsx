import React, { useState } from 'react';
import { 
  Phone, Search, History, MoreVertical, PlayCircle, 
  MessageSquare, CheckCircle2, ChevronLeft, ChevronRight,
  Menu, RefreshCw, Filter, Users, Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from "@/components/ui/sheet";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

// Mock Data to replicate the screenshot state
const MOCK_QUEUE = [
  { id: 1, name: 'Del-Air Heating and Air', contact: 'Corporate', location: 'Sanford', score: 98, type: 'HVAC' },
  { id: 2, name: 'Mechanical One', contact: 'Sales', location: 'Sanford', score: 95, type: 'HVAC' },
  { id: 3, name: 'Ferran Services', contact: 'Dispatch', location: 'Orlando', score: 92, type: 'HVAC' },
  { id: 4, name: 'Space Coast Mechanical', contact: 'Sarah Jones', location: 'Cocoa', score: 92, type: 'HVAC' },
  { id: 5, name: 'Advanced Air Home Services', contact: 'Manager', location: 'Edgewater', score: 90, type: 'HVAC' },
  { id: 6, name: 'Frank Gay Services', contact: 'Dispatch', location: 'Orlando', score: 90, type: 'HVAC' },
  { id: 7, name: 'Jacob Heating & Air', contact: 'Bob Jacob', location: 'DeLand', score: 88, type: 'HVAC' },
];

const ActiveCallView = ({ lead, isMobile }) => {
  const { toast } = useToast();
  
  const handleAction = (action) => {
    toast({
      title: "Action Triggered",
      description: `${action} for ${lead.name}`,
    });
  };

  return (
    <div className="flex flex-col h-full bg-white md:rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      {/* Active Call Header */}
      <div className="p-4 md:p-6 border-b border-slate-100 bg-slate-50/50">
        <div className="flex flex-col xl:flex-row xl:items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h1 className="text-xl md:text-2xl font-bold text-slate-900 leading-tight break-words">
              {lead.name}
            </h1>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <Badge variant="secondary" className="bg-slate-200 text-slate-700 hover:bg-slate-300">
                <Users className="w-3 h-3 mr-1" />
                {lead.contact}
              </Badge>
              <Badge variant="outline" className="border-slate-300 text-slate-600">
                <Search className="w-3 h-3 mr-1" />
                {lead.location}
              </Badge>
              <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200 border-0">
                {lead.type}
              </Badge>
            </div>
          </div>
          
          <div className="flex items-center gap-2 xl:self-start mt-2 xl:mt-0">
            <Button 
              size="lg" 
              className="bg-green-600 hover:bg-green-700 text-white shadow-md w-full xl:w-auto flex-1 xl:flex-none justify-center"
              onClick={() => handleAction('Calling')}
            >
              <Phone className="w-4 h-4 mr-2" />
              <span className="font-semibold">407-831-5600</span>
            </Button>
            <Button variant="outline" size="icon" className="shrink-0">
               <MoreVertical className="w-4 h-4 text-slate-500" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Action Area */}
      <ScrollArea className="flex-1 p-4 md:p-6 bg-white">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* AI Coach Card */}
          <Card className="bg-gradient-to-br from-indigo-50 to-white border-indigo-100 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center">
                     <PlayCircle className="w-6 h-6 text-indigo-600" />
                   </div>
                   <div>
                     <CardTitle className="text-lg text-indigo-950">AI Call Flow</CardTitle>
                     <CardDescription>Real-time coaching active</CardDescription>
                   </div>
                </div>
                <Button 
                  variant="destructive" 
                  size="sm" 
                  className="shadow-sm"
                  onClick={() => handleAction('Flagged Chaos')}
                >
                  Flag Chaos
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-white rounded-md border border-indigo-100 p-4 shadow-sm">
                <div className="flex justify-between items-center mb-2">
                   <h4 className="text-xs font-bold text-indigo-500 uppercase tracking-wider">Suggested Script</h4>
                   <Button variant="ghost" size="icon" className="h-6 w-6"><span className="sr-only">Copy</span><CheckCircle2 className="w-3 h-3" /></Button>
                </div>
                <p className="text-slate-700 text-base leading-relaxed">
                  "Hi {lead.contact}, this is [Your Name] with The Vent Guys. We've been working with several HVAC providers in {lead.location} to handle their overflow dryer vent cleanings. Are you currently referring that work out?"
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Call Logging Form */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-slate-400" />
              After Call Log
            </h3>
            
            <div className="grid gap-4">
               <div>
                 <label className="text-sm font-medium text-slate-700 mb-1.5 block">Outcome</label>
                 <select className="flex h-10 w-full items-center justify-between rounded-md border border-slate-200 bg-white px-3 py-2 text-sm ring-offset-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-950 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                    <option>Select Call Outcome...</option>
                    <option>Left Voicemail</option>
                    <option>Connected - Positive</option>
                    <option>Connected - Not Interested</option>
                    <option>Wrong Number</option>
                 </select>
               </div>
               
               <div>
                 <label className="text-sm font-medium text-slate-700 mb-1.5 block">Notes</label>
                 <textarea 
                    className="flex min-h-[120px] w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm ring-offset-white placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-950 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 resize-none"
                    placeholder="Summarize the conversation..."
                 />
               </div>

               <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white h-11 text-base shadow-sm" onClick={() => handleAction('Logged Call')}>
                  Log Interaction & Next Steps
               </Button>
            </div>
          </div>

        </div>
      </ScrollArea>
    </div>
  );
};

const SmartCallConsole = () => {
  const [selectedLead, setSelectedLead] = useState(MOCK_QUEUE[0]);
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  return (
    <div className="h-[calc(100vh-64px)] lg:h-screen w-full bg-slate-100 flex overflow-hidden">
      
      {/* 
        LEFT COLUMN: Call Queue 
        - Hidden on Tablet/Mobile (Drawer)
        - Visible on Desktop (XL)
      */}
      <aside className="hidden xl:flex w-80 flex-col bg-white border-r border-slate-200 shrink-0 z-10">
        <QueueListContent selectedLead={selectedLead} onSelect={setSelectedLead} />
      </aside>

      {/* MOBILE/TABLET QUEUE DRAWER */}
      <Sheet open={isQueueOpen} onOpenChange={setIsQueueOpen}>
        <SheetContent side="left" className="p-0 w-80">
          <QueueListContent selectedLead={selectedLead} onSelect={(lead) => {
            setSelectedLead(lead);
            setIsQueueOpen(false);
          }} />
        </SheetContent>
      </Sheet>

      {/* CENTER COLUMN: Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-100 relative">
        {/* Mobile/Tablet Toolbar */}
        <div className="xl:hidden h-14 bg-white border-b border-slate-200 flex items-center justify-between px-4 shrink-0">
           <Button variant="ghost" size="sm" className="gap-2 text-slate-600" onClick={() => setIsQueueOpen(true)}>
             <Menu className="w-5 h-5" />
             <span className="font-semibold">Queue</span>
           </Button>
           
           <span className="font-bold text-slate-900 truncate max-w-[150px]">
             {selectedLead?.name}
           </span>

           <Button variant="ghost" size="sm" className="gap-2 text-slate-600" onClick={() => setIsHistoryOpen(true)}>
             <History className="w-5 h-5" />
             <span className="hidden sm:inline font-semibold">History</span>
           </Button>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-2 md:p-4 lg:p-6 overflow-hidden">
          <div className="h-full max-w-5xl mx-auto">
             <ActiveCallView lead={selectedLead} />
          </div>
        </div>
      </main>

      {/* 
        RIGHT COLUMN: History 
        - Hidden on Tablet/Mobile (Drawer)
        - Visible on Desktop (XL)
      */}
      <aside className="hidden xl:flex w-80 flex-col bg-white border-l border-slate-200 shrink-0 z-10">
        <HistoryListContent />
      </aside>

      {/* MOBILE/TABLET HISTORY DRAWER */}
      <Sheet open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
        <SheetContent side="right" className="p-0 w-80">
          <HistoryListContent />
        </SheetContent>
      </Sheet>

    </div>
  );
};

// Sub-components to reuse in Drawer vs Sidebar
const QueueListContent = ({ selectedLead, onSelect }) => (
  <div className="flex flex-col h-full">
    <div className="p-4 border-b border-slate-100">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-bold text-lg flex items-center gap-2">
          <Phone className="w-5 h-5 text-blue-600" /> Call Queue
        </h2>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-blue-600">
          <RefreshCw className="w-4 h-4" />
        </Button>
      </div>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input placeholder="Search queue..." className="pl-9 bg-slate-50 border-slate-200" />
      </div>
    </div>
    <ScrollArea className="flex-1">
      <div className="p-2 space-y-1">
        {MOCK_QUEUE.map((lead) => (
          <div 
            key={lead.id}
            onClick={() => onSelect(lead)}
            className={cn(
              "p-3 rounded-lg cursor-pointer transition-all border border-transparent",
              selectedLead?.id === lead.id 
                ? "bg-blue-50 border-blue-200 shadow-sm" 
                : "hover:bg-slate-50 hover:border-slate-100"
            )}
          >
            <div className="flex justify-between items-start mb-1">
              <span className={cn(
                "font-semibold text-sm line-clamp-1",
                selectedLead?.id === lead.id ? "text-blue-700" : "text-slate-900"
              )}>{lead.name}</span>
              <span className={cn(
                "text-xs font-bold px-1.5 py-0.5 rounded",
                lead.score > 90 ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
              )}>{lead.score}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Users className="w-3 h-3" />
              <span>{lead.contact}</span>
              <span>•</span>
              <span>{lead.location}</span>
            </div>
          </div>
        ))}
      </div>
    </ScrollArea>
  </div>
);

const HistoryListContent = () => (
  <div className="flex flex-col h-full">
    <div className="p-4 border-b border-slate-100 bg-slate-50/50">
      <h2 className="font-bold text-sm uppercase tracking-wider text-slate-500">Interaction History</h2>
    </div>
    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
       <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
         <History className="w-8 h-8 text-slate-300" />
       </div>
       <p className="font-medium text-slate-900">No History Yet</p>
       <p className="text-sm mt-1 max-w-[200px]">Calls and chats will appear here automatically.</p>
    </div>
  </div>
);

export default SmartCallConsole;