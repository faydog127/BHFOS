import React, { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useToast } from "@/components/ui/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Rocket, Mic, Scale, MapPin, Star, BarChart3, Landmark, ListChecks } from 'lucide-react';
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const sections = [
    {
      key: 'identity',
      title: "Identity & Mission",
      description: "Core purpose and who you serve.",
      icon: <Rocket className="h-6 w-6"/>,
      color: "blue",
      fields: ["mission_statement", "primary_audience", "founding_story"]
    },
    {
      key: 'voice',
      title: "Brand Voice & Tone",
      description: "How your brand sounds and visualizes.",
      icon: <Mic className="h-6 w-6"/>,
      color: "purple",
      fields: ["voice_summary", "voice_details", "visual_anchoring"]
    },
    {
      key: 'services',
      title: "Service Offerings & Pricing",
      description: "Menu, CTAs, and pricing rules.",
      icon: <Scale className="h-6 w-6"/>,
      color: "green",
      fields: ["service_menu", "preferred_ctas", "pricing_constraints_strict", "pricing_rules"]
    },
    {
      key: 'area',
      title: "Service Area",
      description: "Where you operate.",
      icon: <MapPin className="h-6 w-6"/>,
      color: "orange",
      fields: ["service_area"]
    },
    {
      key: 'differentiation',
      title: "Differentiation & Objections",
      description: "What makes you unique and how you build trust.",
      icon: <Star className="h-6 w-6"/>,
      color: "red",
      fields: ["usp_1", "usp_2", "usp_3", "objection_responses", "team_framing"]
    },
    {
      key: 'qualification',
      title: "Lead Qualification",
      description: "How to score and segment leads.",
      icon: <BarChart3 className="h-6 w-6"/>,
      color: "yellow",
      fields: ["lead_scoring", "seasonal_messaging"]
    },
    {
      key: 'compliance',
      title: "Compliance & Legal",
      description: "Guardrails, disclaimers, and legal constraints.",
      icon: <Landmark className="h-6 w-6"/>,
      color: "gray",
      fields: ["tone_guardrails", "mold_florida_law", "compliance_disclaimer"]
    },
    {
      key: 'protocols',
      title: "Success Metrics & Protocols",
      description: "AI operational protocols for success.",
      icon: <ListChecks className="h-6 w-6"/>,
      color: "teal",
      fields: ["conversation_objectives", "lead_capture_protocol", "visual_aid_triggers", "escalation_triggers"]
    }
];

const fieldLabels = {
    mission_statement: "Mission Statement",
    primary_audience: "Primary Audience Segments",
    founding_story: "Founding Story",
    voice_summary: "Voice Summary",
    voice_details: "Voice Details & Conversation Flow",
    visual_anchoring: "Visual Anchoring",
    service_menu: "Service Menu",
    preferred_ctas: "Preferred Calls-to-Action",
    pricing_constraints_strict: "Strict Pricing Constraints (for AI)",
    pricing_rules: "General Pricing Rules",
    service_area: "Service Area",
    usp_1: "USP 1: Mechanical Hygiene Specialists",
    usp_2: "USP 2: Health-First, Evidence-Based",
    usp_3: "USP 3: Transparent, Veteran-Owned",
    objection_responses: "Common Objection Responses",
    team_framing: "How to Frame Our Team",
    lead_scoring: "Lead Scoring Logic",
    seasonal_messaging: "Seasonal Messaging Hooks",
    tone_guardrails: "Tone Guardrails (What to Avoid)",
    mold_florida_law: "Florida Mold Law (Statute 468.853)",
    compliance_disclaimer: "Medical Advice Disclaimer",
    conversation_objectives: "Conversation Objectives",
    lead_capture_protocol: "Lead Capture Protocol (Strict Format)",
    visual_aid_triggers: "Visual Aid Triggers",
    escalation_triggers: "Escalation Triggers (To Human)",
};

const SectionCard = ({ title, description, icon, color, fields, data }) => {
    const gradientClasses = {
        blue: 'from-blue-500 to-blue-600', purple: 'from-purple-500 to-purple-600', green: 'from-green-500 to-green-600',
        orange: 'from-orange-500 to-orange-600', red: 'from-red-500 to-red-600', yellow: 'from-yellow-500 to-yellow-600',
        gray: 'from-gray-500 to-gray-600', teal: 'from-teal-500 to-teal-600',
    };

    const isMonospace = (fieldKey) => [
        "primary_audience", "voice_summary", "service_menu", "preferred_ctas", 
        "pricing_constraints_strict", "usp_1", "usp_2", "usp_3", 
        "objection_responses", "lead_scoring", "seasonal_messaging",
        "conversation_objectives", "lead_capture_protocol", "visual_aid_triggers", "escalation_triggers"
    ].includes(fieldKey);

    return (
        <Card className="bg-gray-800/50 border-gray-700/50 text-white overflow-hidden">
            <CardHeader className={cn("p-5 flex flex-row items-center gap-4 bg-gradient-to-r", gradientClasses[color])}>
                <div className="flex-shrink-0">{icon}</div>
                <div className="flex-grow">
                    <CardTitle className="text-lg font-bold">{title}</CardTitle>
                    <CardDescription className="text-white/80 text-sm mt-1">{description}</CardDescription>
                </div>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
                {fields.map(fieldKey => (
                    <div key={fieldKey}>
                        <h3 className="font-semibold text-gray-300 mb-2">{fieldLabels[fieldKey] || fieldKey}</h3>
                        <div className={cn(
                            "text-gray-400 text-sm whitespace-pre-wrap p-4 bg-black/30 rounded-md border border-gray-700",
                            isMonospace(fieldKey) && "font-mono text-xs"
                        )}>
                            {data[fieldKey] || <span className="text-gray-500 italic">Not set</span>}
                        </div>
                    </div>
                ))}
            </CardContent>
        </Card>
    );
};

const BrandReview = () => {
    const [brandProfile, setBrandProfile] = useState({});
    const [isLoading, setIsLoading] = useState(true);
    const { toast } = useToast();

    const fetchBrandProfile = useCallback(async () => {
        setIsLoading(true);
        const { data, error } = await supabase.from('brand_profile').select('key, value');
        if (error) {
            toast({
                title: "Error fetching brand profile",
                description: error.message,
                variant: "destructive",
            });
        } else {
            const profile = data.reduce((acc, item) => {
                acc[item.key] = item.value;
                return acc;
            }, {});
            setBrandProfile(profile);
        }
        setIsLoading(false);
    }, [toast]);

    useEffect(() => {
        fetchBrandProfile();
    }, [fetchBrandProfile]);

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-full bg-gray-900 text-white">
                <Loader2 className="h-10 w-10 animate-spin text-blue-400" />
            </div>
        );
    }

    return (
        <div className="h-full flex flex-col bg-gray-900 text-white">
            <header className="sticky top-0 z-20 p-4 md:p-6 border-b border-gray-700/50 bg-gray-900/70 backdrop-blur-lg">
                <div className="max-w-7xl mx-auto flex justify-between items-center">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-blue-400 to-purple-400 text-transparent bg-clip-text">
                            Brand Brain Review
                        </h1>
                        <p className="text-gray-400 mt-1">Systematic review of the complete KLAIRE SYSTEM PROMPT v1.1.</p>
                    </div>
                    <Button asChild>
                        <Link to="/crm/settings">Edit Brand Brain</Link>
                    </Button>
                </div>
            </header>
            <main className="flex-1 overflow-y-auto p-4 md:p-8">
                <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {sections.map(section => (
                        <SectionCard
                            key={section.key}
                            {...section}
                            data={brandProfile}
                        />
                    ))}
                </div>
            </main>
        </div>
    );
};

export default BrandReview;