
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Building2, Phone, Mail, MessageSquare, Bell, Palette, 
  MonitorSmartphone, Shield, Users, Database, FileText, 
  BarChart3, Settings as SettingsIcon, ClipboardList
} from 'lucide-react';

const SettingsSection = ({ title, items }) => (
  <div className="mb-8">
    <h2 className="text-lg font-semibold mb-4 text-slate-800 flex items-center gap-2">
      {title}
    </h2>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {items.map((item, idx) => (
        <Card 
          key={idx} 
          className="cursor-pointer hover:shadow-md transition-all hover:border-indigo-200 group"
          onClick={() => item.onClick()}
        >
          <CardHeader className="flex flex-row items-center gap-4 pb-2">
            <div className="bg-slate-100 p-2 rounded-lg group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
              {item.icon}
            </div>
            <div>
              <CardTitle className="text-base">{item.title}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <CardDescription className="text-xs">
              {item.description}
            </CardDescription>
          </CardContent>
        </Card>
      ))}
    </div>
  </div>
);

export default function Settings() {
  const navigate = useNavigate();

  const businessItems = [
    {
      title: 'Business Profile',
      description: 'Manage company details, address, and operating hours.',
      icon: <Building2 className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/business')
    },
    {
      title: 'Branding',
      description: 'Upload logo, set brand colors, and configure portal appearance.',
      icon: <Palette className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/branding') 
    },
    {
      title: 'Service Catalog',
      description: 'Configure services, prices, and standard durations.',
      icon: <SettingsIcon className="h-5 w-5" />,
      onClick: () => navigate('/price-book') 
    }
  ];

  const communicationItems = [
    {
      title: 'Email Settings',
      description: 'Connect email provider and configure sending domains.',
      icon: <Mail className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/email')
    },
    {
      title: 'SMS Templates',
      description: 'Manage automated text message templates and triggers.',
      icon: <MessageSquare className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/sms-templates')
    },
    {
      title: 'Notifications',
      description: 'Configure system alerts and staff notification preferences.',
      icon: <Bell className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/notifications')
    }
  ];

  const systemItems = [
    {
      title: 'Call Tracking',
      description: 'Manage Twilio numbers and call routing rules.',
      icon: <Phone className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/call-tracking')
    },
    {
      title: 'Build Console',
      description: 'Manage feature flags and system deployment status.',
      icon: <MonitorSmartphone className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/build-console')
    },
    {
      title: 'Audit Log',
      description: 'View system-wide activity logs and tracking history.',
      icon: <ClipboardList className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/audit-logs')
    },
    {
      title: 'Rollback Analytics',
      description: 'Monitor system stability and automated recovery performance.',
      icon: <BarChart3 className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/rollback-analytics')
    },
    {
      title: 'API Keys',
      description: 'Manage external integrations and access tokens.',
      icon: <Database className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/api-keys')
    }
  ];

  const adminItems = [
    {
      title: 'User Management',
      description: 'Invite team members and manage role-based access.',
      icon: <Users className="h-5 w-5" />,
      onClick: () => navigate('/crm/admin/users')
    },
    {
      title: 'Security',
      description: 'Configure password policies and 2FA settings.',
      icon: <Shield className="h-5 w-5" />,
      onClick: () => navigate('/crm/settings/security')
    }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Settings</h1>
        <p className="text-slate-500 mt-2">Manage your organization preferences and system configurations.</p>
      </div>

      <ScrollArea className="h-[calc(100vh-200px)] pr-4">
        <SettingsSection title="Business & Branding" items={businessItems} />
        <SettingsSection title="Communication" items={communicationItems} />
        <SettingsSection title="System Configuration" items={systemItems} />
        <SettingsSection title="Administration" items={adminItems} />
      </ScrollArea>
    </div>
  );
}
