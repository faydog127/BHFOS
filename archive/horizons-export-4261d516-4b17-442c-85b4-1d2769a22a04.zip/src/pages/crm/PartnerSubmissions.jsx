import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, RefreshCw, Search, Eye, ThumbsUp, ThumbsDown } from 'lucide-react';
import { format } from 'date-fns';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const STATUS_COLORS = {
  sent: 'bg-green-100 text-green-800 border-green-200',
  pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  failed: 'bg-red-100 text-red-800 border-red-200',
  scheduled: 'bg-blue-100 text-blue-800 border-blue-200',
  approved: 'bg-green-100 text-green-800 border-green-200',
  denied: 'bg-red-100 text-red-800 border-red-200',
  new: 'bg-blue-100 text-blue-800 border-blue-200',
};

const PartnerSubmissions = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [submissions, setSubmissions] = useState([]);
  const [selectedSubmission, setSelectedSubmission] = useState(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [actioningId, setActioningId] = useState(null);

  const [roleFilter, setRoleFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState('90');
  const [statusFilter, setStatusFilter] = useState('new');

  const fetchSubmissions = useCallback(async () => {
    setLoading(true);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(dateRange));

    let query = supabase
      .from('partner_registrations')
      .select('*')
      .gte('created_at', startDate.toISOString())
      .order('created_at', { ascending: false });

    if (statusFilter !== 'ALL') {
      if (statusFilter === 'new') {
        query = query.is('status', null);
      } else {
        query = query.eq('status', statusFilter);
      }
    }

    const { data, error } = await query;
    if (error) {
      toast({ variant: 'destructive', title: 'Error fetching data', description: error.message });
    } else {
      setSubmissions(data);
    }
    setLoading(false);
  }, [dateRange, statusFilter, toast]);

  useEffect(() => {
    fetchSubmissions();
  }, [fetchSubmissions]);

  const handleApprove = async (sub) => {
    setActioningId(sub.id);
    try {
      // 1. Create a lead from the submission data.
      const leadPayload = {
        first_name: sub.contact_name,
        company: sub.organization_name,
        email: sub.email,
        phone: sub.mobile_phone,
        persona: sub.partner_type,
        status: 'New',
        pqi: 50,
        utm_source: 'partner_registration',
        source_kind: 'Partner',
        source_detail: 'CRM Approval',
        is_partner: true,
      };

      const { data: leadData, error: leadError } = await supabase.from('leads').insert(leadPayload).select().single();
      if (leadError) throw new Error(`Lead creation failed: ${leadError.message}`);
      
      const newLead = leadData;

      // 2. Create the marketing action to be sent IMMEDIATELY.
      const marketingActionPayload = {
          lead_id: newLead.id,
          playbook_key: 'partner_welcome',
          type: 'email',
          channel: 'api',
          status: 'sending', // 'sending' will trigger immediate processing.
          target_details: { name: newLead.first_name, email: newLead.email },
          scheduled_at: new Date().toISOString(),
          // Bypassing AI generation by providing content directly
          subject_line: `Welcome to The Vent Guys Partner Program, ${newLead.first_name}!`,
          body: `Hi ${newLead.first_name},<br/><br/>Welcome to the club! We're thrilled to have you as a Vent Guys partner. We've received your information and a member of our team will be in touch shortly with next steps, including your unique referral code and marketing materials.<br/><br/>We're excited to build a great partnership.<br/><br/>Best,<br/>The Vent Guys Team`,
          content_preview: `Hi ${newLead.first_name}, Welcome to the club! We're thrilled to have you...`,
          ai_generated_at: new Date().toISOString(), // Mark as generated now
      };

      const { error: actionError } = await supabase.from('marketing_actions').insert(marketingActionPayload);
      if (actionError) throw new Error(`Marketing action creation failed: ${actionError.message}`);

      // 3. Update the submission status to 'approved'.
      const { error: statusError } = await supabase.from('partner_registrations').update({ status: 'approved' }).eq('id', sub.id);
      if (statusError) throw new Error(`Status update failed: ${statusError.message}`);

      toast({ title: 'Partner Approved & Welcome Email Sent!', description: `${sub.contact_name} has been added as a lead and the welcome email is on its way.` });
      fetchSubmissions();
    } catch (err) {
      console.error('Approval Error:', err);
      toast({ variant: 'destructive', title: 'Approval Failed', description: err.message });
    } finally {
      setActioningId(null);
    }
  };

  const handleDeny = async (subId) => {
    setActioningId(subId);
    try {
      const { error } = await supabase.from('partner_registrations').update({ status: 'denied' }).eq('id', subId);
      if (error) throw error;
      toast({ title: 'Partner Denied', description: 'The submission has been marked as denied.', variant: 'destructive' });
      fetchSubmissions();
    } catch (err) {
      console.error(err);
      toast({ variant: 'destructive', title: 'Action Failed', description: err.message });
    } finally {
      setActioningId(null);
    }
  };

  const filteredSubmissions = useMemo(() => {
    return submissions.filter(sub => {
      const partnerType = sub.partner_type || '';
      const title = sub.title || '';
      const matchesRole = roleFilter === 'ALL' ||
        partnerType.toLowerCase() === roleFilter.toLowerCase() ||
        title.toLowerCase().includes(roleFilter.toLowerCase().replace('_', ' '));

      const searchString = `${sub.contact_name} ${sub.organization_name} ${sub.email}`.toLowerCase();
      const matchesSearch = searchString.includes(searchTerm.toLowerCase());
      return matchesRole && matchesSearch;
    });
  }, [submissions, roleFilter, searchTerm]);

  const openDetails = (sub) => {
    setSelectedSubmission(sub);
    setIsDetailOpen(true);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      <Helmet>
        <title>Partner Submissions | CRM</title>
      </Helmet>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Partner Submissions</h1>
          <p className="text-gray-500">Manage incoming partnership requests and lead capture.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={fetchSubmissions} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4 flex flex-col md:flex-row gap-4 items-center">
          <div className="w-full md:w-1/3 space-y-1">
            <label className="text-xs font-medium text-gray-500">Search</label>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input placeholder="Name, Company, Email..." className="pl-8" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
          </div>
          <div className="w-full md:w-1/4 space-y-1">
            <label className="text-xs font-medium text-gray-500">Filter by Status</label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="denied">Denied</SelectItem>
                <SelectItem value="ALL">All Statuses</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="w-full md:w-1/4 space-y-1">
            <label className="text-xs font-medium text-gray-500">Filter by Role</label>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger><SelectValue placeholder="All Roles" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Roles</SelectItem>
                <SelectItem value="property_manager">Property Manager</SelectItem>
                <SelectItem value="realtor">Realtor/Broker</SelectItem>
                <SelectItem value="investor_landlord">Investor/Landlord</SelectItem>
                <SelectItem value="hoa">HOA Board</SelectItem>
                <SelectItem value="b2b">B2B / Contractor</SelectItem>
                <SelectItem value="government">Government</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="w-full md:w-1/4 space-y-1">
            <label className="text-xs font-medium text-gray-500">Date Range</label>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 Days</SelectItem>
                <SelectItem value="30">Last 30 Days</SelectItem>
                <SelectItem value="90">Last 90 Days</SelectItem>
                <SelectItem value="365">Last Year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="bg-white rounded-lg border shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead>Contact</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Units</TableHead>
              <TableHead>Submitted On</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={6} className="h-32 text-center"><Loader2 className="h-8 w-8 animate-spin mx-auto text-gray-400" /></TableCell></TableRow>
            ) : filteredSubmissions.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="h-32 text-center text-gray-500">No submissions found for the selected filters.</TableCell></TableRow>
            ) : (
              filteredSubmissions.map((sub) => (
                <TableRow key={sub.id} className="hover:bg-gray-50/50">
                  <TableCell>
                    <div className="font-medium text-gray-900">{sub.contact_name}</div>
                    <div className="text-sm text-gray-500">{sub.organization_name}</div>
                    <div className="text-xs text-gray-400">{sub.email}</div>
                  </TableCell>
                  <TableCell><Badge variant="outline" className="bg-slate-50">{sub.partner_type?.replace(/_/g, ' ') || sub.title}</Badge></TableCell>
                  <TableCell>{sub.num_units || sub.doors_managed || sub.num_facilities || '-'}</TableCell>
                  <TableCell>
                    <div className="text-sm">{format(new Date(sub.created_at), 'MMM d, yyyy')}</div>
                    <div className="text-xs text-gray-400">{format(new Date(sub.created_at), 'h:mm a')}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={STATUS_COLORS[sub.status || 'new'] + ' capitalize'}>{sub.status || 'New'}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2 items-center">
                      {(!sub.status || sub.status === 'new') && (
                        <>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="outline" size="sm" className="h-8 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700" disabled={actioningId === sub.id}>
                                <ThumbsDown className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader><AlertDialogTitle>Deny Partner Request?</AlertDialogTitle><AlertDialogDescription>This will mark the submission as denied. This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeny(sub.id)} className="bg-red-600 hover:bg-red-700">Confirm Denial</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>

                          <Button size="sm" className="h-8 bg-green-600 hover:bg-green-700" onClick={() => handleApprove(sub)} disabled={actioningId === sub.id}>
                            {actioningId === sub.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <ThumbsUp className="h-4 w-4 mr-2" />} Approve
                          </Button>
                        </>
                      )}
                      {(sub.status === 'approved' || sub.status === 'denied') && (
                        <span className="text-xs italic text-gray-400">Actioned</span>
                      )}
                      <Button variant="ghost" size="icon" onClick={() => openDetails(sub)} title="View Full Details"><Eye className="h-4 w-4 text-gray-500 hover:text-gray-900" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {isDetailOpen && selectedSubmission && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={() => setIsDetailOpen(false)}></div>
          <div className="relative w-full max-w-md bg-white h-full shadow-2xl overflow-y-auto p-6 animate-in slide-in-from-right duration-300">
             <div className="flex justify-between items-start mb-6">
                <div>
                    <h2 className="text-xl font-bold text-gray-900">Submission Details</h2>
                    <p className="text-sm text-gray-500">ID: {selectedSubmission.id.slice(0,8)}</p>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setIsDetailOpen(false)}>Close</Button>
             </div>
             <div className="space-y-6">
                <section>
                    <h3 className="font-semibold text-gray-900 border-b pb-2 mb-3">Contact Info</h3>
                    <DetailRow label="Name" value={selectedSubmission.contact_name} />
                    <DetailRow label="Email" value={selectedSubmission.email} />
                    <DetailRow label="Phone" value={selectedSubmission.mobile_phone} />
                    <DetailRow label="Organization" value={selectedSubmission.organization_name} />
                    <DetailRow label="Role/Title" value={selectedSubmission.title} />
                    <DetailRow label="Address" value={selectedSubmission.address} />
                </section>
                <section>
                    <h3 className="font-semibold text-gray-900 border-b pb-2 mb-3">Portfolio Data</h3>
                    <DetailRow label="Partner Type" value={selectedSubmission.partner_type} />
                    <DetailRow label="Units/Doors" value={selectedSubmission.num_units || selectedSubmission.doors_managed || selectedSubmission.num_facilities} />
                    <DetailRow label="Monthly Turnovers" value={selectedSubmission.monthly_turnovers} />
                </section>
                <section>
                    <h3 className="font-semibold text-gray-900 border-b pb-2 mb-3">Key Insights</h3>
                    <div className="mb-3">
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Biggest Headache</label>
                        <p className="text-sm text-gray-900 mt-1 bg-red-50 p-2 rounded border border-red-100">{selectedSubmission.biggest_headache || "Not provided"}</p>
                    </div>
                </section>
                <section>
                    <h3 className="font-semibold text-gray-900 border-b pb-2 mb-3">System Status</h3>
                    <DetailRow label="Submission Date" value={new Date(selectedSubmission.created_at).toLocaleString()} />
                    <DetailRow label="Status" value={selectedSubmission.status || 'new'} />
                </section>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

const DetailRow = ({ label, value }) => {
    if (!value) return null;
    return (
        <div className="mb-2">
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{label}</label>
            <p className="text-sm text-gray-900 capitalize">{value.toString().replace(/_/g, ' ')}</p>
        </div>
    );
};

export default PartnerSubmissions;