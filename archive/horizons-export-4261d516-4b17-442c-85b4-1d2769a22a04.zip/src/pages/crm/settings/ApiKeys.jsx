import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Eye, EyeOff, Save, Loader2, Lock, Copy } from 'lucide-react';

const ApiKeyInput = ({ label, value, onChange }) => {
    const [visible, setVisible] = useState(false);
    return (
        <div className="space-y-2">
            <Label>{label}</Label>
            <div className="relative">
                <Input 
                    type={visible ? "text" : "password"} 
                    value={value} 
                    onChange={onChange} 
                    placeholder="sk_..."
                    className="pr-10 font-mono"
                />
                <button 
                    type="button"
                    className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600"
                    onClick={() => setVisible(!visible)}
                >
                    {visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
            </div>
        </div>
    );
};

const ApiKeys = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [keys, setKeys] = useState({
      TWILIO_API_KEY: '',
      SENDGRID_API_KEY: '',
      GOOGLE_ADS_KEY: '',
      STRIPE_SECRET_KEY: ''
  });

  useEffect(() => {
    fetchKeys();
  }, []);

  const fetchKeys = async () => {
    setLoading(true);
    // Fetch from global_config
    const keyNames = Object.keys(keys);
    const { data, error } = await supabase
        .from('global_config')
        .select('*')
        .in('key', keyNames);

    if (error) {
        toast({ variant: 'destructive', title: 'Error', description: error.message });
    } else if (data) {
        const newKeys = { ...keys };
        data.forEach(row => {
            if (newKeys.hasOwnProperty(row.key)) {
                newKeys[row.key] = row.value;
            }
        });
        setKeys(newKeys);
    }
    setLoading(false);
  };

  const handleSave = async () => {
      setSaving(true);
      try {
          const updates = Object.entries(keys).map(([key, value]) => ({ key, value }));
          
          const { error } = await supabase.from('global_config').upsert(updates, { onConflict: 'key' });
          
          if (error) throw error;
          
          toast({ title: 'Securely Saved', description: 'API keys have been updated.' });
      } catch (err) {
          toast({ variant: 'destructive', title: 'Error', description: err.message });
      } finally {
          setSaving(false);
      }
  };

  const handleChange = (key, val) => {
      setKeys(prev => ({ ...prev, [key]: val }));
  };

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">API Integrations</h1>
                <p className="text-gray-500">Manage secrets for third-party services.</p>
            </div>
        </div>

        <Card className="border-l-4 border-l-amber-400">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Lock className="h-5 w-5 text-amber-500" /> Secure Storage
                </CardTitle>
                <CardDescription>
                    These keys are encrypted at rest. Only authorized admins can view or rotate them.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                {loading ? <Loader2 className="animate-spin mx-auto" /> : (
                    <>
                        <ApiKeyInput 
                            label="Twilio API Key" 
                            value={keys.TWILIO_API_KEY} 
                            onChange={e => handleChange('TWILIO_API_KEY', e.target.value)} 
                        />
                        <ApiKeyInput 
                            label="SendGrid API Key" 
                            value={keys.SENDGRID_API_KEY} 
                            onChange={e => handleChange('SENDGRID_API_KEY', e.target.value)} 
                        />
                        <ApiKeyInput 
                            label="Google Ads API Key" 
                            value={keys.GOOGLE_ADS_KEY} 
                            onChange={e => handleChange('GOOGLE_ADS_KEY', e.target.value)} 
                        />
                        <ApiKeyInput 
                            label="Stripe Secret Key" 
                            value={keys.STRIPE_SECRET_KEY} 
                            onChange={e => handleChange('STRIPE_SECRET_KEY', e.target.value)} 
                        />
                    </>
                )}
                
                <div className="flex justify-end pt-4">
                    <Button onClick={handleSave} disabled={saving} className="bg-green-600 hover:bg-green-700">
                        {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                        Update Keys
                    </Button>
                </div>
            </CardContent>
        </Card>
    </div>
  );
};

export default ApiKeys;