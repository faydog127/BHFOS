import React, { createContext, useContext } from 'react';
import { useSystemMode } from '@/hooks/useSystemMode';
import { useSupabaseAuth } from '@/contexts/SupabaseAuthContext';

const TrainingModeContext = createContext();

export const useTrainingMode = () => {
  const context = useContext(TrainingModeContext);
  if (!context) {
    throw new Error('useTrainingMode must be used within a TrainingModeProvider');
  }
  return context;
};

// Wraps the useSystemMode hook to provide global state
export const TrainingModeProvider = ({ children }) => {
  const { user } = useSupabaseAuth();
  const { mode, setMode, loading, refreshMode } = useSystemMode(user);
  
  const isTrainingMode = mode === 'training';
  
  const toggleTrainingMode = () => {
      setMode(isTrainingMode ? 'live' : 'training');
  };

  return (
    <TrainingModeContext.Provider value={{ 
        isTrainingMode, 
        mode, 
        setMode, 
        toggleTrainingMode, 
        loading,
        refreshMode 
    }}>
      {children}
    </TrainingModeContext.Provider>
  );
};