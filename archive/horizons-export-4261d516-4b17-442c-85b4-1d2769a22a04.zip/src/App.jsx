
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import AdminRoute from '@/components/AdminRoute';
import CrmLayout from '@/components/CrmLayout';
import AuthLayout from '@/components/AuthLayout';
import NotFound from '@/pages/NotFound';

// Public Pages
import Home from '@/pages/Home';
import Login from '@/pages/Login';
import SignUp from '@/pages/SignUp';
import About from '@/pages/About';
import Services from '@/pages/Services';
import Contact from '@/pages/Contact';
import Gallery from '@/pages/Gallery';
import Booking from '@/pages/Booking';
import FaqPage from '@/pages/Faq';
import Blog from '@/pages/Blog';
import FreeAirCheck from '@/pages/FreeAirCheck';
import PartnersLanding from '@/pages/PartnersLanding';
import PrivacyPolicy from '@/pages/PrivacyPolicy';
import TermsOfService from '@/pages/TermsOfService';
import VendorPacket from '@/pages/VendorPacket';
import ForContractors from '@/pages/ForContractors';

// Partner Specific Pages
import RealtorPartner from '@/pages/partners/RealtorPartner';
import PropertyManagerPartner from '@/pages/partners/PropertyManagerPartner';
import HoaPartner from '@/pages/partners/HoaPartner';
import B2bPartner from '@/pages/partners/B2bPartner';
import GovernmentPartner from '@/pages/partners/GovernmentPartner';
import PartnerWelcome from '@/pages/partners/PartnerWelcome';

// CRM Pages
import CrmHome from '@/pages/crm/CrmHome';
import Pipeline from '@/pages/crm/Pipeline';
import Leads from '@/pages/crm/Leads';
import LeadsList from '@/pages/crm/LeadsList';
import LeadQualification from '@/pages/crm/leads/LeadQualification';
import Estimates from '@/pages/crm/Estimates';
import Jobs from '@/pages/crm/Jobs';
import JobCompletion from '@/pages/crm/jobs/JobCompletion';
import ProposalList from '@/pages/crm/proposals/ProposalList';
import ReferralDashboard from '@/pages/crm/ReferralDashboard';
import Partners from '@/pages/crm/Partners';
import Inbox from '@/pages/crm/Inbox';
import SmsConversations from '@/pages/crm/sms/SmsConversations';
import CallLog from '@/pages/crm/CallLog';
import CallScripts from '@/pages/crm/CallScripts';
import Schedule from '@/pages/crm/Schedule';

// CRM Settings Pages
import Settings from '@/pages/crm/Settings';
import BuildConsole from '@/components/crm/settings/BuildConsole';
import BusinessSettings from '@/pages/crm/settings/BusinessSettings';
import ServiceConfigurations from '@/pages/crm/settings/ServiceConfigurations';
import ApiKeys from '@/pages/crm/settings/ApiKeys';
import EmailTemplates from '@/pages/crm/settings/EmailTemplates';
import SmsTemplates from '@/pages/crm/settings/SmsTemplates';
import BrandingSettings from '@/pages/crm/settings/BrandingSettings';
import NotificationSettings from '@/pages/crm/settings/NotificationSettings';
import KanbanSettings from '@/pages/crm/settings/KanbanSettings';
import CallTrackingSettings from '@/pages/crm/settings/CallTrackingSettings';
import AuditLogListPage from '@/components/crm/settings/AuditLogListPage';
import RollbackFlowManager from '@/components/crm/settings/RollbackFlowManager';
import FeedbackImpactDashboard from '@/components/crm/settings/FeedbackImpactDashboard';

function App() {
  return (
    <BrowserRouter>
      <Helmet>
        <title>Hostinger Horizons</title>
        <meta name="description" content="Hostinger Horizons - A comprehensive web application built with React, Vite, TailwindCSS, and Supabase." />
      </Helmet>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<AuthLayout><Login /></AuthLayout>} />
        <Route path="/signup" element={<AuthLayout><SignUp /></AuthLayout>} />
        
        {/* Marketing/Info Pages */}
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/booking" element={<Booking />} />
        <Route path="/faq" element={<FaqPage />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/free-air-check" element={<FreeAirCheck />} />
        <Route path="/privacy" element={<PrivacyPolicy />} />
        <Route path="/terms-of-service" element={<TermsOfService />} />
        
        {/* Partner Pages */}
        <Route path="/partners" element={<PartnersLanding />} />
        <Route path="/partners/realtor" element={<RealtorPartner />} />
        <Route path="/partners/property-manager" element={<PropertyManagerPartner />} />
        <Route path="/partners/hoa" element={<HoaPartner />} />
        <Route path="/partners/b2b" element={<B2bPartner />} />
        <Route path="/partners/government" element={<GovernmentPartner />} />
        <Route path="/partners/welcome" element={<PartnerWelcome />} />
        <Route path="/vendor-packet" element={<VendorPacket />} />
        <Route path="/for-contractors" element={<ForContractors />} />

        {/* CRM Routes (Admin Protected) */}
        <Route path="/crm" element={<AdminRoute><CrmLayout /></AdminRoute>}>
          <Route index element={<CrmHome />} />
          <Route path="dashboard" element={<CrmHome />} />
          
          {/* Main Navigation Items */}
          <Route path="pipeline" element={<Pipeline />} />
          <Route path="leads" element={<Leads />} />
          <Route path="leads-list" element={<LeadsList />} />
          <Route path="leads/qualification" element={<LeadQualification />} />
          <Route path="estimates" element={<Estimates />} />
          <Route path="jobs" element={<Jobs />} />
          <Route path="job-completion" element={<JobCompletion />} />
          <Route path="job-completion/:jobId" element={<JobCompletion />} />
          <Route path="proposals" element={<ProposalList />} />
          <Route path="referrals" element={<ReferralDashboard />} />
          <Route path="partners" element={<Partners />} />
          <Route path="inbox" element={<Inbox />} />
          <Route path="sms" element={<SmsConversations />} />
          <Route path="calls" element={<CallLog />} />
          <Route path="scripts" element={<CallScripts />} />
          <Route path="schedule" element={<Schedule />} />

          {/* Settings Routes */}
          <Route path="settings" element={<Settings />} />
          <Route path="settings/business" element={<BusinessSettings />} />
          <Route path="settings/service-configurations" element={<ServiceConfigurations />} />
          <Route path="settings/api-keys" element={<ApiKeys />} />
          <Route path="settings/email-templates" element={<EmailTemplates />} />
          <Route path="settings/sms-templates" element={<SmsTemplates />} />
          <Route path="settings/branding" element={<BrandingSettings />} />
          <Route path="settings/notifications" element={<NotificationSettings />} />
          <Route path="settings/kanban" element={<KanbanSettings />} />
          <Route path="settings/call-tracking" element={<CallTrackingSettings />} />
          <Route path="settings/audit-log" element={<AuditLogListPage />} />
          <Route path="settings/rollback-manager" element={<RollbackFlowManager />} />
          <Route path="settings/feedback-impact" element={<FeedbackImpactDashboard />} />
          <Route path="settings/build-console" element={<BuildConsole />} />
          
          <Route path="*" element={<NotFound />} />
        </Route>

        {/* Catch-all for undefined routes */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
