import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabaseClient';
import { 
  AlertTriangle, Activity, History, RotateCcw, Play, 
  Server, FileCode, Lock, Terminal, CheckCircle2, 
  XCircle, Clock, Keyboard, ShieldAlert, Edit3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { formatDistanceToNow } from 'date-fns';

const SystemDoctorConsole = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // --- STATE ---
  const [selectedView, setSelectedView] = useState('active'); 
  const [selectedIssue, setSelectedIssue] = useState(null); 
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  
  // Dialogs & Modes
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [manualMode, setManualMode] = useState(false);
  const [manualSql, setManualSql] = useState("");

  // Global Settings (In a real app, fetch from system_settings)
  const [safeMode, setSafeMode] = useState(true);

  // --- SHORTCUTS ---
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === 'd' && selectedIssue) { e.preventDefault(); runDiagnostics(); }
        if (e.key === 'e' && selectedIssue?.fix_plan_jsonb) { e.preventDefault(); setShowConfirmDialog(true); }
        if (e.key === 'r') { e.preventDefault(); queryClient.invalidateQueries(); }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedIssue]);

  // --- QUERIES ---
  const { data: issues } = useQuery({
    queryKey: ['system-issues'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('system_audit_log')
        .select('*')
        .eq('execution_status', 'PENDING_REVIEW') 
        .order('timestamp_utc', { ascending: false });
      if (error) throw error;
      return data;
    },
    refetchInterval: 5000 // Polling for freshness
  });

  const { data: history } = useQuery({
    queryKey: ['system-history'],
    queryFn: async () => {
       const { data, error } = await supabase
        .from('system_audit_log')
        .select('*')
        .neq('execution_status', 'PENDING_REVIEW')
        .order('timestamp_utc', { ascending: false })
        .limit(50);
       if (error) throw error;
       return data;
    }
  });

  // Step Logs (Real-time execution tracking)
  const { data: stepLogs } = useQuery({
    queryKey: ['step-logs', selectedIssue?.id],
    queryFn: async () => {
        if (!selectedIssue) return [];
        const { data } = await supabase
            .from('remediation_step_log')
            .select('*')
            .eq('issue_id', selectedIssue.id)
            .order('step_order', { ascending: true });
        return data || [];
    },
    enabled: !!selectedIssue && selectedIssue.execution_status === 'IN_PROGRESS',
    refetchInterval: 1000 // Fast polling during execution
  });

  // --- ACTIONS ---

  // 1. THE BRAIN (AI Diagnosis)
  const runDiagnostics = async () => {
      if (!selectedIssue) return;
      setIsDiagnosing(true);
      try {
          const { data, error } = await supabase.functions.invoke('system-doctor', {
              body: { issue_id: selectedIssue.id }
          });
          if (error) throw new Error(error.message);
          
          queryClient.invalidateQueries(['system-issues']);
          
          // Optimistic update
          const updated = { ...selectedIssue, ...data, fix_plan_jsonb: data.fix_plan };
          setSelectedIssue(updated);
          toast({ title: "Diagnosis Complete", description: "AI has generated a remediation plan." });
      } catch (err) {
          toast({ variant: "destructive", title: "Diagnosis Failed", description: err.message });
          // Suggest Manual Mode on failure
          setManualMode(true);
      } finally {
          setIsDiagnosing(false);
      }
  };

  // 2. THE HANDS (Execute RPC)
  const applyFixMutation = useMutation({
      mutationFn: async () => {
          // If Manual Mode, we must save the plan first (Logic omitted for brevity, assumes plan exists)
          const { data, error } = await supabase.rpc('execute_remediation_plan', {
              target_issue_id: selectedIssue.id
          });
          if (error) throw error;
          return data;
      },
      onSuccess: (data) => {
          if (data.status === 'SUCCESS') {
            toast({ title: "Success", description: `Executed ${data.steps_executed} steps.` });
            setSelectedIssue(null);
          } else {
            toast({ variant: "destructive", title: "Execution Failed", description: data.error });
          }
          setShowConfirmDialog(false);
          setConfirmText("");
          queryClient.invalidateQueries();
      },
      onError: (err) => {
          toast({ variant: "destructive", title: "RPC Error", description: err.message });
          setShowConfirmDialog(false);
      }
  });

  // 3. MANUAL OVERRIDE (Save Manual Plan)
  const saveManualPlan = async () => {
      try {
          // Basic validation
          if (!manualSql.trim()) throw new Error("SQL cannot be empty");
          
          const manualPlan = {
              steps: [{
                  order: 1,
                  description: "Manual Override Fix",
                  type: "SQL",
                  sql: manualSql,
                  is_destructive: manualSql.match(/(DROP|DELETE|TRUNCATE)/i) ? true : false,
                  inverse_sql: "-- Manual fix, no auto-rollback"
              }]
          };

          const { error } = await supabase
              .from('system_audit_log')
              .update({ fix_plan_jsonb: manualPlan, root_cause_type: 'MANUAL_OVERRIDE' })
              .eq('id', selectedIssue.id);

          if (error) throw error;

          const updated = { ...selectedIssue, fix_plan_jsonb: manualPlan };
          setSelectedIssue(updated);
          setManualMode(false);
          toast({ title: "Plan Saved", description: "Manual plan ready for execution." });
      } catch (err) {
          toast({ variant: "destructive", title: "Save Failed", description: err.message });
      }
  };

  // --- COMPUTED SAFETY CHECKS ---
  const hasDestructive = selectedIssue?.fix_plan_jsonb?.steps?.some(s => s.is_destructive);
  const isReadyToExecute = selectedIssue?.fix_plan_jsonb?.steps?.length > 0;
  const isBlockedBySafeMode = safeMode && hasDestructive;

  // --- RENDER ---
  return (
    <div className="flex flex-col h-[calc(100vh-2rem)] max-w-[1600px] mx-auto border rounded-xl overflow-hidden bg-white shadow-sm font-sans">
      
      {/* HEADER */}
      <div className="bg-slate-950 text-slate-200 px-4 py-2 flex items-center justify-between text-xs font-mono select-none">
          <div className="flex items-center gap-6">
              <span className="font-bold tracking-wider flex items-center gap-2">
                  <Server className="w-4 h-4 text-indigo-400" /> BLACKHORSE // SYSTEM DOCTOR
              </span>
              <span className="text-slate-500">ENV: PRODUCTION</span>
          </div>
          <div className="flex items-center gap-3">
             <span className={safeMode ? "text-emerald-400 font-bold" : "text-amber-500 font-bold"}>
                 {safeMode ? "SAFE MODE: ON" : "SAFE MODE: OFF"}
             </span>
             <Switch checked={safeMode} onCheckedChange={setSafeMode} />
          </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        
        {/* SIDEBAR */}
        <div className="w-64 bg-slate-50 border-r pt-4 space-y-1">
            <Button variant={selectedView === 'active' ? 'secondary' : 'ghost'} className="w-full justify-start rounded-none" onClick={() => setSelectedView('active')}>
                <Activity className="w-4 h-4 mr-3 text-indigo-500" /> Active Queue
                {issues?.length > 0 && <span className="ml-auto bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-full">{issues.length}</span>}
            </Button>
            <Button variant={selectedView === 'history' ? 'secondary' : 'ghost'} className="w-full justify-start rounded-none" onClick={() => setSelectedView('history')}>
                <History className="w-4 h-4 mr-3 text-slate-500" /> History
            </Button>
            
            <div className="mt-8 px-4">
                <p className="text-[10px] font-bold text-slate-400 uppercase mb-2">Shortcuts</p>
                <div className="text-[10px] text-slate-500 space-y-1 font-mono">
                    <div className="flex justify-between"><span>Run Diagnostics</span><span>⌘ D</span></div>
                    <div className="flex justify-between"><span>Execute</span><span>⌘ E</span></div>
                    <div className="flex justify-between"><span>Refresh</span><span>⌘ R</span></div>
                </div>
            </div>
        </div>

        {/* WORKSPACE */}
        {selectedView === 'active' && (
            <div className="flex flex-1">
                {/* LIST */}
                <div className="w-80 border-r bg-white flex flex-col">
                    <div className="p-3 border-b flex justify-between items-center bg-slate-50">
                        <span className="text-xs font-bold text-slate-500 uppercase">Incidents</span>
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => queryClient.invalidateQueries()}><RotateCcw className="w-3 h-3" /></Button>
                    </div>
                    <ScrollArea className="flex-1">
                        {issues?.map(issue => (
                            <div key={issue.id} onClick={() => { setSelectedIssue(issue); setManualMode(false); }} className={`p-4 border-b cursor-pointer hover:bg-slate-50 ${selectedIssue?.id === issue.id ? 'bg-indigo-50 border-l-4 border-l-indigo-500' : ''}`}>
                                <div className="flex justify-between mb-1">
                                    <Badge variant="outline" className="text-[10px]">{issue.root_cause_type || 'NEW'}</Badge>
                                    <span className="text-[10px] text-slate-400">{formatDistanceToNow(new Date(issue.timestamp_utc))}</span>
                                </div>
                                <p className="text-sm font-medium line-clamp-2 text-slate-700">{issue.original_error_message}</p>
                            </div>
                        ))}
                    </ScrollArea>
                </div>

                {/* DETAILS */}
                <div className="flex-1 flex flex-col bg-slate-50/30 relative">
                    {!selectedIssue ? (
                        <div className="flex-1 flex items-center justify-center text-slate-400">
                            <div className="text-center">
                                <ShieldAlert className="w-12 h-12 mx-auto mb-2 opacity-20" />
                                <p>Select an incident to triage.</p>
                            </div>
                        </div>
                    ) : (
                        <ScrollArea className="flex-1">
                            <div className="p-8 max-w-4xl mx-auto space-y-6">
                                {/* Error Card */}
                                <Card className="border-l-4 border-l-red-500 shadow-sm">
                                    <CardContent className="p-4 pt-4">
                                        <h3 className="text-xs font-bold text-red-500 uppercase mb-2">Original Error</h3>
                                        <code className="text-sm font-mono block bg-red-50 p-3 rounded text-red-900 break-all">
                                            {selectedIssue.original_error_message}
                                        </code>
                                    </CardContent>
                                </Card>

                                {/* Controls */}
                                {!selectedIssue.fix_plan_jsonb && !manualMode ? (
                                    <div className="text-center py-10">
                                        <Button size="lg" onClick={runDiagnostics} disabled={isDiagnosing} className="bg-indigo-600 hover:bg-indigo-700">
                                            {isDiagnosing ? <Activity className="w-4 h-4 mr-2 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
                                            {isDiagnosing ? "Analyzing..." : "Run AI Diagnostics"}
                                        </Button>
                                        <div className="mt-4">
                                            <Button variant="link" size="sm" onClick={() => setManualMode(true)} className="text-slate-400">
                                                <Edit3 className="w-3 h-3 mr-2" /> or enter manual SQL
                                            </Button>
                                        </div>
                                    </div>
                                ) : null}

                                {/* Manual Mode */}
                                {manualMode && (
                                    <Card>
                                        <CardContent className="p-4 space-y-4 pt-4">
                                            <h3 className="font-bold flex items-center gap-2"><Terminal className="w-4 h-4" /> Manual Override</h3>
                                            <Textarea 
                                                className="font-mono text-sm min-h-[150px] bg-slate-900 text-emerald-400" 
                                                placeholder="UPDATE table SET column = value WHERE..."
                                                value={manualSql}
                                                onChange={e => setManualSql(e.target.value)}
                                            />
                                            <div className="flex justify-end gap-2">
                                                <Button variant="ghost" onClick={() => setManualMode(false)}>Cancel</Button>
                                                <Button onClick={saveManualPlan}>Save Plan</Button>
                                            </div>
                                        </CardContent>
                                    </Card>
                                )}

                                {/* Plan Review */}
                                {selectedIssue.fix_plan_jsonb && !manualMode && (
                                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                                        <div className="flex justify-between items-center">
                                            <h3 className="text-lg font-bold text-slate-800">Remediation Plan</h3>
                                            <Button variant="outline" size="sm" onClick={() => setManualMode(true)}>Edit</Button>
                                        </div>
                                        
                                        {/* Steps */}
                                        {selectedIssue.fix_plan_jsonb.steps.map((step, i) => (
                                            <Card key={i} className="overflow-hidden">
                                                <div className="bg-slate-100 px-4 py-2 border-b flex justify-between items-center">
                                                    <span className="font-semibold text-sm text-slate-700">Step {step.order}: {step.description}</span>
                                                    {step.is_destructive && <Badge variant="destructive" className="flex gap-1"><AlertTriangle className="w-3 h-3" /> Destructive</Badge>}
                                                </div>
                                                <div className="bg-slate-900 p-4 overflow-x-auto">
                                                    <pre className="text-sm font-mono text-emerald-400">{step.sql}</pre>
                                                </div>
                                            </Card>
                                        ))}

                                        {/* Execution Logs (If running) */}
                                        {stepLogs && stepLogs.length > 0 && (
                                            <div className="mt-6 space-y-2">
                                                <h4 className="text-xs font-bold text-slate-500 uppercase">Live Execution Log</h4>
                                                {stepLogs.map(log => (
                                                    <div key={log.id} className="flex items-center gap-2 text-sm p-2 bg-white border rounded">
                                                        {log.status === 'SUCCESS' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                                                        {log.status === 'PENDING' && <Clock className="w-4 h-4 text-amber-500 animate-pulse" />}
                                                        {log.status === 'FAILURE' && <XCircle className="w-4 h-4 text-red-500" />}
                                                        <span className="font-mono text-xs text-slate-400">Step {log.step_order}</span>
                                                        <span>{log.step_description}</span>
                                                    </div>
                                                ))}
                                            </div>
                                        )}

                                        {/* Action Bar */}
                                        <div className="sticky bottom-0 p-4 bg-white/90 backdrop-blur border-t -mx-8 px-8 flex justify-end items-center gap-4">
                                            {isBlockedBySafeMode && (
                                                <span className="text-xs font-bold text-amber-600 flex items-center gap-1">
                                                    <Lock className="w-3 h-3" /> Safe Mode Blocks Destructive Actions
                                                </span>
                                            )}
                                            <Button 
                                                size="lg"
                                                className="bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200 shadow-lg"
                                                disabled={!isReadyToExecute || isBlockedBySafeMode}
                                                onClick={() => setShowConfirmDialog(true)}
                                            >
                                                <Play className="w-4 h-4 mr-2 fill-current" /> Apply Remediation
                                            </Button>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </ScrollArea>
                    )}
                </div>
            </div>
        )}
        
        {/* HISTORY VIEW (Omitted for brevity, same as previous) */}
        {selectedView === 'history' && (
             <div className="p-8 text-center text-slate-400">History View Active</div>
        )}

      </div>

      {/* CONFIRMATION DIALOG */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>Confirm Execution</DialogTitle>
                <DialogDescription>
                    You are about to execute {selectedIssue?.fix_plan_jsonb?.steps?.length} SQL steps.
                    {hasDestructive && <span className="block mt-2 text-red-600 font-bold">⚠️ Warning: This plan contains destructive operations.</span>}
                </DialogDescription>
            </DialogHeader>
            
            {hasDestructive && (
                <div className="py-2">
                    <p className="text-xs font-bold text-slate-500 mb-1">TYPE "CONFIRM" TO PROCEED:</p>
                    <Input 
                        value={confirmText} 
                        onChange={e => setConfirmText(e.target.value)} 
                        className="border-red-300 focus-visible:ring-red-500"
                    />
                </div>
            )}

            <DialogFooter>
                <Button variant="ghost" onClick={() => setShowConfirmDialog(false)}>Cancel</Button>
                <Button 
                    className="bg-emerald-600 hover:bg-emerald-700" 
                    onClick={() => applyFixMutation.mutate()}
                    disabled={hasDestructive && confirmText !== "CONFIRM"}
                >
                    {applyFixMutation.isPending ? "Executing..." : "Execute Plan"}
                </Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SystemDoctorConsole;