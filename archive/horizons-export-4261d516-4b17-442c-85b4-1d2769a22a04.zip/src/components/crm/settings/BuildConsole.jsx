
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabaseClient';
import { 
  AlertTriangle, CheckCircle2, Terminal, ShieldAlert, 
  History, RotateCcw, ChevronRight,
  Server, Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { formatDistanceToNow } from 'date-fns';
import { Progress } from '@/components/ui/progress';

const BuildConsole = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('diagnostics');
  const [selectedIssue, setSelectedIssue] = useState(null);

  // --- Queries ---

  // 1. Fetch Audit Logs (Potential Issues)
  const { data: issues, isLoading: issuesLoading } = useQuery({
    queryKey: ['system-issues'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('system_audit_log')
        .select('*')
        .eq('execution_status', 'PENDING_REVIEW') 
        .order('timestamp_utc', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      return data;
    }
  });

  // 2. Fetch History
  const { data: fixHistory, isLoading: historyLoading } = useQuery({
    queryKey: ['fix-history'],
    queryFn: async () => {
       // Assuming 'execution_status' changes to SUCCESS/ROLLED_BACK
       const { data, error } = await supabase
        .from('system_audit_log')
        .select('*')
        .in('execution_status', ['SUCCESS', 'ROLLED_BACK', 'PARTIAL_ROLLBACK'])
        .order('timestamp_utc', { ascending: false })
        .limit(20);
       if (error) throw error;
       return data;
    }
  });

  // --- Mutations ---

  // 1. Analyze (Simulated System Doctor Call)
  const analyzeMutation = useMutation({
    mutationFn: async (issueId) => {
       // In a real scenario, this would call the edge function 'system-doctor'
       // For this UI restoration, we simulate the structure expected by the previous UI
       return {
         id: issueId,
         root_cause: 'MISSING_INDEX',
         risk_rating: 'LOW',
         confidence_score: 0.95,
         fix_sql: 'CREATE INDEX idx_leads_email ON leads(email);',
         rollback_sql: 'DROP INDEX idx_leads_email;',
         reasoning_factors: ['High read volume on email column', 'No existing index found', 'Low write impact'],
         explanation: 'Adding an index to the email column will significantly speed up lead lookups during intake.'
       };
    },
    onSuccess: (data) => {
       setSelectedIssue(data);
       toast({ title: 'Analysis Complete', description: 'Remediation plan generated.' });
    }
  });

  const getRiskColor = (rating) => {
    switch(rating) {
        case 'LOW': return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
        case 'MEDIUM': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
        case 'HIGH': return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
        case 'CRITICAL': return 'bg-red-500/10 text-red-500 border-red-500/20';
        default: return 'bg-slate-500/10 text-slate-500 border-slate-500/20';
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">System Doctor Console</h1>
          <p className="text-muted-foreground">Automated diagnostics and self-healing infrastructure.</p>
        </div>
        <div className="flex gap-2">
            <Button variant="outline" onClick={() => queryClient.invalidateQueries()}>
                <RotateCcw className="w-4 h-4 mr-2" /> Refresh
            </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatsCard title="Active Issues" value={issues?.length || 0} icon={AlertTriangle} color="text-yellow-500" />
        <StatsCard title="Fixes Applied" value={fixHistory?.length || 0} icon={CheckCircle2} color="text-emerald-500" />
        <StatsCard title="System Health" value="98%" icon={Activity} color="text-blue-500" />
        <StatsCard title="Protected Mode" value="Active" icon={ShieldAlert} color="text-purple-500" />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="diagnostics" className="flex items-center gap-2">
            <Terminal className="w-4 h-4" /> Diagnostics Queue
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <History className="w-4 h-4" /> Fix History
          </TabsTrigger>
        </TabsList>

        {/* --- DIAGNOSTICS TAB --- */}
        <TabsContent value="diagnostics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Issue List */}
            <Card className="lg:col-span-1 h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle>Detected Anomalies</CardTitle>
                <CardDescription>Real-time system alerts requiring attention.</CardDescription>
              </CardHeader>
              <ScrollArea className="flex-1">
                <div className="p-4 space-y-3">
                  {issuesLoading ? (
                    <div className="text-center p-4 text-muted-foreground">Loading diagnostics...</div>
                  ) : issues?.length === 0 ? (
                    <div className="text-center p-8 border border-dashed rounded-lg m-4">
                        <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                        <p className="text-muted-foreground">All systems operational.</p>
                    </div>
                  ) : (
                    issues?.map(issue => (
                        <div 
                            key={issue.id} 
                            className={`p-3 rounded-lg border cursor-pointer hover:bg-slate-50 transition-colors ${selectedIssue?.id === issue.id ? 'border-blue-500 bg-blue-50' : ''}`}
                            onClick={() => analyzeMutation.mutate(issue.id)}
                        >
                            <div className="flex justify-between items-start mb-1">
                                <Badge variant="outline">{issue.root_cause_type || 'UNKNOWN'}</Badge>
                                <span className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(issue.timestamp_utc))} ago</span>
                            </div>
                            <p className="text-sm font-medium line-clamp-2">{issue.original_error_message}</p>
                        </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </Card>

            {/* Right: Analysis & Fix Panel */}
            <Card className="lg:col-span-2 h-[600px] flex flex-col">
                <CardHeader>
                    <CardTitle>Remediation Plan</CardTitle>
                    <CardDescription>AI-generated fix proposal and impact analysis.</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-y-auto">
                    {!selectedIssue ? (
                        <div className="h-full flex flex-col items-center justify-center text-muted-foreground border-2 border-dashed rounded-lg m-4">
                            <Server className="w-12 h-12 mb-4 opacity-20" />
                            <p>Select an issue to generate a fix plan.</p>
                        </div>
                    ) : (
                        <div className="space-y-6">
                            {/* Summary Header */}
                            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border">
                                <div>
                                    <h3 className="font-semibold text-lg flex items-center gap-2">
                                        {selectedIssue.root_cause}
                                    </h3>
                                    <p className="text-sm text-muted-foreground">{selectedIssue.explanation}</p>
                                </div>
                                <div className="text-right space-y-1">
                                    <Badge className={getRiskColor(selectedIssue.risk_rating)}>
                                        {selectedIssue.risk_rating} RISK
                                    </Badge>
                                    <div className="text-xs font-mono text-muted-foreground">
                                        Conf: {(selectedIssue.confidence_score * 100).toFixed(0)}%
                                    </div>
                                </div>
                            </div>

                            {/* SQL Preview */}
                            <div className="space-y-2">
                                <label className="text-xs font-semibold uppercase text-muted-foreground">Proposed SQL Fix</label>
                                <div className="bg-slate-950 text-slate-50 p-4 rounded-md font-mono text-sm overflow-x-auto">
                                    {selectedIssue.fix_sql}
                                </div>
                            </div>
                            
                            {/* Rollback Preview */}
                            <div className="space-y-2">
                                <label className="text-xs font-semibold uppercase text-muted-foreground">Rollback Strategy</label>
                                <div className="bg-slate-100 text-slate-600 p-3 rounded-md font-mono text-xs overflow-x-auto">
                                    {selectedIssue.rollback_sql}
                                </div>
                            </div>

                            {/* Reasoning */}
                            <div>
                                <label className="text-xs font-semibold uppercase text-muted-foreground mb-2 block">AI Reasoning</label>
                                <ul className="space-y-1">
                                    {selectedIssue.reasoning_factors?.map((factor, i) => (
                                        <li key={i} className="text-sm flex items-start gap-2">
                                            <ChevronRight className="w-4 h-4 text-blue-500 mt-0.5" />
                                            {factor}
                                        </li>
                                    ))}
                                </ul>
                            </div>

                            {/* Action Buttons */}
                            <div className="pt-4 flex items-center justify-end gap-3 border-t">
                                <Button variant="ghost" onClick={() => setSelectedIssue(null)}>Cancel</Button>
                                {/* This is a purely visual restoration, so the button doesn't trigger the new backend RPC yet */}
                                <Button className="bg-emerald-600 hover:bg-emerald-700">
                                    Apply Fix
                                </Button>
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* --- HISTORY TAB --- */}
        <TabsContent value="history">
          <Card>
            <CardHeader>
                <CardTitle>Applied Fixes Log</CardTitle>
                <CardDescription>Audit trail of all automated and manual system interventions.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="rounded-md border">
                    <div className="grid grid-cols-6 gap-4 p-4 font-medium text-sm bg-slate-50 border-b">
                        <div className="col-span-2">Fix Type / Cause</div>
                        <div>Status</div>
                        <div>Confidence</div>
                        <div>Executed By</div>
                        <div className="text-right">Applied At</div>
                    </div>
                    <div className="divide-y">
                        {historyLoading ? (
                             <div className="p-8 text-center text-muted-foreground">Loading history...</div>
                        ) : fixHistory?.length === 0 ? (
                             <div className="p-8 text-center text-muted-foreground">No fixes applied yet.</div>
                        ) : (
                            fixHistory?.map(fix => (
                                <div key={fix.id} className="grid grid-cols-6 gap-4 p-4 text-sm items-center hover:bg-slate-50 transition-colors">
                                    <div className="col-span-2">
                                        <div className="font-medium">{fix.root_cause_type}</div>
                                        <div className="text-xs text-muted-foreground truncate font-mono">{fix.id}</div>
                                    </div>
                                    <div>
                                        <Badge variant="outline" className={fix.execution_status === 'SUCCESS' ? 'text-emerald-500 border-emerald-200 bg-emerald-50' : 'text-slate-500'}>
                                            {fix.execution_status}
                                        </Badge>
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2">
                                           {/* Mock confidence since old audit log structure didn't have it flat */}
                                            <Progress value={95} className="w-16 h-2" />
                                            <span className="text-xs text-muted-foreground">95%</span>
                                        </div>
                                    </div>
                                    <div className="text-muted-foreground">
                                        System
                                    </div>
                                    <div className="text-right text-muted-foreground">
                                        {new Date(fix.timestamp_utc).toLocaleDateString()}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

const StatsCard = ({ title, value, icon: Icon, color }) => (
    <Card>
        <CardContent className="p-6 flex items-center justify-between">
            <div>
                <p className="text-sm font-medium text-muted-foreground">{title}</p>
                <h2 className="text-2xl font-bold">{value}</h2>
            </div>
            <div className={`p-3 rounded-full bg-slate-100 ${color && color.replace('text-', 'bg-').replace('500', '100')}`}>
                <Icon className={`w-6 h-6 ${color}`} />
            </div>
        </CardContent>
    </Card>
);

export default BuildConsole;
