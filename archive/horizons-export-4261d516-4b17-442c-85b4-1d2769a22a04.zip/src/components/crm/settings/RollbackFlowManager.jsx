import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Loader2, Undo2 } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import PreviewRollbackModal from '@/components/crm/settings/PreviewRollbackModal';
import RollbackConfirmationDialog from '@/components/crm/settings/RollbackConfirmationDialog';

export default function RollbackFlowManager({ 
  auditId, 
  featureName, 
  environment = 'production', 
  onFlowComplete 
}) {
  const [currentStep, setCurrentStep] = useState('CLOSED'); // 'CLOSED', 'PREVIEW', 'CONFIRMATION'
  const [previewData, setPreviewData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [auditLogData, setAuditLogData] = useState(null); // Need to store the full log object for modals

  const { toast } = useToast();
  const navigate = useNavigate();

  const handleInitiatePreview = async () => {
    if (!auditId) return;
    
    setIsLoading(true);
    try {
      // First, we need to fetch the audit log details if we don't have them
      // The preview RPC expects p_audit_id, but the modals expect the full auditLog object
      const { data: logData, error: logError } = await supabase
        .from('system_audit_log')
        .select('*')
        .eq('id', auditId)
        .single();
        
      if (logError) throw logError;
      setAuditLogData(logData);

      // Now call the preview RPC
      // Note: PreviewRollbackModal actually calls this internally in its own useEffect if passed an auditLog
      // But the requirements say handleInitiatePreview should call it. 
      // To strictly follow requirements while maintaining component compatibility:
      // We will call it here to validate and get initial state, then pass data or let modal refetch.
      // However, PreviewRollbackModal as written in previous steps fetches its own data.
      // Let's stick to the prompt's instruction: this manager handles the fetch.
      
      /* 
         NOTE: The previous implementation of PreviewRollbackModal fetches data internally when open=true.
         To comply with THIS prompt's requirement (manager fetches data), we might need to adjust props 
         or just let the manager fetch it to decide whether to open the modal at all.
         
         Let's fetch here to ensure we can proceed.
      */

      const { data, error } = await supabase.rpc('preview_rollback_plan', { 
        p_audit_id: auditId 
      });

      if (error) throw error;
      
      if (!data.success) {
        throw new Error(data.error || 'Failed to generate rollback plan');
      }

      if (data.rollback_window_expired) {
        toast({
          variant: "destructive",
          title: "Warning: Rollback Window Expired",
          description: "This action is older than 24 hours. Manual override may be required.",
        });
      }

      setPreviewData(data);
      setCurrentStep('PREVIEW');
      
    } catch (err) {
      console.error('Rollback initiation error:', err);
      toast({
        variant: "destructive",
        title: "Initiation Failed",
        description: err.message || "Could not prepare rollback plan.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleProceedToConfirmation = (planData) => {
    // If the modal passes back data, use it, otherwise use stored state
    if (planData) {
        setPreviewData(planData);
    }
    
    if (currentStep === 'PREVIEW') {
      setCurrentStep('CONFIRMATION');
    }
  };

  const handleRollbackSuccess = (success) => {
    if (onFlowComplete) {
      onFlowComplete(success);
    }
    handleCloseFlow();
  };

  const handleCloseFlow = () => {
    setPreviewData(null);
    setAuditLogData(null);
    setCurrentStep('CLOSED');
    // If we closed without success, we might still want to trigger the callback
    // but usually only on completion. 
  };

  // If we are in CLOSED state, just show the button
  if (currentStep === 'CLOSED') {
    return (
      <Button 
        variant="destructive" 
        onClick={handleInitiatePreview} 
        disabled={isLoading}
        className="w-full sm:w-auto"
      >
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Loading Plan...
          </>
        ) : (
          <>
            <Undo2 className="mr-2 h-4 w-4" />
            Initiate Rollback
          </>
        )}
      </Button>
    );
  }

  return (
    <>
      {/* 
        We render the PreviewModal when step is PREVIEW.
        The PreviewModal expects 'auditLog' prop.
      */}
      {currentStep === 'PREVIEW' && auditLogData && (
        <PreviewRollbackModal 
          open={true}
          onOpenChange={(open) => !open && handleCloseFlow()}
          auditLog={auditLogData}
          onContinue={handleProceedToConfirmation}
        />
      )}

      {/* 
        We render the ConfirmationDialog when step is CONFIRMATION.
        The ConfirmationDialog expects 'rollbackPlan' prop which matches our previewData structure.
      */}
      {currentStep === 'CONFIRMATION' && previewData && (
        <RollbackConfirmationDialog
          open={true}
          onOpenChange={(open) => !open && handleCloseFlow()}
          rollbackPlan={previewData}
          onComplete={handleRollbackSuccess}
        />
      )}
    </>
  );
}