import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useTrainingMode } from '@/contexts/TrainingModeContext';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Zap, AlertTriangle, Database } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const SystemDiagnostics = () => {
    const { isTrainingMode, toggleTrainingMode } = useTrainingMode();
    const { toast } = useToast();
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState(null);
    const [migrateLoading, setMigrateLoading] = useState(false);

    const fetchSystemStats = async () => {
        setLoading(true);
        try {
            const { data, error } = await supabase.rpc('get_system_mode_with_data');

            if (error) {
                console.error('Error fetching system mode with data:', error);
                throw error;
            }

            setStats(data);
            // Ensure client-side training mode matches database
            if (data && data.system_mode !== (isTrainingMode ? 'training' : 'live')) {
                toggleTrainingMode(data.system_mode === 'training');
            }
        } catch (error) {
            console.error('Failed to fetch system diagnostics:', error);
            toast({
                variant: 'destructive',
                title: 'Diagnostic Error',
                description: 'Could not load system diagnostic data.'
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchSystemStats();
    }, []);

    const handleMigrateToTestbed = async () => {
        setMigrateLoading(true);
        try {
            const { data, error } = await supabase.rpc('migrate_production_to_testbed');

            if (error) {
                console.error('Error migrating to testbed:', error);
                throw error;
            }

            if (data && data.success) {
                toast({
                    title: 'Migration Successful',
                    description: `Migrated ${data.summary.total_records_affected} records to testbed. Reloading data...`,
                });
                await fetchSystemStats(); // Re-fetch stats after migration
                toggleTrainingMode(true); // Force training mode after migration
            } else {
                toast({
                    variant: 'destructive',
                    title: 'Migration Failed',
                    description: data?.error || 'Unknown error during migration.',
                });
            }
        } catch (error) {
            console.error('Failed to execute migration:', error);
            toast({
                variant: 'destructive',
                title: 'Migration Error',
                description: 'Failed to complete migration to testbed. Please check console.',
            });
        } finally {
            setMigrateLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-48">
                <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                <span className="ml-3 text-lg text-slate-700">Loading system diagnostics...</span>
            </div>
        );
    }

    const currentMode = stats?.system_mode || 'unknown';
    const liveLeads = stats?.stats?.live_leads || 0;
    const testLeads = stats?.stats?.test_leads || 0;

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Zap className="h-5 w-5 text-indigo-600" /> System Diagnostics
                    </CardTitle>
                    <CardDescription>
                        Overview of current system status, data modes, and critical actions.
                    </CardDescription>
                </CardHeader>
                <CardContent className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    <div className="flex flex-col space-y-2">
                        <h3 className="text-sm font-semibold text-slate-700">Current Data Mode</h3>
                        <Badge variant={currentMode === 'training' ? 'secondary' : 'default'} className="capitalize w-fit">
                            {currentMode === 'training' ? 'Training Mode' : 'Live Mode'}
                        </Badge>
                        <p className="text-sm text-slate-500">
                            {currentMode === 'training'
                                ? 'Operating with test data. Real leads are hidden.'
                                : 'Operating with live data. Exercise caution.'}
                        </p>
                    </div>

                    <div className="flex flex-col space-y-2">
                        <h3 className="text-sm font-semibold text-slate-700">Lead Statistics</h3>
                        <div className="flex flex-col gap-1">
                            <p className="text-sm text-slate-700 flex items-center">
                                <Database className="h-4 w-4 mr-2 text-blue-500" />
                                Live Leads: <span className="font-medium ml-2">{liveLeads}</span>
                            </p>
                            <p className="text-sm text-slate-700 flex items-center">
                                <Database className="h-4 w-4 mr-2 text-green-500" />
                                Test Leads: <span className="font-medium ml-2">{testLeads}</span>
                            </p>
                        </div>
                        <p className="text-sm text-slate-500">
                            Total leads available across all data modes.
                        </p>
                    </div>

                    <div className="flex flex-col space-y-2">
                        <h3 className="text-sm font-semibold text-slate-700">
                            <AlertTriangle className="h-4 w-4 mr-1 inline-block text-red-500" /> Critical Action
                        </h3>
                        <p className="text-sm text-slate-500">
                            This action will mark all existing production data as 'test_data', effectively migrating your
                            live environment to a training environment. This is irreversible.
                        </p>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button
                                    variant="destructive"
                                    disabled={migrateLoading || currentMode === 'training'}
                                >
                                    {migrateLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Migrate All to Testbed
                                </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle className="flex items-center text-red-600">
                                        <AlertTriangle className="mr-2 h-6 w-6" /> Are you absolutely sure?
                                    </AlertDialogTitle>
                                    <AlertDialogDescription>
                                        This action cannot be undone. All your current live lead, job, and customer data
                                        will be permanently marked as 'test_data'. This means your production
                                        environment will become a training environment.
                                        <br /><br />
                                        Please type "MIGRATE TO TESTBED" to confirm.
                                        <input
                                            type="text"
                                            className="mt-4 p-2 border rounded-md w-full"
                                            placeholder="Type 'MIGRATE TO TESTBED' to confirm"
                                            id="migrate-confirm-input"
                                        />
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                        onClick={() => {
                                            const confirmInput = document.getElementById('migrate-confirm-input');
                                            if (confirmInput && confirmInput.value === 'MIGRATE TO TESTBED') {
                                                handleMigrateToTestbed();
                                            } else {
                                                toast({
                                                    variant: 'destructive',
                                                    title: 'Confirmation Failed',
                                                    description: 'You must correctly type "MIGRATE TO TESTBED" to proceed.',
                                                });
                                            }
                                        }}
                                        className="bg-red-600 hover:bg-red-700"
                                    >
                                        Confirm Migration
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                        <p className="text-xs text-red-500 mt-1">
                            Use with extreme caution. This permanently changes your data's status.
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default SystemDiagnostics;