import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, Copy, Zap, Bot, CheckCircle, Mail, MessageSquare, ShieldAlert, Flag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from '@/components/ui/use-toast';
import { invoke } from '@/lib/api';
import { CHAOS_SCRIPTS } from '@/lib/hvac-scripts';
import FlagChaosModal from '@/components/crm/hvac/FlagChaosModal';
import HvacCallConsoleState from '@/components/crm/hvac/HvacCallConsoleState';

const SuggestionsPanel = ({ suggestions, isLoading, onSelect, selectedTemplate }) => {
    if (isLoading) return <div className="text-center p-4 text-gray-500">Loading AI Suggestions...</div>;
    if (!suggestions || suggestions.length === 0) return <div className="text-center p-4 text-gray-500">No suggestions for this outcome.</div>;

    const ChannelIcons = ({ channels }) => (<div className="flex items-center gap-2"> {channels.includes('email') && <Mail className="h-4 w-4 text-gray-500" />} {channels.includes('sms') && <MessageSquare className="h-4 w-4 text-gray-500" />} </div>);

    return (
        <div className="space-y-2">
            {suggestions.map((s, i) => (
                <motion.div key={s.template_id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                    <Card className={`cursor-pointer transition-all h-full ${selectedTemplate?.template_id === s.template_id ? 'ring-2 ring-blue-500 shadow-md' : 'hover:shadow-sm'}`} onClick={() => onSelect(s)}>
                        <CardHeader className="flex flex-row items-center justify-between p-3">
                            <CardTitle className="text-sm font-semibold">{s.template_id}</CardTitle>
                            {selectedTemplate?.template_id === s.template_id && <CheckCircle className="h-5 w-5 text-blue-500 flex-shrink-0" />}
                        </CardHeader>
                        <CardContent className="p-3 pt-0"> <p className="text-xs text-gray-500 mb-2">{s.reason}</p> <ChannelIcons channels={s.channels} /> </CardContent>
                    </Card>
                </motion.div>
            ))}
        </div>
    );
};

const AiCopilot = ({ lead, onCompleteAction, isCommitting }) => {
    const { toast } = useToast();
    const [scriptText, setScriptText] = useState("Loading script...");
    const [chaosMode, setChaosMode] = useState(false);
    const [chaosData, setChaosData] = useState(null);
    
    const [finalOutcome, setFinalOutcome] = useState('');
    const [notes, setNotes] = useState('');
    const [suggestions, setSuggestions] = useState([]);
    const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [showFlagModal, setShowFlagModal] = useState(false);

    // Initial load and chaos check
    useEffect(() => {
        if (lead?.chaos_flag && lead?.chaos_flag_type) {
            const script = CHAOS_SCRIPTS[lead.chaos_flag_type];
            if (script) {
                setChaosMode(true);
                setChaosData(script);
                setScriptText(script.script.replace('[Rep Name]', 'The Vent Guys').replace('[Service Area]', lead.city || 'your area'));
            }
        } else {
            setChaosMode(false);
            setChaosData(null);
            // Default script if not chaos
            setScriptText("Hi, this is [Rep Name] with The Vent Guys. I saw you just pulled a mechanical permit, and I'm calling to see if you need a certified post-construction duct cleaning to avoid a failed inspection.".replace('[Rep Name]', 'your name'));
        }
    }, [lead]);

    const fetchSuggestions = useCallback(async (outcome) => {
        if (!outcome || !lead) return;
        setIsLoadingSuggestions(true);
        setSuggestions([]);
        setSelectedTemplate(null);
        
        const payload = { 
            lead_id: lead.id, 
            lead: lead, 
            lead_data: lead,
            final_outcome: outcome 
        };
        
        try {
            const { ok, data, error } = await invoke('smartdocs-suggest', { 
                body: JSON.stringify(payload) 
            });

            if (ok && data?.suggestions) {
                setSuggestions(data.suggestions);
                if (data.suggestions.length > 0) setSelectedTemplate(data.suggestions[0]);
            } else {
                console.error("SmartDocs suggest failed:", error || "No suggestions returned");
                setSuggestions([]);
            }
        } catch (err) {
             console.error("Network error fetching suggestions:", err);
             setSuggestions([]);
        } finally {
            setIsLoadingSuggestions(false);
        }
    }, [lead]);

    useEffect(() => {
        if (finalOutcome) fetchSuggestions(finalOutcome); else { setSuggestions([]); setSelectedTemplate(null); }
    }, [finalOutcome, fetchSuggestions]);

    const handleCommit = () => {
        if (!finalOutcome) {
            toast({ variant: 'destructive', title: 'Action Required', description: 'Please select a call outcome.' });
            return;
        }
        onCompleteAction({ final_outcome: finalOutcome, notes: notes, template: selectedTemplate });
    };

    const onCopy = (text) => {
        navigator.clipboard.writeText(text);
        toast({ title: "Copied ✓", description: "Script copied to clipboard.", duration: 2000 });
    };

    return (
        <div className="flex flex-col h-full">
            {/* Chaos Banner */}
            <HvacCallConsoleState lead={lead} />

            <Card className="flex-1 flex flex-col bg-white text-gray-900 shadow-lg border-t-0 rounded-t-none">
                <CardHeader className="pb-3 border-b flex flex-row justify-between items-center">
                    <div>
                        <CardTitle className="flex items-center"><BrainCircuit className="mr-2 text-blue-500"/> {chaosMode ? "PROTOCOL SCRIPT" : "AI Call Flow"}</CardTitle>
                        <CardDescription>Your real-time coach & playbook</CardDescription>
                    </div>
                    {!chaosMode && (
                         <Button variant="destructive" size="sm" onClick={() => setShowFlagModal(true)} className="gap-2">
                            <Flag className="h-4 w-4" /> Flag Chaos
                         </Button>
                    )}
                </CardHeader>
                
                <div className="flex-1 flex flex-col overflow-hidden">
                    <div className="p-4 space-y-4 overflow-y-auto">
                        
                        <div className={`p-4 rounded-lg group border flex-1 flex flex-col shadow-inner ${chaosMode ? 'bg-red-50 border-red-200' : 'bg-gray-50'}`}>
                            <div className="flex justify-between items-start mb-2">
                                <h3 className={`text-xs font-bold tracking-wider uppercase ${chaosMode ? 'text-red-600' : 'text-blue-600'}`}>
                                    {chaosMode ? chaosData?.title : "Suggested Script"}
                                </h3>
                                <Button size="icon" variant="ghost" className="h-7 w-7 ml-2 -mt-1 opacity-50 group-hover:opacity-100 transition-opacity" onClick={() => onCopy(scriptText)}> <Copy className="h-4 w-4" /> </Button>
                            </div>
                            <p className={`text-base leading-relaxed flex-1 ${chaosMode ? 'font-medium text-red-900' : 'text-gray-800'}`}>
                                {scriptText}
                            </p>
                            {chaosMode && (
                                <div className="mt-4 pt-3 border-t border-red-200">
                                    <span className="text-xs font-bold text-red-500 uppercase">Required Action:</span>
                                    <div className={`mt-1 px-3 py-1.5 rounded text-sm font-bold inline-block ${chaosData?.color}`}>
                                        {chaosData?.action}
                                    </div>
                                </div>
                            )}
                        </div>

                    </div>

                    {/* After Call Log Section */}
                    <div className="p-4 bg-gray-50 border-t space-y-4">
                        <h3 className="font-semibold text-md">After Call Log</h3>
                        <div className="grid grid-cols-1 gap-4">
                            <Select onValueChange={setFinalOutcome} value={finalOutcome}>
                                <SelectTrigger className="h-11 text-base"><SelectValue placeholder="Select Call Outcome..." /></SelectTrigger>
                                <SelectContent>{["booked", "qualified", "nurture", "lost", "no_answer", "voicemail", "chaos_blacklisted"].map(v => <SelectItem key={v} value={v}>{v.toUpperCase().replace('_', ' ')}</SelectItem>)}</SelectContent>
                            </Select>
                            <Textarea placeholder="Call notes for summary..." value={notes} onChange={(e) => setNotes(e.target.value)} className="h-20 text-base" />
                        </div>
                        
                        <AnimatePresence>
                        {finalOutcome && !chaosMode && (
                            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                                <div className="space-y-3 pt-4">
                                    <h3 className="font-semibold text-sm flex items-center"><Bot className="mr-2 text-blue-500" /> AI Suggested Actions</h3>
                                    <div className="max-h-32 overflow-y-auto pr-2">
                                        <SuggestionsPanel suggestions={suggestions} isLoading={isLoadingSuggestions} onSelect={setSelectedTemplate} selectedTemplate={selectedTemplate} />
                                    </div>
                                </div>
                            </motion.div>
                        )}
                        </AnimatePresence>
                    </div>
                </div>

                {/* Commit Button */}
                <div className="p-4 bg-gray-100 border-t mt-auto">
                    <Button onClick={handleCommit} size="lg" className={`w-full text-white font-bold text-lg ${chaosMode ? 'bg-gray-800 hover:bg-gray-900' : 'bg-gradient-to-r from-green-500 to-emerald-600'}`} disabled={isCommitting || !finalOutcome || isLoadingSuggestions}>
                        <Zap className="mr-2 h-5 w-5" />
                        {isCommitting ? 'Committing...' : 'Send & Log'}
                    </Button>
                </div>
            </Card>
            
            {lead && (
                <FlagChaosModal 
                    open={showFlagModal} 
                    onOpenChange={setShowFlagModal} 
                    lead={lead} 
                    onFlagged={() => window.location.reload()} // Simple reload to refresh state
                />
            )}
        </div>
    );
};

export default AiCopilot;