// This component is no longer needed as its functionality has been merged into AiCopilot.jsx
// Keeping the file to avoid breaking imports until a full cleanup, but it can be removed later.
import React from 'react';

const AfterCallLog = () => {
    return null;
};

export default AfterCallLog;