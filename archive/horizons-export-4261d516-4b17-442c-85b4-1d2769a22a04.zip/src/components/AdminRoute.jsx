import React, { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useSupabaseAuth } from '@/contexts/SupabaseAuthContext';
import { Loader2 } from 'lucide-react';

const AdminRoute = ({ children, requiredRole }) => {
  const { user, loading, role, isAdmin } = useSupabaseAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <p className="text-sm text-slate-500">Verifying access...</p>
        </div>
      </div>
    );
  }

  // 1. Check Authentication
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 2. Check Role Authorization (if specific role required)
  // If requiredRole is passed, check if user has it. 
  // Admin always passes.
  if (requiredRole && role !== requiredRole && !isAdmin) {
     // If they are logged in but don't have permission, send to a safe page or 403
     return (
       <div className="h-screen w-full flex flex-col items-center justify-center bg-slate-50 p-4 text-center">
         <h1 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h1>
         <p className="text-slate-600 mb-6">You do not have the required permissions ({requiredRole}) to view this page.</p>
         <Navigate to="/crm/dashboard" replace />
       </div>
     );
  }

  return children;
};

export default AdminRoute;