import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { pqiBadgeClass } from '@/lib/uiClassUtils';
import { ArrowUpRight, Users, Target, BarChart2 } from 'lucide-react';

const StatCard = ({ title, value, icon, change, changeType }) => (
    <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            {icon}
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
            {change && (
                <p className={`text-xs ${changeType === 'increase' ? 'text-green-600' : 'text-red-600'}`}>
                    {change} vs last week
                </p>
            )}
        </CardContent>
    </Card>
);

const CrmHome = () => {
    const { toast } = useToast();
    const [recentLeads, setRecentLeads] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchRecentLeads = useCallback(async () => {
        setLoading(true);
        // Query the new public view 'v_leads_public'
        const { data, error } = await supabase
            .from('v_leads_public')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(5);

        if (error) {
            toast({
                variant: 'destructive',
                title: 'Error fetching leads',
                description: `Could not load public leads. Check RLS policies on 'v_leads_public'.`,
            });
            setRecentLeads([]);
        } else {
            setRecentLeads(data);
        }
        setLoading(false);
    }, [toast]);

    useEffect(() => {
        fetchRecentLeads();
    }, [fetchRecentLeads]);

    return (
        <>
            <Helmet>
                <title>Dashboard | TVG CRM</title>
            </Helmet>
            <div className="p-4 md:p-6 space-y-6">
                <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <StatCard title="New Leads (7d)" value="12" icon={<Users className="h-4 w-4 text-muted-foreground" />} change="+20.1%" changeType="increase" />
                    <StatCard title="Booked Jobs (7d)" value="3" icon={<Target className="h-4 w-4 text-muted-foreground" />} change="-2.5%" changeType="decrease" />
                    <StatCard title="Conversion Rate" value="25%" icon={<BarChart2 className="h-4 w-4 text-muted-foreground" />} change="+5.2%" changeType="increase" />
                    <StatCard title="Avg. PQI" value="78" icon={<ArrowUpRight className="h-4 w-4 text-muted-foreground" />} change="+8" changeType="increase" />
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle>Recent Leads</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Company/Property</TableHead>
                                    <TableHead>Persona</TableHead>
                                    <TableHead>Stage</TableHead>
                                    <TableHead className="text-right">PQI</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loading ? (
                                    <TableRow><TableCell colSpan="4" className="h-24 text-center">Loading...</TableCell></TableRow>
                                ) : recentLeads.length > 0 ? (
                                    recentLeads.map(lead => (
                                        <TableRow key={lead.id}>
                                            <TableCell className="font-medium">{lead.company || lead.property_name || 'N/A'}</TableCell>
                                            <TableCell><Badge variant="outline">{lead.persona}</Badge></TableCell>
                                            <TableCell>{lead.pipeline_stage}</TableCell>
                                            <TableCell className="text-right">
                                                <span className={pqiBadgeClass(lead.pqi)}>{lead.pqi}</span>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow><TableCell colSpan="4" className="h-24 text-center">No recent leads found.</TableCell></TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </>
    );
};

export default CrmHome;