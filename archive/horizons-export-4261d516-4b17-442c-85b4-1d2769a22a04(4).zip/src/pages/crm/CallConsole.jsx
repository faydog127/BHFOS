
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from '@/components/ui/drawer';
import { Switch } from '@/components/ui/switch';
import { Phone, User, Building, Clock, Bot, TrendingUp, Filter, Search, Loader2, Users, Zap, ChevronsRight, X, Mail, MapPin } from 'lucide-react';

const priorityColors = { URGENT: 'bg-red-500', HIGH: 'bg-orange-500', NORMAL: 'bg-yellow-500', LOW: 'bg-blue-500' };
const statusColors = { OPEN: 'bg-blue-100 text-blue-800', IN_PROGRESS: 'bg-yellow-100 text-yellow-800', WON: 'bg-green-100 text-green-800', LOST: 'bg-red-100 text-red-800', ARCHIVED: 'bg-gray-100 text-gray-800' };
const LEAD_SOURCES = ['WEBSITE', 'REFERRAL', 'MANUAL', 'PARTNER'];

const LeadList = ({ leads, onSelectLead, selectedLeadId, loading }) => (
    <Card className="h-full flex flex-col bg-white border-none shadow-none">
        <CardHeader className="pt-2">
            <CardTitle className="flex items-center text-lg"><Users className="mr-2 h-5 w-5"/> Lead Queue</CardTitle>
            <CardDescription>{leads.length} leads</CardDescription>
        </CardHeader>
        <CardContent className="p-0 flex-1">
            <ScrollArea className="h-full px-2">
                {loading ? <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin text-gray-400"/></div>
                : leads.length === 0 ? <div className="text-center py-10 text-gray-500">No leads match filters.</div>
                : (
                    <div className="space-y-1 pb-2">
                        {leads.map(lead => (
                            <div key={lead.id} onClick={() => onSelectLead(lead)} className={`flex items-center p-3 rounded-lg cursor-pointer transition-colors ${selectedLeadId === lead.id ? 'bg-[#1B263B] text-white' : 'hover:bg-gray-50'}`}>
                                <div className={`h-2.5 w-2.5 rounded-full mr-3 flex-shrink-0 ${priorityColors[lead.priority]}`}></div>
                                <div className="flex-1 overflow-hidden">
                                    <p className="font-semibold truncate text-sm">{lead.company || `${lead.first_name} ${lead.last_name || ''}`}</p>
                                    <p className={`text-xs truncate ${selectedLeadId === lead.id ? 'text-gray-300' : 'text-gray-500'}`}>{lead.service}</p>
                                </div>
                                <Badge variant="outline" className={`text-xs border ${selectedLeadId === lead.id ? 'bg-white/10 border-white/20 text-white' : statusColors[lead.status]}`}>{lead.status}</Badge>
                            </div>
                        ))}
                    </div>
                )}
            </ScrollArea>
        </CardContent>
    </Card>
);

const CallHistory = ({ calls, loading }) => (
    <div>
        <h3 className="text-lg font-semibold mb-2 flex items-center"><Clock className="mr-2 h-5 w-5"/> Call History</h3>
        {loading ? <p className="text-sm text-gray-500">Loading history...</p> : calls.length === 0 ? <p className="text-sm text-gray-500">No calls logged yet.</p> : (
            <ScrollArea className="h-48 border rounded-lg p-2 bg-gray-50/50">
                <div className="space-y-3">
                    {calls.map(call => (
                        <div key={call.id} className="text-sm">
                            <div className="flex justify-between items-center">
                                <span className="font-semibold">{call.disposition}</span>
                                <span className="text-xs text-gray-500">{new Date(call.created_at).toLocaleString()}</span>
                            </div>
                            <p className="text-gray-600 mt-1 italic">"{call.notes || 'No notes provided.'}"</p>
                        </div>
                    ))}
                </div>
            </ScrollArea>
        )}
    </div>
);

const CafzMetrics = () => (
     <Card className="bg-white">
        <CardHeader>
            <CardTitle className="text-base">CAFZ Metrics (Last 30 Days)</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-3 gap-4 text-center">
            <div><p className="text-2xl font-bold">12</p><p className="text-xs text-gray-500">CAFZ Leads</p></div>
            <div><p className="text-2xl font-bold">3 (25%)</p><p className="text-xs text-gray-500">Booked</p></div>
            <div><p className="text-2xl font-bold">HVAC Install</p><p className="text-xs text-gray-500">Top Event</p></div>
        </CardContent>
    </Card>
);

const CallConsole = () => {
    const { toast } = useToast();
    const [leads, setLeads] = useState([]);
    const [selectedLead, setSelectedLead] = useState(null);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [callHistory, setCallHistory] = useState([]);
    const [loadingLeads, setLoadingLeads] = useState(true);
    const [loadingHistory, setLoadingHistory] = useState(false);
    const [isLoggingCall, setIsLoggingCall] = useState(false);
    const [isUpdatingLead, setIsUpdatingLead] = useState(false);
    const [filters, setFilters] = useState({ status: 'OPEN', source: 'ALL', cafzOnly: false, search: '' });

    const debouncedSearch = useMemo(() => {
        let timer;
        return (searchVal) => {
            clearTimeout(timer);
            timer = setTimeout(() => {
                setFilters(f => ({...f, search: searchVal}));
            }, 300);
        }
    }, []);

    const fetchLeads = useCallback(async () => {
        setLoadingLeads(true);
        let query = supabase.from('leads').select('*').in('status', ['OPEN', 'IN_PROGRESS']);
        if (filters.status && filters.status !== 'ALL') query = query.eq('status', filters.status);
        if (filters.source && filters.source !== 'ALL') query = query.eq('source_kind', filters.source);
        if (filters.search) query = query.or(`company.ilike.%${filters.search}%,first_name.ilike.%${filters.search}%,last_name.ilike.%${filters.search}%,service.ilike.%${filters.search}%`);
        if (filters.cafzOnly) query = query.eq('is_cafz', true); // Assuming a boolean field 'is_cafz' exists
        
        const { data, error } = await query.order('priority', { ascending: false }).order('created_at', { ascending: true });
        if (error) toast({ variant: 'destructive', title: 'Error fetching leads', description: error.message });
        else setLeads(data);
        setLoadingLeads(false);
    }, [filters, toast]);

    const fetchCallHistory = useCallback(async (leadId) => {
        if (!leadId) return;
        setLoadingHistory(true);
        const { data, error } = await supabase.from('calls').select('*').eq('lead_id', leadId).order('created_at', { ascending: false });
        if (error) toast({ variant: 'destructive', title: 'Error fetching call history', description: error.message });
        else setCallHistory(data);
        setLoadingHistory(false);
    }, [toast]);

    useEffect(() => { fetchLeads(); }, [fetchLeads]);

    useEffect(() => {
        if (selectedLead?.id) {
            fetchCallHistory(selectedLead.id);
            setIsDrawerOpen(true);
        } else {
            setIsDrawerOpen(false);
        }
    }, [selectedLead, fetchCallHistory]);

    const handleSelectLead = (lead) => { setSelectedLead(lead); };
    const handleCloseDrawer = () => { setSelectedLead(null); };

    const handleLogCall = async (e) => {
        e.preventDefault();
        if (!selectedLead) return;
        setIsLoggingCall(true);
        const formData = new FormData(e.target);
        const callData = Object.fromEntries(formData.entries());
        const payload = {
            lead_id: selectedLead.id,
            from_number: '+13213609704', to_number: selectedLead.phone,
            direction: 'OUTBOUND', disposition: callData.disposition, notes: callData.notes,
            duration_sec: parseInt(callData.duration_sec, 10) || 0,
        };
        const { data, error } = await supabase.functions.invoke('calls', { body: JSON.stringify(payload) });
        if (error || (data && data.error)) toast({ variant: 'destructive', title: 'Failed to log call', description: error?.message || data?.error });
        else {
            toast({ title: 'Call logged successfully!' });
            fetchCallHistory(selectedLead.id);
            fetchLeads(); // Refetch to see status change
            e.target.reset();
        }
        setIsLoggingCall(false);
    };

    const handleUpdateLead = async (field, value) => {
        if (!selectedLead) return;
        setIsUpdatingLead(true);
        const { error } = await supabase.from('leads').update({ [field]: value }).eq('id', selectedLead.id);
        if (error) toast({ variant: 'destructive', title: 'Failed to update lead', description: error.message });
        else {
            toast({ title: `Lead ${field} updated!` });
            setSelectedLead(prev => ({...prev, [field]: value}));
            setLeads(prevLeads => prevLeads.map(l => l.id === selectedLead.id ? {...l, [field]: value} : l));
        }
        setIsUpdatingLead(false);
    };

    return (
        <>
            <Helmet><title>Call Console | The Vent Guys CRM</title></Helmet>
            <div className="h-screen w-screen bg-[#F4F7FA] flex font-sans text-gray-800">
                {/* Sidebar */}
                <aside className="w-72 bg-white border-r border-gray-200 p-4 flex flex-col space-y-6">
                    <h1 className="text-2xl font-bold text-[#1B263B]">Call Console</h1>
                    <div className="space-y-4">
                        <div>
                            <Label htmlFor="search">Search</Label>
                            <div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400"/><Input id="search" placeholder="Name, company, service..." className="pl-9" onChange={e => debouncedSearch(e.target.value)}/></div>
                        </div>
                        <div>
                            <Label htmlFor="status-filter">Status</Label>
                            <Select value={filters.status} onValueChange={v => setFilters(f => ({...f, status: v}))}><SelectTrigger id="status-filter"><SelectValue/></SelectTrigger>
                                <SelectContent><SelectItem value="ALL">All Active</SelectItem><SelectItem value="OPEN">Open</SelectItem><SelectItem value="IN_PROGRESS">In Progress</SelectItem></SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label htmlFor="source-filter">Source</Label>
                            <Select value={filters.source} onValueChange={v => setFilters(f => ({...f, source: v}))}><SelectTrigger id="source-filter"><SelectValue/></SelectTrigger>
                                <SelectContent><SelectItem value="ALL">All Sources</SelectItem>{LEAD_SOURCES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                        <div className="flex items-center justify-between pt-2">
                            <Label htmlFor="cafz-toggle">CAFZ Leads Only</Label>
                            <Switch id="cafz-toggle" checked={filters.cafzOnly} onCheckedChange={c => setFilters(f => ({...f, cafzOnly: c}))} />
                        </div>
                    </div>
                    <div className="mt-auto"><CafzMetrics /></div>
                </aside>

                {/* Main Content */}
                <main className="flex-1 p-6 overflow-hidden h-full">
                    <LeadList leads={leads} onSelectLead={handleSelectLead} selectedLeadId={selectedLead?.id} loading={loadingLeads} />
                </main>

                {/* Lead Detail Drawer */}
                <Drawer open={isDrawerOpen} onOpenChange={setIsDrawerOpen}>
                    <DrawerContent className="w-[600px] sm:max-w-[600px] h-screen top-0 right-0 left-auto mt-0 rounded-none flex flex-col data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right">
                        <ScrollArea className="flex-1">
                        {selectedLead && (
                            <>
                            <DrawerHeader className="p-4 border-b text-left">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <DrawerTitle className="text-2xl">{selectedLead.company || `${selectedLead.first_name} ${selectedLead.last_name || ''}`}</DrawerTitle>
                                        <DrawerDescription>{selectedLead.service}</DrawerDescription>
                                    </div>
                                    <Button variant="ghost" size="icon" onClick={handleCloseDrawer} className="flex-shrink-0"><X className="h-5 w-5"/></Button>
                                </div>
                                <div className="flex items-center gap-2 pt-4">
                                    <Select value={selectedLead.priority} onValueChange={v => handleUpdateLead('priority', v)} disabled={isUpdatingLead}><SelectTrigger className="w-32 h-9"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="LOW">Low</SelectItem><SelectItem value="NORMAL">Normal</SelectItem><SelectItem value="HIGH">High</SelectItem><SelectItem value="URGENT">Urgent</SelectItem></SelectContent></Select>
                                    <Select value={selectedLead.status} onValueChange={v => handleUpdateLead('status', v)} disabled={isUpdatingLead}><SelectTrigger className="w-36 h-9"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="OPEN">Open</SelectItem><SelectItem value="IN_PROGRESS">In Progress</SelectItem><SelectItem value="WON">Won</SelectItem><SelectItem value="LOST">Lost</SelectItem><SelectItem value="ARCHIVED">Archived</SelectItem></SelectContent></Select>
                                </div>
                            </DrawerHeader>
                            <div className="p-4 space-y-6">
                                <Card><CardContent className="pt-6 grid grid-cols-2 gap-4 text-sm">
                                    <div className="flex items-center"><User className="mr-2 h-4 w-4 text-gray-500"/><span>{`${selectedLead.first_name} ${selectedLead.last_name || ''}`}</span></div>
                                    <div className="flex items-center"><Phone className="mr-2 h-4 w-4 text-gray-500"/><a href={`tel:${selectedLead.phone}`} className="text-[#D7263D] hover:underline">{selectedLead.phone}</a></div>
                                    <div className="flex items-center"><Mail className="mr-2 h-4 w-4 text-gray-500"/><a href={`mailto:${selectedLead.email}`} className="text-[#D7263D] hover:underline truncate">{selectedLead.email}</a></div>
                                    <div className="flex items-center"><Building className="mr-2 h-4 w-4 text-gray-500"/><span>{selectedLead.company || 'N/A'}</span></div>
                                    <div className="col-span-2 flex items-start"><MapPin className="mr-2 mt-1 h-4 w-4 text-gray-500"/><span>{selectedLead.property_name || 'No property info'}</span></div>
                                </CardContent></Card>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <Card className="bg-blue-50/50"><CardHeader className="p-3"><CardTitle className="text-sm flex items-center"><Bot className="mr-2 h-4"/>AI Summary</CardTitle></CardHeader><CardContent className="p-3 pt-0"><p className="text-xs text-blue-800">AI summary will appear here.</p></CardContent></Card>
                                    <Card className="bg-green-50/50"><CardHeader className="p-3"><CardTitle className="text-sm flex items-center"><Zap className="mr-2 h-4"/>AI Next-Step</CardTitle></CardHeader><CardContent className="p-3 pt-0"><p className="text-xs text-green-800">AI recommendation will appear here.</p></CardContent></Card>
                                    <Card className="bg-purple-50/50"><CardHeader className="p-3"><CardTitle className="text-sm flex items-center"><TrendingUp className="mr-2 h-4"/>AI Score</CardTitle></CardHeader><CardContent className="p-3 pt-0"><p className="text-xs text-purple-800">AI score will appear here.</p></CardContent></Card>
                                </div>
                                <Card>
                                    <CardHeader><CardTitle className="text-lg">Log a Call</CardTitle></CardHeader>
                                    <CardContent>
                                        <form onSubmit={handleLogCall} className="space-y-4">
                                            <div className="grid grid-cols-2 gap-4">
                                                <div><Label htmlFor="disposition">Disposition</Label><Select name="disposition" required><SelectTrigger><SelectValue placeholder="Select..."/></SelectTrigger><SelectContent>{['NO_ANSWER', 'VOICEMAIL', 'COMPLETED', 'CALLBACK', 'ESCALATED'].map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent></Select></div>
                                                <div><Label htmlFor="duration_sec">Duration (sec)</Label><Input name="duration_sec" type="number" defaultValue="0"/></div>
                                            </div>
                                            <div><Label htmlFor="notes">Notes</Label><Textarea name="notes" placeholder="Call summary, next steps..."/></div>
                                            <Button type="submit" disabled={isLoggingCall} className="w-full bg-[#D7263D] hover:bg-[#b51f31]"><Phone className="mr-2 h-4"/> {isLoggingCall ? <><Loader2 className="animate-spin mr-2"/>Logging...</> : 'Log Call'}</Button>
                                        </form>
                                    </CardContent>
                                </Card>
                                <CallHistory calls={callHistory} loading={loadingHistory} />
                            </div>
                            </>
                        )}
                        </ScrollArea>
                    </DrawerContent>
                </Drawer>
            </div>
        </>
    );
};

export default CallConsole;
