
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Wind, Flame, TestTube, CheckCircle, Calendar, ExternalLink, HelpCircle, BookOpen, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import FaqAccordion from '@/components/FaqAccordion';
import { allFaqs } from '@/config/faqs';

const ServiceFaqs = ({ ids }) => {
    const faqs = allFaqs.filter(faq => ids.includes(faq.id));
    return (
        <div className="mt-12">
            <h3 className="text-2xl font-bold text-[#1B263B] mb-4 flex items-center">
                <HelpCircle className="mr-3 text-[#D7263D]"/>
                Frequently Asked Questions
            </h3>
            <FaqAccordion faqs={faqs} />
            <div className="text-right mt-4">
                <Link to="/faq" className="text-sm font-semibold text-[#D7263D] hover:underline">
                    See all FAQs →
                </Link>
            </div>
        </div>
    );
};

const RelatedReading = ({ links }) => (
    <div className="mt-12 bg-gray-100 p-6 rounded-lg">
        <h3 className="text-2xl font-bold text-[#1B263B] mb-4 flex items-center">
            <BookOpen className="mr-3 text-[#D7263D]"/>
            Related Reading
        </h3>
        <ul className="space-y-3">
            {links.map((link, i) => (
                <li key={i}>
                    <Link to={link.path} className="flex items-center text-gray-700 hover:text-[#D7263D] group">
                        <span className="font-semibold group-hover:underline">{link.title}</span>
                        <ArrowRight className="ml-auto h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity"/>
                    </Link>
                </li>
            ))}
        </ul>
    </div>
);


const Services = () => {
    const services = [
        {
            icon: Wind,
            title: 'Air Duct Cleaning',
            description: 'Our professional, NADCA-certified air duct cleaning removes years of accumulated dust, allergens, and contaminants from your HVAC system. We follow a strict mechanical hygiene cleaning process to ensure the best results.',
            benefits: [
                'Removes dust, pollen, and allergens',
                'Improves HVAC efficiency',
                'Reduces energy costs',
                'Eliminates musty odors',
                'Extends system lifespan'
            ],
            faqIds: ['q1', 'q2', 'q7', 'q8'],
            relatedLinks: [
                { title: "Learn more about return duct leaks →", path: "/blog/return-duct-leak-attic-air/" },
                { title: "Mechanical Hygiene vs. Air Duct Cleaning", path: "/mechanical-hygiene-vs-duct-cleaning" },
            ],
            image: {
                src: "https://images.unsplash.com/photo-1602075422734-a8a43c7347c2",
                alt: "Diverse technician performing air duct cleaning in a modern Central Florida home, showing professionalism and care."
            }
        },
        {
            icon: Flame,
            title: 'Dryer Vent Cleaning',
            description: 'Prevent fire hazards and improve dryer efficiency with our professional dryer vent cleaning. Lint buildup is a leading cause of home fires and can negatively impact your indoor air quality.',
            benefits: [
                'Prevents dryer fires',
                'Reduces drying time',
                'Lowers energy bills',
                'Extends dryer lifespan',
                'Improves air quality'
            ],
            faqIds: ['q5'],
            relatedLinks: [],
            image: {
                src: "https://images.unsplash.com/photo-1581578731548-c64695cc6952",
                alt: "Technician showing a relieved homeowner the amount of lint removed from their dryer vent in a suburban Florida house."
            }
        },
        {
            icon: TestTube,
            title: 'IAQ Testing',
            description: 'Our Free Air Check and comprehensive indoor air quality testing services identify pollutants, allergens, and contaminants affecting your home\'s air quality.',
            benefits: [
                'Identifies air quality issues',
                'Tests for mold and allergens',
                'Measures humidity levels',
                'Detects VOCs and pollutants',
                'Provides actionable solutions'
            ],
            faqIds: ['q3', 'q4', 'q6'],
            relatedLinks: [
                { title: "Understand filter strategy →", path: "/blog/florida-air-filter-guide-merv-cadence/" },
                { title: "The Return Leak Problem", path: "/blog/return-duct-leak-attic-air/" },
                { title: "How NADCA Standards Protect Your Air", path: "/nadca-standards-air-quality-protection" },
            ],
            image: {
                src: "https://images.unsplash.com/photo-1576091160550-2173dba999ef",
                alt: "Asian American couple reviewing an IAQ report on a tablet with a friendly Vent Guys technician in their home."
            }
        }
    ];

    return (
        <>
            <Helmet>
                <title>Air Duct Cleaning Services - NADCA Certified | The Vent Guys</title>
                <meta name="description" content="Professional air duct cleaning, dryer vent cleaning, and IAQ testing in Brevard County, FL. NADCA-certified technicians. Book your service today!" />
            </Helmet>

            {/* Hero Section */}
            <section className="relative bg-gradient-to-br from-[#1B263B] to-[#2a3f5f] text-white py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                        className="text-center"
                    >
                        <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
                        <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                            Comprehensive indoor air quality solutions for healthier homes in Brevard County
                        </p>
                    </motion.div>
                </div>
            </section>

            {/* Services Detail Sections */}
            {services.map((service, index) => (
                <section key={index} className={`py-20 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5 }}
                        >
                            <div className="grid md:grid-cols-2 gap-12 items-start">
                                {/* Text Content */}
                                <div>
                                    <service.icon className="h-16 w-16 text-[#D7263D] mb-6" />
                                    <h2 className="text-3xl md:text-4xl font-bold text-[#1B263B] mb-4">{service.title}</h2>
                                    <p className="text-lg text-gray-700 mb-6">{service.description}</p>
                                    
                                    {service.title === 'Air Duct Cleaning' && (
                                    <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg mb-6">
                                        <p className="font-semibold text-blue-800">
                                        Our process adheres strictly to <Link to="/nadca-standards-air-quality-protection" className="font-bold text-blue-600 hover:underline">NADCA standards</Link>.
                                        <Link to="/nadca-standards-air-quality-protection" className="ml-2 font-bold text-blue-600 hover:underline inline-flex items-center">
                                            Learn what that means for you <ExternalLink className="ml-1 h-4 w-4" />
                                        </Link>
                                        </p>
                                    </div>
                                    )}

                                    <div className="mb-8">
                                        <h3 className="text-xl font-bold text-[#1B263B] mb-4">Benefits:</h3>
                                        <ul className="space-y-3">
                                            {service.benefits.map((benefit, i) => (
                                                <li key={i} className="flex items-start gap-3">
                                                    <CheckCircle className="h-6 w-6 text-[#4DA6FF] flex-shrink-0 mt-0.5" />
                                                    <span className="text-gray-700">{benefit}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>

                                    <Link to="/contact">
                                        <Button size="lg" className="bg-[#D7263D] hover:bg-[#b51f31] text-white">
                                            <Calendar className="mr-2 h-5 w-5" />
                                            Schedule Service
                                        </Button>
                                    </Link>
                                </div>
                                
                                {/* Image */}
                                <div>
                                    <div className="relative rounded-xl overflow-hidden shadow-xl">
                                        <img className="w-full h-auto aspect-[16/9] object-cover" alt={service.image.alt} src={service.image.src} />
                                        <div className="absolute top-4 left-4 bg-[#4DA6FF] text-white px-4 py-2 rounded-full text-sm font-semibold">Professional Process</div>
                                    </div>
                                </div>
                            </div>
                             {/* FAQ Section for the service */}
                            <ServiceFaqs ids={service.faqIds} />
                             {/* Related Reading */}
                            {service.relatedLinks.length > 0 && <RelatedReading links={service.relatedLinks} />}
                        </motion.div>
                    </div>
                </section>
            ))}

            {/* CTA Section */}
            <section className="py-20 bg-gradient-to-r from-[#1B263B] to-[#2a3f5f] text-white">
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <h2 className="text-3xl md:text-4xl font-bold mb-6">
                        Ready to Breathe Cleaner Air?
                    </h2>
                    <p className="text-xl text-gray-300 mb-8">
                        Schedule your professional service today and experience the difference NADCA-certified cleaning makes.
                    </p>
                    <Link to="/contact">
                        <Button size="lg" className="bg-[#D7263D] hover:bg-[#b51f31] text-white px-8 py-6 text-lg font-semibold">
                            <Calendar className="mr-2 h-5 w-5" />
                            Book Your Service
                        </Button>
                    </Link>
                </div>
            </section>
        </>
    );
};

export default Services;
