
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import Home from '@/pages/Home';
import About from '@/pages/About';
import Services from '@/pages/Services';
import Contact from '@/pages/Contact';
import Blog from '@/pages/Blog';
import Gallery from '@/pages/Gallery';
import Rockledge from '@/pages/Rockledge';
import MerrittIsland from '@/pages/MerrittIsland';
import NewSmyrnaBeach from '@/pages/NewSmyrnaBeach';
import Cocoa from '@/pages/Cocoa'; 
import Titusville from '@/pages/Titusville'; 
import Melbourne from '@/pages/Melbourne';
import Viera from '@/pages/Viera';
import Suntree from '@/pages/Suntree';
import PortStJohn from '@/pages/PortStJohn';
import ForContractors from '@/pages/ForContractors';
import PropertyManagers from '@/pages/PropertyManagers';
import MobileCtaBar from '@/components/MobileCtaBar';
import VendorPacket from '@/pages/VendorPacket';
import PrivacyPolicy from '@/pages/PrivacyPolicy';
import CrmLayout from '@/components/CrmLayout';
import CrmHome from '@/pages/crm/CrmHome';
import Inbox from '@/pages/crm/Inbox';
import Schedule from '@/pages/crm/Schedule';
import Customers from '@/pages/crm/Customers';
import MyMoney from '@/pages/crm/MyMoney';
import Payroll from '@/pages/crm/Payroll';
import Reporting from '@/pages/crm/Reporting';
import Marketing from '@/pages/crm/Marketing';
import CallConsole from '@/pages/crm/CallConsole';
import Pipeline from '@/pages/crm/Pipeline';
import Settings from '@/pages/crm/Settings';
import LegacyAdminPanel from '@/pages/crm/AdminPanel'; // Renamed to avoid conflict
import Metrics from '@/pages/crm/Metrics';
import ActionHub from '@/pages/crm/ActionHub';
import Pricebook from '@/pages/Pricebook';
import FloatingCallButton from '@/components/FloatingCallButton';
import { useToast } from '@/components/ui/use-toast';
import FloridaHumidityDuctContamination from '@/pages/blog/FloridaHumidityDuctContamination';
import DryerVentFireSafety from '@/pages/blog/DryerVentFireSafety';
import MechanicalHygieneVsDuctCleaning from '@/pages/blog/MechanicalHygieneVsDuctCleaning';
import FreeAirCheckPage from '@/pages/blog/FreeAirCheck';
import CleanAirCertified from '@/pages/blog/CleanAirCertified';
import NadcaStandards from '@/pages/blog/NadcaStandards';
import ReturnDuctLeak from '@/pages/blog/ReturnDuctLeak';
import FloridaFilterGuide from '@/pages/blog/FloridaFilterGuide';
import FaqPage from '@/pages/Faq';
import AdminDashboard from '@/pages/Admin';
import DiversityTracker from '@/components/DiversityTracker';
import ImageUploadForm from '@/components/ImageUploadForm';
import TestimonialManager from '@/components/TestimonialManager';
import ImageAssetManager from '@/components/ImageAssetManager';
import ThankYou from '@/pages/ThankYou';
import FreeAirCheck from '@/pages/FreeAirCheck';


const PlaceholderPage = ({ title }) => {
  const { toast } = useToast();
  React.useEffect(() => {
    toast({
      title: "🚧 Under Construction!",
      description: `The "${title}" page isn't built yet, but you can request it!`,
    });
  }, [title, toast]);

  return (
    <div className="container mx-auto py-20 text-center">
      <h1 className="text-4xl font-bold mb-4">{title}</h1>
      <p>This page is coming soon. Check back later!</p>
    </div>
  );
};

const CrmRoutes = () => (
    <CrmLayout>
        <Routes>
            <Route index element={<Navigate to="dashboard" replace />} />
            <Route path="dashboard" element={<CrmHome />} />
            <Route path="inbox" element={<Inbox />} />
            <Route path="schedule" element={<Schedule />} />
            <Route path="customers" element={<Customers />} />
            <Route path="money" element={<MyMoney />} />
            <Route path="payroll" element={<Payroll />} />
            <Route path="reporting" element={<Reporting />} />
            <Route path="marketing" element={<Marketing />} />
            <Route path="console" element={<CallConsole />} />
            <Route path="pipeline" element={<Pipeline />} />
            <Route path="action-hub" element={<ActionHub />} />
            <Route path="settings" element={<Settings />} />
            <Route path="admin" element={<LegacyAdminPanel />} />
            <Route path="metrics" element={<Metrics />} />
        </Routes>
    </CrmLayout>
);

const AdminRoutes = () => (
  <AdminDashboard>
    <Routes>
      <Route path="/" element={<p>Welcome to the Admin Dashboard!</p>} />
      <Route path="image-asset-manager" element={<ImageAssetManager />} />
      <Route path="image-diversity-tracker" element={<DiversityTracker />} />
      <Route path="upload-image" element={<ImageUploadForm />} />
      <Route path="testimonials" element={<TestimonialManager />} />
    </Routes>
  </AdminDashboard>
);


const AppContent = () => {
  const location = useLocation();
  const isCrmRoute = location.pathname.startsWith('/crm');
  const isAdminRoute = location.pathname.startsWith('/admin');
  const isThankYouRoute = location.pathname === '/thank-you';

  const shouldShowNavAndFooter = !isCrmRoute && !isAdminRoute && !isThankYouRoute;

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      {shouldShowNavAndFooter && <Navigation />}
      <main className={`flex-grow ${shouldShowNavAndFooter ? 'pb-20 lg:pb-0' : ''}`}>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/pricebook" element={<Pricebook />} />
          <Route path="/faq" element={<FaqPage />} />
          <Route path="/login" element={<Navigate to="/crm" replace />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/free-air-check" element={<FreeAirCheck />} />
          
          {/* Admin Dashboard Routes */}
          <Route path="/admin/*" element={<AdminRoutes />} />
          
          {/* Blog Post Routes */}
          <Route path="/florida-humidity-hidden-duct-contamination" element={<FloridaHumidityDuctContamination />} />
          <Route path="/dryer-vent-cleaning-fire-safety" element={<DryerVentFireSafety />} />
          <Route path="/mechanical-hygiene-vs-duct-cleaning" element={<MechanicalHygieneVsDuctCleaning />} />
          <Route path="/free-air-check-what-we-look-for" element={<FreeAirCheckPage />} />
          <Route path="/clean-air-certified-property-listings" element={<CleanAirCertified />} />
          <Route path="/nadca-standards-air-quality-protection" element={<NadcaStandards />} />
          <Route path="/blog/return-duct-leak-attic-air" element={<ReturnDuctLeak />} />
          <Route path="/blog/florida-air-filter-guide-merv-cadence" element={<FloridaFilterGuide />} />


          {/* CRM Routes */}
          <Route path="/crm/*" element={<CrmRoutes />} />

          {/* City Pages */}
          <Route path="/rockledge-air-duct-cleaning" element={<Rockledge />} />
          <Route path="/merritt-island-air-duct-cleaning" element={<MerrittIsland />} />
          <Route path="/new-smyrna-beach-air-duct-cleaning" element={<NewSmyrnaBeach />} />
          <Route path="/cocoa-air-duct-cleaning" element={<Cocoa />} /> 
          <Route path="/titusville-air-duct-cleaning" element={<Titusville />} />
          <Route path="/melbourne-air-duct-cleaning" element={<Melbourne />} />
          <Route path="/viera-air-duct-cleaning" element={<Viera />} />
          <Route path="/suntree-air-duct-cleaning" element={<Suntree />} />
          <Route path="/port-st-john-air-duct-cleaning" element={<PortStJohn />} />

          {/* Other Pages */}
          <Route path="/for-contractors" element={<ForContractors />} />
          <Route path="/for-property-managers" element={<PropertyManagers />} />
          <Route path="/vendor-packet" element={<VendorPacket />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          
          {/* Placeholder Routes */}
          <Route path="/terms-of-service" element={<PlaceholderPage title="Terms of Service" />} />
        </Routes>
      </main>
      {shouldShowNavAndFooter && <Footer />}
      {shouldShowNavAndFooter && <MobileCtaBar />}
      {shouldShowNavAndFooter && <FloatingCallButton />}
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
