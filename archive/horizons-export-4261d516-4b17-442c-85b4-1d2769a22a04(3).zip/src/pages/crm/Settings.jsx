import React, { useEffect, useState, useCallback } from "react";
import { supabase } from "@/lib/customSupabaseClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";

const AdminSettings = () => {
  const { toast } = useToast();
  const [cfg, setCfg] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const loadSettings = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('global_config').select('*');
    if (error) {
      toast({ variant: "destructive", title: "Failed to load settings", description: error.message });
    } else {
      const settingsObject = data.reduce((acc, { key, value }) => ({ ...acc, [key]: value }), {});
      setCfg(settingsObject);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  function set(key, value) {
    setCfg(prev => ({ ...prev, [key]: value }));
  }

  async function save() {
    setSaving(true);
    const updates = Object.keys(cfg).map(key => ({ key, value: cfg[key] }));

    const { error } = await supabase
      .from('global_config')
      .upsert(updates, { onConflict: 'key' });

    if (error) {
      toast({ variant: "destructive", title: "Save failed", description: error.message });
    } else {
      toast({ title: "Success!", description: "Settings have been saved." });
      loadSettings(); // Reload to confirm
    }
    setSaving(false);
  }

  if (loading) return <div className="p-8 text-center">Loading settings...</div>;

  return (
    <div className="p-4 md:p-6 space-y-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-800">Business Settings</h1>
      
      <Section title="Brand & Contact">
        <Field label="Business Phone">
          <Input value={cfg.BUSINESS_PHONE_NUMBER || ""} onChange={e => set("BUSINESS_PHONE_NUMBER", e.target.value)} />
        </Field>
        <Field label="Support Email">
          <Input type="email" value={cfg.SUPPORT_EMAIL || ""} onChange={e => set("SUPPORT_EMAIL", e.target.value)} />
        </Field>
      </Section>

      <Section title="Service Settings">
        <Field label="Service ZIP Codes (comma-separated)">
          <Input value={(cfg.GLOBAL_SERVICE_ZIP_CODES || []).join(", ")} onChange={e => set("GLOBAL_SERVICE_ZIP_CODES", e.target.value.split(",").map(s => s.trim()).filter(Boolean))} />
        </Field>
        <Field label="Hours of Operation (JSON)">
          <Textarea className="h-36 font-mono text-sm" value={JSON.stringify(cfg.GLOBAL_HOURS_OF_OPERATION || {}, null, 2)}
            onChange={e => {
              try {
                const parsed = JSON.parse(e.target.value);
                set("GLOBAL_HOURS_OF_OPERATION", parsed);
              } catch { /* ignore invalid json */ }
            }} />
        </Field>
      </Section>

      <Section title="External Links">
        <Field label="Google Review Link">
          <Input value={cfg.REVIEW_LINK_GOOGLE || ""} onChange={e => set("REVIEW_LINK_GOOGLE", e.target.value)} />
        </Field>
        <Field label="Calendly (General)">
          <Input value={cfg.CALENDLY_LINK_GENERAL || ""} onChange={e => set("CALENDLY_LINK_GENERAL", e.target.value)} />
        </Field>
      </Section>

      <Section title="Compliance">
        <Field label="NADCA Cert URL">
          <Input value={cfg.NADCA_CERT_URL || ""} onChange={e => set("NADCA_CERT_URL", e.target.value)} />
        </Field>
        <Field label="Insurance Expiry (YYYY-MM-DD)">
          <Input type="date" value={cfg.INSURANCE_EXPIRY_DATE || ""} onChange={e => set("INSURANCE_EXPIRY_DATE", e.target.value)} />
        </Field>
      </Section>

      <div className="flex justify-end pt-4">
        <Button size="lg" onClick={save} disabled={saving}>
          {saving ? "Saving..." : "Save All Settings"}
        </Button>
      </div>
    </div>
  );
};

const Section = ({ title, children }) => (
  <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
    <h2 className="text-xl font-semibold mb-4 text-gray-700">{title}</h2>
    <div className="space-y-4">{children}</div>
  </div>
);

const Field = ({ label, children }) => (
  <div>
    <label className="block text-sm font-medium text-gray-600 mb-1">{label}</label>
    {children}
  </div>
);

export default AdminSettings;