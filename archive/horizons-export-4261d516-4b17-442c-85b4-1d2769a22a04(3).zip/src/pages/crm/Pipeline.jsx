import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';
import { User, MoreVertical, Search } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { invoke } from '@/lib/api';

// --- Component: Individual Card (The Lead) ---
function LeadCard({ lead, onDragStart, onMoveRequest }) {
  const getPqiColor = (pqi) => {
    if (pqi >= 80) return 'bg-green-500 border-green-600';
    if (pqi >= 60) return 'bg-yellow-500 border-yellow-600';
    return 'bg-red-500 border-red-600';
  };
  
  const scoreClass = getPqiColor(lead.pqi);

  return (
    <Card 
      className="mb-3 bg-white touch-none shadow-sm hover:shadow-lg transition-shadow cursor-grab border-l-4 border-blue-500 group"
      draggable
      onDragStart={(e) => onDragStart(e, lead.lead_id, lead.pipeline_stage)}
    >
      <CardContent className="p-3">
        <div className="flex justify-between items-start">
            <h4 className="font-semibold text-sm text-gray-800 truncate pr-2">{lead.company || `${lead.first_name || ''} ${lead.last_name || ''}`}</h4>
            <span className={`px-2 py-0.5 text-xs font-bold rounded-full text-white ${scoreClass}`}>
              {lead.pqi}
            </span>
        </div>
        <div className="flex items-center text-xs text-gray-500 mt-1 space-x-2">
            <div className="flex items-center"><User size={12} className="mr-1" />{lead.persona}</div>
        </div>
      </CardContent>
      <CardFooter className="p-2 bg-gray-50/50 flex justify-between items-center text-xs">
         <span className="text-gray-400">{lead.days_since_last_activity} days ago</span>
         <Button variant="ghost" size="sm" className="h-6 px-2 text-gray-500 group-hover:opacity-100 opacity-0 transition-opacity" onClick={() => onMoveRequest(lead.lead_id, lead.pipeline_stage)}>Move</Button>
      </CardFooter>
    </Card>
  );
}

// --- Component: Pipeline Column ---
function PipelineColumn({ column, leads, onDragOver, onDrop, onDragStart, onMoveRequest }) {
  return (
    <div 
      className="min-w-[300px] flex-shrink-0 bg-gray-100 rounded-lg h-full flex flex-col"
      onDragOver={onDragOver}
      onDrop={(e) => onDrop(e, column.code)}
    >
      <h3 className="text-sm font-bold text-gray-600 p-3 border-b tracking-wider uppercase sticky top-0 bg-gray-100 z-10">{column.name} <span className="text-gray-400 font-medium ml-1">{leads.length}</span></h3>
      <div className="flex-1 p-2 overflow-y-auto">
        {leads.map(lead => (
          <LeadCard key={lead.lead_id} lead={lead} onDragStart={onDragStart} onMoveRequest={onMoveRequest} />
        ))}
      </div>
    </div>
  );
}

// --- Main Component: Kanban Board ---
export default function Pipeline() {
  const [pipelineData, setPipelineData] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [personaFilter, setPersonaFilter] = useState('all');
  const [moveModalState, setMoveModalState] = useState({ isOpen: false, leadId: null, fromStage: null, toStage: '' });

  const fetchPipeline = useCallback(async () => {
    setLoading(true);
    const { ok, data, error } = await invoke('pipeline-list');
    if (ok) {
        setPipelineData(data.columns);
    } else {
        toast({ variant: 'destructive', title: 'Fetch failed', description: error });
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchPipeline();
  }, [fetchPipeline]);

  const onDragStart = (e, leadId, currentStage) => {
    e.dataTransfer.setData("lead_id", leadId);
    e.dataTransfer.setData("from_stage", currentStage);
  };

  const onDragOver = (e) => e.preventDefault();

  const handleMove = async (leadId, fromStage, toStage) => {
    if (!leadId || fromStage === toStage) return;

    const originalData = JSON.parse(JSON.stringify(pipelineData));
    setPipelineData(prev => {
      const next = JSON.parse(JSON.stringify(prev));
      let movedLead = null;
      const fromCol = next.find(c => c.code === fromStage);
      if (fromCol) {
        const leadIndex = fromCol.leads.findIndex(l => l.lead_id === leadId);
        if (leadIndex > -1) {
          [movedLead] = fromCol.leads.splice(leadIndex, 1);
        }
      }
      if (movedLead) {
        movedLead.pipeline_stage = toStage;
        const toCol = next.find(c => c.code === toStage);
        if (toCol) toCol.leads.unshift(movedLead);
      }
      return next;
    });

    const { ok, error } = await invoke('pipeline-transition', {
      body: JSON.stringify({ lead_id: leadId, to_stage: toStage })
    });

    if (!ok) {
      toast({ variant: 'destructive', title: 'Move Failed', description: error });
      setPipelineData(originalData);
    } else {
       toast({ title: 'Lead Moved!', description: `Successfully moved lead to "${toStage}".` });
    }
  };
  
  const onDrop = (e, toStage) => {
    e.preventDefault();
    const leadId = e.dataTransfer.getData("lead_id");
    const fromStage = e.dataTransfer.getData("from_stage");
    handleMove(leadId, fromStage, toStage);
  };

  const onMoveRequest = (leadId, fromStage) => {
    setMoveModalState({ isOpen: true, leadId, fromStage, toStage: '' });
  };
  
  const handleMoveConfirm = () => {
    const { leadId, fromStage, toStage } = moveModalState;
    if (toStage) {
        handleMove(leadId, fromStage, toStage);
    }
    setMoveModalState({ isOpen: false, leadId: null, fromStage: null, toStage: '' });
  };
  
  const filteredPipelineData = useMemo(() => {
    if (!searchTerm && personaFilter === 'all') return pipelineData;
    return pipelineData.map(column => ({
      ...column,
      leads: column.leads.filter(lead => {
        const matchesPersona = personaFilter === 'all' || lead.persona === personaFilter;
        const name = lead.company || `${lead.first_name} ${lead.last_name}`;
        const matchesSearch = !searchTerm || name.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesPersona && matchesSearch;
      })
    }));
  }, [pipelineData, searchTerm, personaFilter]);
  
  const availablePersonas = useMemo(() => {
    const allPersonas = new Set(pipelineData.flatMap(c => c.leads.map(l => l.persona)));
    return ['all', ...Array.from(allPersonas)];
  }, [pipelineData]);


  if (loading) return <div className="flex justify-center items-center h-full"><div className="text-center p-8">Loading Pipeline...</div></div>;

  return (
    <>
      <Helmet><title>Sales Pipeline | TVG CRM</title></Helmet>
      <div className="flex flex-col h-full bg-gray-50 text-gray-900">
        <header className="p-4 border-b bg-white/80 backdrop-blur-sm sticky top-0 z-20">
            <h1 className="text-2xl font-bold text-gray-800">Sales Pipeline</h1>
            <div className="mt-2 flex gap-4">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input placeholder="Search by name or company..." className="pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                </div>
                <Select value={personaFilter} onValueChange={setPersonaFilter}>
                    <SelectTrigger className="w-[200px]">
                        <SelectValue placeholder="Filter by persona..." />
                    </SelectTrigger>
                    <SelectContent>
                        {availablePersonas.map(p => <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
        </header>
        <div className="flex-1 p-4 overflow-x-auto">
          <div className="flex flex-row space-x-4 h-full">
            {filteredPipelineData.map(column => (
              <PipelineColumn 
                key={column.code}
                column={column}
                leads={column.leads}
                onDragStart={onDragStart}
                onDragOver={onDragOver}
                onDrop={onDrop}
                onMoveRequest={onMoveRequest}
              />
            ))}
          </div>
        </div>
      </div>
      
      {moveModalState.isOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
            <div className="bg-white rounded-lg p-6 shadow-xl w-full max-w-sm">
                <h3 className="font-bold text-lg mb-4">Move Lead</h3>
                <p className="text-sm text-gray-600 mb-2">Move lead from <strong>{moveModalState.fromStage}</strong> to:</p>
                <Select onValueChange={(value) => setMoveModalState(s => ({ ...s, toStage: value }))}>
                    <SelectTrigger><SelectValue placeholder="Select new stage..." /></SelectTrigger>
                    <SelectContent>
                        {pipelineData
                          .filter(c => c.code !== moveModalState.fromStage)
                          .map(c => <SelectItem key={c.code} value={c.code}>{c.name}</SelectItem>)
                        }
                    </SelectContent>
                </Select>
                <div className="mt-6 flex justify-end gap-3">
                    <Button variant="ghost" onClick={() => setMoveModalState({ isOpen: false, leadId: null, fromStage: null, toStage: '' })}>Cancel</Button>
                    <Button onClick={handleMoveConfirm} disabled={!moveModalState.toStage}>Confirm Move</Button>
                </div>
            </div>
        </div>
      )}
    </>
  );
}