
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Send, Loader2 } from 'lucide-react';
import { LEAD_CAPTURE_API_URL } from '@/lib/constants';

export default function LeadCaptureForm({
  formType = 'free-air-check',
  onSuccess = () => {}
}) {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null);
  const [message, setMessage] = useState('');
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    phone: '',
    email: '',
    message: '',
    consent_marketing: false,
  });

  const navigate = useNavigate();

  const formTypeConfig = {
    'free-air-check': {
      service_type: 'IAQ Check',
      source_kind: 'WEBSITE',
      source_detail: 'Free Air Check Form',
    },
    'contact': {
      service_type: 'Other',
      source_kind: 'WEBSITE',
      source_detail: 'Contact Form',
    },
    'audit-booking': {
      service_type: 'IAQ Audit',
      source_kind: 'WEBSITE',
      source_detail: 'Paid Audit Booking',
    },
  };

  const config = formTypeConfig[formType] || formTypeConfig['free-air-check'];

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus(null);
    setMessage('');

    try {
      if (!formData.first_name.trim()) throw new Error('First name is required');
      if (!formData.phone.trim()) throw new Error('Phone number is required');

      const payload = {
        first_name: formData.first_name.trim(),
        last_name: formData.last_name.trim() || undefined,
        phone: formData.phone.trim(),
        email: formData.email.trim() || undefined,
        message: formData.message.trim() || undefined,
        service_type: config.service_type,
        customer_type: 'RESIDENTIAL',
        source_kind: config.source_kind,
        source_detail: config.source_detail,
        landing_page_url: window.location.href,
        utm_source: new URLSearchParams(window.location.search).get('utm_source') || undefined,
        utm_medium: new URLSearchParams(window.location.search).get('utm_medium') || undefined,
        utm_campaign: new URLSearchParams(window.location.search).get('utm_campaign') || undefined,
        utm_term: new URLSearchParams(window.location.search).get('utm_term') || undefined,
        utm_content: new URLSearchParams(window.location.search).get('utm_content') || undefined,
        gclid: new URLSearchParams(window.location.search).get('gclid') || undefined,
        consent_marketing: formData.consent_marketing,
      };

      const response = await fetch(LEAD_CAPTURE_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || `HTTP ${response.status}`);
      }

      setStatus('success');
      setMessage('✓ Thank you! We received your request and will contact you shortly.');
      setFormData({
        first_name: '',
        last_name: '',
        phone: '',
        email: '',
        message: '',
        consent_marketing: false,
      });
      onSuccess(result);
      
      setTimeout(() => {
        navigate('/thank-you');
      }, 1000);

    } catch (err) {
      console.error('Form submission error:', err);
      setStatus('error');
      setMessage(`✗ ${err.message || 'Something went wrong. Please try again.'}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="first_name">First Name *</Label>
          <Input id="first_name" type="text" name="first_name" value={formData.first_name} onChange={handleChange} required placeholder="John" disabled={loading} />
        </div>
        <div>
          <Label htmlFor="last_name">Last Name</Label>
          <Input id="last_name" type="text" name="last_name" value={formData.last_name} onChange={handleChange} placeholder="Doe" disabled={loading} />
        </div>
      </div>
      <div>
        <Label htmlFor="phone">Phone *</Label>
        <Input id="phone" type="tel" name="phone" value={formData.phone} onChange={handleChange} required placeholder="(321) 555-1234" disabled={loading} />
      </div>
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" type="email" name="email" value={formData.email} onChange={handleChange} placeholder="john@example.com" disabled={loading} />
      </div>
      <div>
        <Label htmlFor="message">Message</Label>
        <Textarea id="message" name="message" value={formData.message} onChange={handleChange} rows={3} placeholder="Tell us about your air quality concerns..." disabled={loading} />
      </div>
      <div className="flex items-center space-x-2">
        <Checkbox id="consent_marketing" name="consent_marketing" checked={formData.consent_marketing} onCheckedChange={(checked) => setFormData(p => ({...p, consent_marketing: checked}))} disabled={loading} />
        <Label htmlFor="consent_marketing" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
            I consent to marketing communications
        </Label>
      </div>

      {status && (
        <div className={`p-3 rounded-md text-sm font-medium ${ status === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }`}>
          {message}
        </div>
      )}

      <Button type="submit" size="lg" className="w-full bg-[#D7263D] hover:bg-[#b51f31] text-white" disabled={loading}>
        {loading ? <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Sending...</> : <><Send className="mr-2 h-5 w-5" /> Request My Free Check</>}
      </Button>
    </form>
  );
}
