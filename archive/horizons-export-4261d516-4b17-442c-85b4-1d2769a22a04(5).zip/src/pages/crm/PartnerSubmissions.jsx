
import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, RefreshCw, Search, Eye, Mail, Download } from 'lucide-react';
import { format } from 'date-fns';

const STATUS_COLORS = {
  sent: 'bg-green-100 text-green-800 border-green-200',
  pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  failed: 'bg-red-100 text-red-800 border-red-200',
  scheduled: 'bg-blue-100 text-blue-800 border-blue-200'
};

const PartnerSubmissions = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [submissions, setSubmissions] = useState([]);
  const [selectedSubmission, setSelectedSubmission] = useState(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [resendingId, setResendingId] = useState(null);

  // Filters
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState('30'); // days

  useEffect(() => {
    fetchSubmissions();
  }, [dateRange]);

  const fetchSubmissions = async () => {
    setLoading(true);
    
    // Calculate date range
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(dateRange));

    let query = supabase
      .from('partner_registrations')
      .select('*')
      .gte('created_at', startDate.toISOString())
      .order('created_at', { ascending: false });

    const { data, error } = await query;

    if (error) {
      toast({ variant: 'destructive', title: 'Error fetching data', description: error.message });
    } else {
      setSubmissions(data);
    }
    setLoading(false);
  };

  const handleResendEmail = async (submission) => {
    setResendingId(submission.id);
    try {
      // Call the edge function
      const { error } = await supabase.functions.invoke('send-partner-email', {
        body: JSON.stringify({
          name: submission.contact_name,
          email: submission.email,
          role: submission.title || submission.partner_type, // Fallback if title is empty
          headache: submission.biggest_headache,
          company: submission.organization_name
        })
      });

      if (error) throw error;

      // Update DB status
      await supabase.from('partner_registrations')
        .update({ 
          welcome_email_status: 'sent', 
          welcome_email_sent_at: new Date().toISOString() 
        })
        .eq('id', submission.id);

      // Update local state
      setSubmissions(prev => prev.map(s => 
        s.id === submission.id 
          ? { ...s, welcome_email_status: 'sent', welcome_email_sent_at: new Date().toISOString() } 
          : s
      ));

      toast({ title: "Email Resent", description: `Welcome email sent to ${submission.email}` });

    } catch (err) {
      console.error(err);
      toast({ variant: "destructive", title: "Failed to send", description: err.message });
      
      // Update DB status to failed
      await supabase.from('partner_registrations')
        .update({ welcome_email_status: 'failed' })
        .eq('id', submission.id);
        
      setSubmissions(prev => prev.map(s => s.id === submission.id ? { ...s, welcome_email_status: 'failed' } : s));
    } finally {
      setResendingId(null);
    }
  };

  const filteredSubmissions = useMemo(() => {
    return submissions.filter(sub => {
      // Logic: Check if role filter matches partner_type (exact) OR title (partial)
      // The filter values now match standard DB partner_type values
      const matchesRole = roleFilter === 'ALL' || 
                          (sub.partner_type && sub.partner_type.toLowerCase() === roleFilter.toLowerCase()) || 
                          (sub.title && sub.title.toLowerCase().includes(roleFilter.toLowerCase().replace('_', ' ')));
      
      const searchString = `${sub.contact_name} ${sub.organization_name} ${sub.email}`.toLowerCase();
      const matchesSearch = searchString.includes(searchTerm.toLowerCase());
      return matchesRole && matchesSearch;
    });
  }, [submissions, roleFilter, searchTerm]);

  const openDetails = (sub) => {
    setSelectedSubmission(sub);
    setIsDetailOpen(true);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      <Helmet>
        <title>Partner Submissions | CRM</title>
      </Helmet>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Partner Submissions</h1>
          <p className="text-gray-500">Manage incoming partnership requests and lead capture.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={fetchSubmissions} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </Button>
          <Button variant="secondary">
            <Download className="h-4 w-4 mr-2" /> Export CSV
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4 flex flex-col md:flex-row gap-4 items-end md:items-center">
          <div className="w-full md:w-1/3 space-y-1">
            <label className="text-xs font-medium text-gray-500">Search</label>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Name, Company, Email..." 
                className="pl-8" 
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="w-full md:w-1/4 space-y-1">
             <label className="text-xs font-medium text-gray-500">Filter by Role</label>
             <Select value={roleFilter} onValueChange={setRoleFilter}>
               <SelectTrigger><SelectValue placeholder="All Roles" /></SelectTrigger>
               <SelectContent>
                 <SelectItem value="ALL">All Roles</SelectItem>
                 {/* Values updated to match partner_type in DB */}
                 <SelectItem value="property_manager">Property Manager</SelectItem>
                 <SelectItem value="realtor">Realtor/Broker</SelectItem>
                 <SelectItem value="hoa">HOA Board</SelectItem>
                 <SelectItem value="b2b">B2B / Contractor</SelectItem>
                 <SelectItem value="government">Government</SelectItem>
               </SelectContent>
             </Select>
          </div>

          <div className="w-full md:w-1/4 space-y-1">
             <label className="text-xs font-medium text-gray-500">Date Range</label>
             <Select value={dateRange} onValueChange={setDateRange}>
               <SelectTrigger><SelectValue placeholder="Select Range" /></SelectTrigger>
               <SelectContent>
                 <SelectItem value="7">Last 7 Days</SelectItem>
                 <SelectItem value="30">Last 30 Days</SelectItem>
                 <SelectItem value="90">Last 90 Days</SelectItem>
                 <SelectItem value="365">All Time</SelectItem>
               </SelectContent>
             </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <div className="bg-white rounded-lg border shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead>Contact</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Properties / Units</TableHead>
              <TableHead>Biggest Headache</TableHead>
              <TableHead>Submission Date</TableHead>
              <TableHead>Welcome Email</TableHead>
              <TableHead>Follow-up</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={8} className="h-32 text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                  <span className="text-sm text-gray-500 mt-2 block">Loading submissions...</span>
                </TableCell>
              </TableRow>
            ) : filteredSubmissions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="h-32 text-center text-gray-500">
                  No submissions found for the selected filters.
                </TableCell>
              </TableRow>
            ) : (
              filteredSubmissions.map((sub) => (
                <TableRow key={sub.id} className="hover:bg-gray-50/50">
                  <TableCell>
                    <div className="font-medium text-gray-900">{sub.contact_name}</div>
                    <div className="text-sm text-gray-500">{sub.organization_name}</div>
                    <div className="text-xs text-gray-400">{sub.email}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-slate-50">
                      {sub.title || sub.partner_type}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {sub.num_units || sub.doors_managed || sub.num_facilities || '-'}
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate" title={sub.biggest_headache}>
                    {sub.biggest_headache || <span className="text-gray-300 italic">N/A</span>}
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {format(new Date(sub.created_at), 'MMM d, yyyy')}
                    </div>
                    <div className="text-xs text-gray-400">
                      {format(new Date(sub.created_at), 'h:mm a')}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={STATUS_COLORS[sub.welcome_email_status || 'pending']}>
                      {sub.welcome_email_status === 'sent' ? 'Sent' : sub.welcome_email_status || 'Pending'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={STATUS_COLORS[sub.followup_email_status || 'pending']}>
                      {sub.followup_email_status || 'Pending'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => handleResendEmail(sub)}
                        disabled={resendingId === sub.id}
                        title="Resend Welcome Email"
                      >
                        {resendingId === sub.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4 text-gray-500 hover:text-blue-600" />}
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => openDetails(sub)}
                        title="View Full Details"
                      >
                        <Eye className="h-4 w-4 text-gray-500 hover:text-gray-900" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Details Sheet (Modal) */}
      {isDetailOpen && selectedSubmission && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={() => setIsDetailOpen(false)}></div>
          
          {/* Panel */}
          <div className="relative w-full max-w-md bg-white h-full shadow-2xl overflow-y-auto p-6 animate-in slide-in-from-right duration-300">
             <div className="flex justify-between items-start mb-6">
                <div>
                    <h2 className="text-xl font-bold text-gray-900">Submission Details</h2>
                    <p className="text-sm text-gray-500">ID: {selectedSubmission.id.slice(0,8)}</p>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setIsDetailOpen(false)}>Close</Button>
             </div>

             <div className="space-y-6">
                <section>
                    <h3 className="font-semibold text-gray-900 border-b pb-2 mb-3">Contact Info</h3>
                    <DetailRow label="Name" value={selectedSubmission.contact_name} />
                    <DetailRow label="Email" value={selectedSubmission.email} />
                    <DetailRow label="Phone" value={selectedSubmission.mobile_phone} />
                    <DetailRow label="Organization" value={selectedSubmission.organization_name} />
                    <DetailRow label="Role/Title" value={selectedSubmission.title} />
                    <DetailRow label="Address" value={selectedSubmission.address} />
                </section>

                <section>
                    <h3 className="font-semibold text-gray-900 border-b pb-2 mb-3">Portfolio Data</h3>
                    <DetailRow label="Partner Type" value={selectedSubmission.partner_type} />
                    <DetailRow label="Units/Doors" value={selectedSubmission.num_units || selectedSubmission.doors_managed || selectedSubmission.num_facilities} />
                    <DetailRow label="Monthly Turnovers" value={selectedSubmission.monthly_turnovers} />
                    <DetailRow label="Work Order System" value={selectedSubmission.work_order_system} />
                    <DetailRow label="Portfolio Type" value={selectedSubmission.portfolio_type} />
                </section>

                <section>
                    <h3 className="font-semibold text-gray-900 border-b pb-2 mb-3">Key Insights</h3>
                    <div className="mb-3">
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Biggest Headache</label>
                        <p className="text-sm text-gray-900 mt-1 bg-red-50 p-2 rounded border border-red-100">
                            {selectedSubmission.biggest_headache || "Not provided"}
                        </p>
                    </div>
                    <DetailRow label="Interest Reasons" value={selectedSubmission.interest_reasons ? JSON.stringify(selectedSubmission.interest_reasons) : ''} />
                    <DetailRow label="Program Usage" value={selectedSubmission.program_use ? JSON.stringify(selectedSubmission.program_use) : ''} />
                </section>
                
                <section>
                    <h3 className="font-semibold text-gray-900 border-b pb-2 mb-3">System Status</h3>
                    <DetailRow label="Submission Date" value={new Date(selectedSubmission.created_at).toLocaleString()} />
                    <DetailRow label="Welcome Email" value={selectedSubmission.welcome_email_status} />
                    <DetailRow label="Sent At" value={selectedSubmission.welcome_email_sent_at ? new Date(selectedSubmission.welcome_email_sent_at).toLocaleString() : '-'} />
                </section>

                <div className="pt-6 flex gap-3">
                    <Button className="flex-1" onClick={() => handleResendEmail(selectedSubmission)} disabled={resendingId === selectedSubmission.id}>
                         {resendingId === selectedSubmission.id ? <Loader2 className="animate-spin mr-2 h-4 w-4"/> : <Mail className="mr-2 h-4 w-4" />}
                         Resend Welcome Email
                    </Button>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

const DetailRow = ({ label, value }) => {
    if (!value) return null;
    return (
        <div className="mb-2">
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{label}</label>
            <p className="text-sm text-gray-900">{value.toString()}</p>
        </div>
    );
}

export default PartnerSubmissions;
