import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ThankYou = () => {
  return (
    <>
      <Helmet>
        <title>Thank You! | The Vent Guys</title>
        <meta name="description" content="Thank you for contacting The Vent Guys. We'll be in touch shortly." />
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="max-w-md w-full space-y-8 text-center bg-white p-10 rounded-xl shadow-lg"
        >
          <div>
            <CheckCircle className="mx-auto h-16 w-16 text-green-500" />
            <h1 className="mt-6 text-3xl font-extrabold text-[#1B263B]">
              Thank You for Your Request!
            </h1>
            <p className="mt-4 text-lg text-gray-600">
              We've received your submission and a member of our team will be in touch with you shortly to discuss the next steps.
            </p>
          </div>
          
          <div className="mt-6">
            <p className="text-gray-600">
              In the meantime, feel free to explore more about our services or read our latest articles on indoor air quality.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
            <Link to="/services">
              <Button variant="outline" className="w-full sm:w-auto">
                Explore Services
              </Button>
            </Link>
            <Link to="/">
              <Button className="w-full sm:w-auto bg-[#D7263D] hover:bg-[#b51f31]">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default ThankYou;