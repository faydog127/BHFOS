
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Award, CheckCircle, ShieldCheck, Users, Home as HomeIcon, Building2, FileCheck, Hammer, Building, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PartnerLeadForm from '@/components/PartnerLeadForm';

const PartnersLanding = () => {
  const handleScrollToForm = (e) => {
    e.preventDefault();
    document.getElementById('partner-form-section').scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Helmet>
        <title>The Vent Guys | Partner with Health & Safety Pros</title>
        <meta name="description" content="Partner with The Vent Guys. Certified air system hygiene for Realtors, Property Managers, and HOAs in Brevard County." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative bg-[#1B263B] text-white py-20 md:py-32 overflow-hidden">
        {/* Abstract Background Pattern */}
        <div className="absolute inset-0 opacity-10 pointer-events-none">
            <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <path d="M0 100 C 20 0 50 0 100 100 Z" fill="white" />
            </svg>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }} 
              animate={{ opacity: 1, x: 0 }} 
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/50 border border-blue-700 text-blue-200 text-sm font-semibold mb-6">
                 <ShieldCheck className="w-4 h-4" /> B2B & Government Certified Partner
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight font-oswald">
                Partner With The Vent Guys <span className="text-[#D7263D]">Health & Safety Team</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Clean air isn't a "nice to have" anymore—it's a liability shield, a tenant retention tool, and a critical health standard. We help professionals protect their assets with NADCA-certified mechanical hygiene.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button onClick={handleScrollToForm} size="lg" className="bg-[#D7263D] hover:bg-[#b51f31] text-white px-8 py-6 text-lg font-bold shadow-xl hover:shadow-2xl transition-all">
                  Request Partner Info Pack
                </Button>
                <Link to="/contact">
                  <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-[#1B263B] px-8 py-6 text-lg font-bold transition-all w-full sm:w-auto">
                    Book a 15-Minute Call
                  </Button>
                </Link>
              </div>
            </motion.div>
            
            {/* Hero Image / Visual */}
            <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative hidden md:block"
            >
                <div className="absolute -inset-4 bg-[#D7263D] rounded-2xl opacity-20 blur-lg"></div>
                <img 
                    src="https://images.unsplash.com/photo-1574333313713-2574ebc53d29?auto=format&fit=crop&q=80" 
                    alt="Professional inspecting air duct system in commercial building" 
                    className="relative rounded-2xl shadow-2xl border-4 border-white/10"
                />
                <div className="absolute -bottom-6 -left-6 bg-white text-[#1B263B] p-4 rounded-xl shadow-xl flex items-center gap-4">
                    <div className="bg-green-100 p-2 rounded-full">
                        <CheckCircle className="w-8 h-8 text-green-600" />
                    </div>
                    <div>
                        <p className="font-bold text-lg">NADCA Certified</p>
                        <p className="text-sm text-gray-600">Compliance Verified</p>
                    </div>
                </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Who We Partner With Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1B263B] font-oswald">Who We Partner With</h2>
            <p className="text-xl text-gray-600 mt-4 max-w-2xl mx-auto">Specialized programs designed for the unique needs of your industry.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Card 1: Realtors */}
            <motion.div 
                whileHover={{ y: -5 }}
                className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden flex flex-col"
            >
                <div className="h-2 bg-[#D7263D]"></div>
                <div className="p-8 flex-grow flex flex-col">
                    <div className="w-14 h-14 bg-red-50 rounded-lg flex items-center justify-center mb-6">
                        <HomeIcon className="w-7 h-7 text-[#D7263D]" />
                    </div>
                    <h3 className="text-2xl font-bold text-[#1B263B] mb-3 font-oswald">Realtors & Brokers</h3>
                    <p className="text-gray-600 mb-6 font-medium">
                        Stop deals from falling apart over mold fears. We turn IAQ objections into certified selling points.
                    </p>
                    <ul className="space-y-3 mb-8 flex-grow">
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>Priority scheduling for closing deadlines.</span>
                        </li>
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>White-label inspection response reports.</span>
                        </li>
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>Exclusive 'Clean Air Certified' listing badge.</span>
                        </li>
                    </ul>
                    <Link to="/partners/realtor" className="mt-auto">
                        <Button variant="outline" className="w-full border-[#D7263D] text-[#D7263D] hover:bg-[#D7263D] hover:text-white font-bold">
                            Get Realtor Partner Kit
                        </Button>
                    </Link>
                </div>
            </motion.div>

            {/* Card 2: Property Managers */}
            <motion.div 
                whileHover={{ y: -5 }}
                className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden flex flex-col"
            >
                <div className="h-2 bg-[#1B263B]"></div>
                <div className="p-8 flex-grow flex flex-col">
                    <div className="w-14 h-14 bg-blue-50 rounded-lg flex items-center justify-center mb-6">
                        <Building2 className="w-7 h-7 text-[#1B263B]" />
                    </div>
                    <h3 className="text-2xl font-bold text-[#1B263B] mb-3 font-oswald">Property Managers</h3>
                    <p className="text-gray-600 mb-6 font-medium">
                        Turn units faster and stop dryer fire risks. We handle the dirty work so you can focus on leasing.
                    </p>
                    <ul className="space-y-3 mb-8 flex-grow">
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>Volume pricing for 50+ unit portfolios.</span>
                        </li>
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>Automated dryer vent compliance logs.</span>
                        </li>
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>Tenant education materials included.</span>
                        </li>
                    </ul>
                    <Link to="/partners/property-manager" className="mt-auto">
                        <Button variant="outline" className="w-full border-[#1B263B] text-[#1B263B] hover:bg-[#1B263B] hover:text-white font-bold">
                            Get Management Proposal
                        </Button>
                    </Link>
                </div>
            </motion.div>

            {/* Card 3: HOA */}
            <motion.div 
                whileHover={{ y: -5 }}
                className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden flex flex-col"
            >
                <div className="h-2 bg-emerald-600"></div>
                <div className="p-8 flex-grow flex flex-col">
                    <div className="w-14 h-14 bg-emerald-50 rounded-lg flex items-center justify-center mb-6">
                        <Users className="w-7 h-7 text-emerald-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-[#1B263B] mb-3 font-oswald">HOA & Condo Boards</h3>
                    <p className="text-gray-600 mb-6 font-medium">
                        Protect your community's insurance and safety. Reduce premiums with verified hygiene programs.
                    </p>
                    <ul className="space-y-3 mb-8 flex-grow">
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>Bulk coordination for multi-unit buildings.</span>
                        </li>
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>Fire marshal compliance reporting.</span>
                        </li>
                        <li className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>Reduced group rates for residents.</span>
                        </li>
                    </ul>
                    <Link to="/partners/hoa" className="mt-auto">
                        <Button variant="outline" className="w-full border-emerald-600 text-emerald-600 hover:bg-emerald-600 hover:text-white font-bold">
                            Request Board Packet
                        </Button>
                    </Link>
                </div>
            </motion.div>
          </div>

          {/* Secondary Partners Row */}
          <div className="mt-12 flex flex-col md:flex-row gap-8 justify-center items-center">
            <Link to="/partners/b2b" className="group flex items-center gap-4 bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100 w-full md:w-auto">
                <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center group-hover:bg-orange-100 transition-colors">
                    <Hammer className="w-6 h-6 text-orange-500" />
                </div>
                <div>
                    <h3 className="font-bold text-lg text-gray-900">Contractors (B2B)</h3>
                    <p className="text-sm text-gray-500 flex items-center">HVAC, Roofers, Restoration <ArrowRight className="w-4 h-4 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" /></p>
                </div>
            </Link>

             <Link to="/partners/government" className="group flex items-center gap-4 bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100 w-full md:w-auto">
                <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                    <Building className="w-6 h-6 text-slate-600" />
                </div>
                <div>
                    <h3 className="font-bold text-lg text-gray-900">Government Agencies</h3>
                    <p className="text-sm text-gray-500 flex items-center">SDVOSB Certified Services <ArrowRight className="w-4 h-4 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" /></p>
                </div>
            </Link>
          </div>

        </div>
      </section>

      {/* "Fit" Form Section */}
      <section id="partner-form-section" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
                <div>
                    <h2 className="text-4xl font-bold text-[#1B263B] mb-6 font-oswald">Serious About Safety? <br/><span className="text-[#D7263D]">Let's Talk Strategy.</span></h2>
                    <p className="text-lg text-gray-600 mb-8">
                        We don't just clean ducts; we solve operational headaches. Tell us a bit about your portfolio, and we'll show you exactly how our partner program can reduce your liability and workload.
                    </p>
                    
                    <div className="space-y-8">
                        <div className="flex gap-4">
                            <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center flex-shrink-0">
                                <FileCheck className="w-6 h-6 text-[#1B263B]" />
                            </div>
                            <div>
                                <h4 className="font-bold text-xl text-[#1B263B]">Documentation That Holds Up</h4>
                                <p className="text-gray-600">Every job comes with a digital audit trail. Before/After photos, sensor readings, and technician notes.</p>
                            </div>
                        </div>
                        <div className="flex gap-4">
                            <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center flex-shrink-0">
                                <Award className="w-6 h-6 text-[#D7263D]" />
                            </div>
                            <div>
                                <h4 className="font-bold text-xl text-[#1B263B]">Certified Expertise</h4>
                                <p className="text-gray-600">No bait-and-switch. Our technicians are NADCA certified and background checked.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div className="mt-12 p-6 bg-gray-50 rounded-xl border border-gray-100">
                        <p className="italic text-gray-600">
                            "The Vent Guys simplified our entire annual fire safety inspection process. They handle the scheduling, the cleaning, and the reporting. It's on autopilot now."
                        </p>
                        <div className="mt-4 font-bold text-[#1B263B]">— Sarah Jenkins, Regional Property Manager</div>
                    </div>
                </div>
                
                <div>
                    <PartnerLeadForm />
                </div>
            </div>
        </div>
      </section>
    </div>
  );
};

export default PartnersLanding;
