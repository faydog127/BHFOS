import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState(null);

  const galleryImages = [
    { title: 'Before: Dirty Air Duct', description: 'Years of dust and debris accumulation', image: 'Severely dirty air duct filled with dust, debris, and contaminants before cleaning' },
    { title: 'After: Clean Air Duct', description: 'Professionally cleaned and sanitized', image: 'Spotlessly clean air duct after professional NADCA-certified cleaning' },
    { title: 'Dryer Vent Lint Buildup', description: 'Fire hazard removed from dryer vent', image: 'Dangerous lint buildup removed from dryer vent during professional cleaning' },
    { title: 'HVAC Coil Cleaning', description: 'Restoring system efficiency', image: 'Technician cleaning HVAC evaporator coil with specialized equipment' },
    { title: 'Mold Remediation', description: 'Mold growth eliminated from ductwork', image: 'Mold growth in air duct before professional remediation and cleaning' },
    { title: 'Clean System Components', description: 'All components thoroughly cleaned', image: 'Clean HVAC system components after professional maintenance service' },
    { title: 'Before: Return Vent', description: 'Dust-covered return air vent', image: 'Dirty return air vent covered in dust and debris before cleaning' },
    { title: 'After: Return Vent', description: 'Clean and sanitized return vent', image: 'Clean return air vent after professional cleaning and sanitization' },
    { title: 'Ductwork Inspection', description: 'Camera inspection of duct system', image: 'Technician performing video camera inspection of air duct system' },
    { title: 'Professional Equipment', description: 'NADCA-approved cleaning tools', image: 'Professional air duct cleaning equipment and NADCA-approved tools' },
    { title: 'Residential Service', description: 'Serving Brevard County homes', image: 'Technician providing air duct cleaning service at residential home' },
    { title: 'Commercial Project', description: 'Large-scale commercial cleaning', image: 'Commercial air duct cleaning project in office building' }
  ];

  return (
    <>
      <Helmet>
        <title>Our Work Gallery - Before & After Photos | The Vent Guys</title>
        <meta name="description" content="See the difference professional NADCA-certified air duct cleaning makes. Before and after photos of our work in Brevard County, FL." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1B263B] to-[#2a3f5f] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Work</h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              See the dramatic difference professional NADCA-certified air duct cleaning makes in Brevard County homes
            </p>
          </motion.div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryImages.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="relative group cursor-pointer"
                onClick={() => setSelectedImage(item)}
              >
                <div className="relative rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all">
                  <img 
                    class="w-full h-auto aspect-[4/5] md:aspect-square object-cover transition-transform group-hover:scale-110 duration-300" 
                    alt={item.title}
                    style={{ opacity: 0.95 }}
                   src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                      <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                      <p className="text-sm text-gray-200">{item.description}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div 
          className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button 
            className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors"
            onClick={() => setSelectedImage(null)}
          >
            <X className="h-8 w-8" />
          </button>
          <div className="max-w-5xl w-full">
            <img 
              class="w-full h-auto max-h-[80vh] object-contain rounded-lg" 
              alt={selectedImage.title}
             src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
            <div className="text-white text-center mt-6">
              <h3 className="text-2xl font-bold mb-2">{selectedImage.title}</h3>
              <p className="text-gray-300">{selectedImage.description}</p>
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-[#1B263B] mb-6">
            Ready to See These Results in Your Home?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Schedule your professional air duct cleaning today and experience the difference NADCA-certified service makes.
          </p>
          <a href="/contact">
            <button className="bg-[#D7263D] hover:bg-[#b51f31] text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all transform hover:scale-105 shadow-lg">
              Book Your Service
            </button>
          </a>
        </div>
      </section>
    </>
  );
};

export default Gallery;