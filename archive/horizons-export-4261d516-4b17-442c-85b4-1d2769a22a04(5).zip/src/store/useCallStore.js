
import { create } from 'zustand';

/**
 * @typedef {Object} LeadData
 * @property {string} id
 * @property {string} first_name
 * @property {string} last_name
 * @property {string} [phone]
 * @property {string} [email]
 * @property {string} [company]
 * @property {string} [pipeline_stage]
 * @property {number} [pqi]
 */

/**
 * @typedef {'idle' | 'connecting' | 'ringing' | 'connected' | 'wrap_up' | 'ended' | 'failed'} CallState
 */

/**
 * Zustand store for managing call state
 */
const useCallStore = create((set) => ({
  /** @type {boolean} */
  isCallActive: false,
  
  /** @type {CallState} */
  callState: 'idle',
  
  /** @type {LeadData | null} */
  lead: null,
  
  /** @type {number} Duration in seconds */
  duration: 0,

  /**
   * Starts a call with the given lead
   * @param {LeadData} lead 
   */
  startCall: (lead) => set({
    isCallActive: true,
    lead,
    callState: 'connecting',
    duration: 0
  }),

  /**
   * Updates the current call state
   * @param {CallState} state 
   */
  setCallState: (state) => set({ callState: state }),

  /**
   * Resets the call duration timer
   */
  resetTimer: () => set({ duration: 0 }),

  /**
   * Increments the duration by 1 second
   */
  incrementDuration: () => set((state) => ({ duration: state.duration + 1 })),

  /**
   * Ends the current call and transitions to wrap-up
   */
  endCall: () => set({
    isCallActive: false,
    callState: 'wrap_up',
  }),

  // Utility to clear data after summary view
  clearCall: () => set({
    isCallActive: false,
    callState: 'idle',
    lead: null,
    duration: 0
  })
}));

export default useCallStore;
