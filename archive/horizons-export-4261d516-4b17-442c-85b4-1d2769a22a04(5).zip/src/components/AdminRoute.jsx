import React from 'react';

const AdminRoute = ({ children }) => {
  // Authentication removed, so we just render the children.
  return children;
};

export default AdminRoute;