import React, { useState } from 'react';
import { DndContext, closestCenter } from '@dnd-kit/core';
import { SortableContext, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';

const TASK_STATUSES = ['new', 'in-progress', 'completed', 'snoozed'];

const TaskCard = ({ task, onTaskUpdate }) => {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: task.id });
    const style = { transform: CSS.Transform.toString(transform), transition };

    const leadName = task.lead?.company || `${task.lead?.first_name || ''} ${task.lead?.last_name || ''}`.trim() || 'N/A';
    const dueDate = task.due_at ? new Date(task.due_at).toLocaleDateString() : 'No due date';

    return (
        <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
            <Card className="mb-3 bg-white shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="p-3">
                    <CardTitle className="text-base font-semibold">{task.title}</CardTitle>
                </CardHeader>
                <CardContent className="p-3 text-sm space-y-2">
                    <p className="text-gray-600">For: {leadName}</p>
                    <p className="text-gray-500">Due: {dueDate}</p>
                    <div>
                        <Select
                            value={task.status}
                            onValueChange={(newStatus) => onTaskUpdate(task.id, { status: newStatus })}
                        >
                            <SelectTrigger className="text-xs h-8">
                                <SelectValue placeholder="Set status" />
                            </SelectTrigger>
                            <SelectContent>
                                {TASK_STATUSES.map(status => (
                                    <SelectItem key={status} value={status}>
                                        {status.charAt(0).toUpperCase() + status.slice(1)}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

const KanbanColumn = ({ title, tasks, onTaskUpdate }) => {
    const { setNodeRef } = useSortable({ id: title, data: { accepts: ['task'] } });
    
    return (
        <div ref={setNodeRef} className="bg-gray-100 rounded-lg p-3 w-72 flex-shrink-0">
            <h3 className="font-semibold mb-4 px-1">{title.charAt(0).toUpperCase() + title.slice(1)} ({tasks.length})</h3>
            <SortableContext items={tasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
                <div className="space-y-3 min-h-[50px]">
                    {tasks.map(task => (
                        <TaskCard key={task.id} task={task} onTaskUpdate={onTaskUpdate} />
                    ))}
                </div>
            </SortableContext>
        </div>
    );
};

const ActionHubKanbanView = ({ tasks, onTaskUpdate }) => {
    const handleDragEnd = (event) => {
        const { active, over } = event;
        if (over && active.id !== over.id) {
            // Find the task and the new status/column
            const task = tasks.find(t => t.id === active.id);
            const newStatus = over.id;

            if (task && TASK_STATUSES.includes(newStatus) && task.status !== newStatus) {
                onTaskUpdate(task.id, { status: newStatus });
            }
        }
    };

    return (
        <DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <div className="flex gap-6 overflow-x-auto p-2">
                <SortableContext items={TASK_STATUSES} strategy={verticalListSortingStrategy}>
                    {TASK_STATUSES.map(status => (
                        <KanbanColumn
                            key={status}
                            title={status}
                            tasks={tasks.filter(t => t.status === status)}
                            onTaskUpdate={onTaskUpdate}
                        />
                    ))}
                </SortableContext>
            </div>
        </DndContext>
    );
};

export default ActionHubKanbanView;