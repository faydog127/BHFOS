import React, { useState, useEffect } from 'react';
import { Sparkles, Rss } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import SignalsPanel from '@/components/crm/call-console/SignalsPanel';
import { useToast } from '@/components/ui/use-toast';
import { invoke } from '@/lib/api';
import { useSignals } from '@/hooks/useSignals';

const PreCallBrief = ({ lead }) => {
    const { toast } = useToast();
    const [isGenerating, setIsGenerating] = useState(false);
    
    // Use the useSignals hook which now uses public 'invoke'
    const { signals, loading: signalsLoading, refetchSignals } = useSignals(lead?.company, lead?.id);

    const handleRefreshIntel = () => {
        if (lead) {
            toast({ title: "Refreshing Intel...", description: "Acquiring the latest signals for this lead." });
            refetchSignals();
        }
    };

    useEffect(() => {
        if (lead) {
            refetchSignals();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [lead]);
    
    const generateBrief = async () => {
        if (!lead) return;
        setIsGenerating(true);
        try {
            const { ok, data, error } = await invoke('generate-brief', {
                body: { lead_id: lead.id }
            });
            if (!ok) throw new Error(error);
            toast({ title: "AI Brief Generated!", description: "Lead summary has been updated." });
        } catch (e) {
            toast({ variant: 'destructive', title: 'Brief Generation Failed', description: e.message });
        }
        setIsGenerating(false);
    };

    return (
        <Card className="bg-white text-gray-900 flex-1 h-full flex flex-col">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <CardTitle className="text-2xl">{lead?.company || `${lead?.first_name} ${lead?.last_name}`}</CardTitle>
                        <CardDescription>PQI: {lead?.pqi}/100 | {lead?.pipeline_stage}</CardDescription>
                    </div>
                    <div className="flex gap-2">
                         <Button onClick={handleRefreshIntel} disabled={signalsLoading} size="sm" variant="outline">
                            {signalsLoading ? "Acquiring..." : <><Rss className="mr-2 h-4 w-4" /> Refresh Intel</>}
                        </Button>
                        <Button onClick={generateBrief} disabled={isGenerating} size="sm">
                            {isGenerating ? "Working..." : <><Sparkles className="mr-2 h-4 w-4" /> Gen Brief</>}
                        </Button>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="space-y-3 overflow-y-auto flex-1 pr-2">
                 <div className="bg-gray-50 p-3 rounded-lg border">
                    <h3 className="font-bold text-gray-700 flex items-center mb-2 text-sm">SUMMARY</h3>
                     <p className="text-sm text-gray-600">{lead?.message || 'No initial message provided.'}</p>
                </div>
                <SignalsPanel signals={signals} isLoading={signalsLoading} />
            </CardContent>
        </Card>
    );
};

export default PreCallBrief;