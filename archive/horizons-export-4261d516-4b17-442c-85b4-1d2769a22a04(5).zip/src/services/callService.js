
// import { apiClient } from '@/services/apiClient';

/**
 * @typedef {Object} LogAndOutreachPayload
 * @property {string} lead_id - The unique identifier of the lead
 * @property {string} script_type - The script identifier used during the call
 * @property {string} result - The outcome of the call
 * @property {string} next_step - The subsequent action to take
 * @property {string} notes - Any notes taken during the call
 * @property {string} call_state - The state of the call when logged (e.g. 'wrap_up')
 * @property {number} duration_seconds - The duration of the call in seconds
 */

/**
 * @typedef {Object} LogAndOutreachResponse
 * @property {boolean} success - Whether the operation was successful
 * @property {string} lead_id - The lead ID returned from the server
 * @property {string} pipeline_stage - The updated pipeline stage
 * @property {string} created_call_log_id - The ID of the created call log
 * @property {string|null} created_task_id - The ID of the created task (if any)
 * @property {string|null} error - Error message if any
 */

/**
 * Logs the call outcome and triggers outreach.
 * 
 * @param {LogAndOutreachPayload} payload
 * @returns {Promise<LogAndOutreachResponse>}
 */
export const logAndOutreach = async (payload) => {
  // Flag to toggle mock mode
  const isMocked = true;

  if (isMocked) {
    console.log('📡 [MOCK API] logAndOutreach payload:', payload);

    // Simulate 500ms API latency
    await new Promise((resolve) => setTimeout(resolve, 500));

    return {
      success: true,
      lead_id: payload.lead_id,
      pipeline_stage: "attempting",
      created_call_log_id: "CALL-MOCK-123",
      created_task_id: payload.next_step === "NO_ACTION" ? null : "TASK-MOCK-999",
      error: null
    };
  }

  // TODO: Wire this to live backend when API is ready
  // return apiClient.post('/calls/end', payload);
};
